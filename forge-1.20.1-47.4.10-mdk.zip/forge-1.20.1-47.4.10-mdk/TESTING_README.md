# RPG对话Mod - 测试与重构指南

## 项目概述

本项目已经进行了架构重构，以提高可测试性和系统稳定性。主要改进包括：

1. 引入了依赖注入和接口抽象
2. 创建了服务层来解耦业务逻辑
3. 添加了测试框架和测试工具类
4. 重构了单例类为可注入的服务

## 项目结构

### 源代码结构

```
src/main/java/rpg/
├── RpgDialogueMod.java          # Mod主类
├── data/                        # 数据模型
│   ├── DialogueNode.java
│   ├── DialogueOption.java
│   ├── DialogueLoader.java       # 已废弃，使用服务层替代
│   ├── PlayerVariables.java
│   └── ...
├── service/                     # 服务层（新增）
│   ├── IDialogueRepository.java  # 对话数据仓库接口
│   ├── IPlayerVariableService.java  # 玩家变量服务接口
│   ├── IPacketSender.java        # 网络包发送服务接口
│   ├── IDialogueHistoryService.java  # 对话历史服务接口
│   ├── ISerializer.java          # 序列化服务接口
│   ├── ModServices.java         # 服务定位器
│   ├── DialogueService.java      # 对话流程服务
│   └── impl/                    # 服务实现
│       ├── DialogueRepositoryImpl.java
│       ├── PlayerVariableServiceImpl.java
│       ├── PacketSenderImpl.java
│       ├── DialogueHistoryServiceImpl.java
│       └── NbtSerializerImpl.java
└── ...
```

### 测试代码结构

```
src/test/java/rpg/
├── test/                        # 测试工具类
│   ├── BaseTest.java            # 测试基类
│   ├── DialogueNodeBuilder.java  # 对话节点构建器
│   ├── DialogueOptionBuilder.java  # 对话选项构建器
│   └── PlayerVariablesBuilder.java  # 玩家变量构建器
└── ...
```

## 测试框架

项目使用以下测试框架：

- **JUnit 5**: 单元测试框架
- **Mockito**: Mock框架，用于模拟依赖
- **Hamcrest**: 断言库

## 运行测试

### 运行所有测试

```bash
./gradlew test
```

### 运行特定测试类

```bash
./gradlew test --tests rpg.data.DialogueNodeTest
```

### 生成测试覆盖率报告

```bash
./gradlew test jacocoTestReport
```

覆盖率报告将生成在 `build/reports/jacoco/test/html/index.html`

## 测试策略

### 单元测试

单元测试主要针对核心业务逻辑，包括：

1. **条件解析器** (ConditionParser)
   - 条件表达式解析
   - 条件评估逻辑

2. **数据模型** (DialogueNode, DialogueOption)
   - 数据序列化/反序列化
   - 数据验证

3. **玩家变量** (PlayerVariables)
   - 变量设置和获取
   - 变量类型转换

4. **服务层**
   - 对话仓库
   - 玩家变量服务
   - 对话历史服务

### 集成测试

集成测试主要针对模块间的交互，包括：

1. **网络通信**
   - 网络包的发送和接收
   - 客户端和服务器同步

2. **事件处理**
   - 对话事件
   - NPC行为事件

3. **对话流程**
   - 完整的对话流程
   - 多NPC对话

## 编写测试

### 示例：测试对话节点

```java
import org.junit.jupiter.api.Test;
import rpg.data.DialogueNode;
import rpg.test.DialogueNodeBuilder;
import rpg.test.BaseTest;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

class DialogueNodeTest extends BaseTest {

    @Test
    void testNodeCreation() {
        DialogueNode node = DialogueNodeBuilder.aNode()
            .withId("TEST_NODE")
            .withSpeaker("测试NPC")
            .withText("这是一段测试对话")
            .build();

        assertThat(node.getNodeId(), is("TEST_NODE"));
        assertThat(node.getSpeakerName(), is("测试NPC"));
        assertThat(node.getNpcText(), is("这是一段测试对话"));
    }

    @Test
    void testNodeSerialization() {
        DialogueNode original = DialogueNodeBuilder.aNode()
            .withId("TEST_NODE")
            .withText("测试文本")
            .build();

        CompoundTag tag = original.serializeNBT();
        DialogueNode deserialized = DialogueNode.deserializeNBT(tag);

        assertThat(deserialized.getNodeId(), is(original.getNodeId()));
        assertThat(deserialized.getNpcText(), is(original.getNpcText()));
    }
}
```

### 示例：测试服务层

```java
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import rpg.service.DialogueService;
import rpg.service.IDialogueRepository;
import rpg.service.IPlayerVariableService;
import rpg.service.IPacketSender;
import rpg.service.IDialogueHistoryService;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DialogueServiceTest extends BaseTest {

    @Mock
    private IDialogueRepository dialogueRepository;

    @Mock
    private IPlayerVariableService playerVariableService;

    @Mock
    private IPacketSender packetSender;

    @Mock
    private IDialogueHistoryService dialogueHistoryService;

    @Test
    void testProcessDialogueOption() {
        // Arrange
        DialogueService service = new DialogueService(
            dialogueRepository,
            playerVariableService,
            packetSender,
            dialogueHistoryService
        );

        // Act & Assert
        // 添加测试逻辑
    }
}
```

## 服务层使用指南

### 获取服务实例

```java
// 获取对话仓库
IDialogueRepository dialogueRepo = ModServices.getDialogueRepository();

// 获取玩家变量服务
IPlayerVariableService varService = ModServices.getPlayerVariableService();

// 获取网络包发送服务
IPacketSender packetSender = ModServices.getPacketSender();

// 获取对话历史服务
IDialogueHistoryService historyService = ModServices.getDialogueHistoryService();
```

### 在测试中替换服务

```java
@BeforeEach
void setUp() {
    // 创建Mock服务
    IDialogueRepository mockRepo = mock(IDialogueRepository.class);

    // 替换服务
    ModServices.setDialogueRepository(mockRepo);
}
```

## 迁移指南

### 从旧代码迁移到服务层

**旧代码**:
```java
DialogueNode node = DialogueLoader.getNode(nodeId);
```

**新代码**:
```java
IDialogueRepository repo = ModServices.getDialogueRepository();
DialogueNode node = repo.getNode(nodeId);
```

**旧代码**:
```java
PlayerVariables vars = PlayerVariableManager.getInstance().getPlayerVariables(player);
```

**新代码**:
```java
IPlayerVariableService service = ModServices.getPlayerVariableService();
PlayerVariables vars = service.getPlayerVariables(player);
```

## 最佳实践

1. **使用依赖注入**：通过构造函数注入依赖，而不是直接使用静态方法或单例
2. **面向接口编程**：使用接口而不是具体实现，便于测试和替换
3. **编写单元测试**：为每个服务方法编写单元测试，确保逻辑正确
4. **使用Mock隔离依赖**：在测试中使用Mock对象隔离外部依赖
5. **保持测试独立**：每个测试应该独立运行，不依赖其他测试的状态

## 后续计划

1. 为所有核心业务逻辑编写单元测试
2. 为关键流程编写集成测试
3. 提高测试覆盖率到80%以上
4. 添加性能测试
5. 添加压力测试
