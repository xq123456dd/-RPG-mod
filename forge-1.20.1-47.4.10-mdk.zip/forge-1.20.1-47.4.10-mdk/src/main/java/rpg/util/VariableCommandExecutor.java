package rpg.util;

import net.minecraft.server.level.ServerPlayer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import rpg.data.DialogueCommand;
import rpg.data.PlayerVariableManager;
import rpg.data.PlayerVariables;
import rpg.data.PlayerVariables.VariableType;

public class VariableCommandExecutor {
    private static final Logger LOGGER = LogManager.getLogger();

    /**
     * 执行设置变量命令
     */
    public static void executeSetVariable(DialogueCommand command, PlayerVariables variables, ServerPlayer player) {
        String varName = command.getVariableName();
        String varValue = command.getVariableValue();

        if (varName == null || varName.isEmpty()) {
            LOGGER.error("SET_VARIABLE命令缺少变量名");
            return;
        }

        if (varValue == null) {
            LOGGER.error("SET_VARIABLE命令缺少变量值: {}", varName);
            return;
        }

        // 尝试解析值
        Object value = parseVariableValue(varValue);
        VariableType type = inferVariableType(value);

        variables.setVariable(varName, type, value);
        PlayerVariableManager.getInstance().markDirty(player);
        LOGGER.info("设置变量: {} = {} (类型: {})", varName, value, type);
    }

    /**
     * 执行增加变量命令（如果存在则添加值，否则新建）
     */
    public static void executeAddVariable(DialogueCommand command, PlayerVariables variables, ServerPlayer player) {
        String varName = command.getVariableName();
        String varValue = command.getVariableValue();

        if (varName == null || varName.isEmpty()) {
            LOGGER.error("ADD_VARIABLE命令缺少变量名");
            return;
        }

        if (varValue == null) {
            LOGGER.error("ADD_VARIABLE命令缺少变量值: {}", varName);
            return;
        }

        Object addValue = parseVariableValue(varValue);

        if (!variables.hasVariable(varName)) {
            // 新建变量
            VariableType type = inferVariableType(addValue);
            variables.setVariable(varName, type, addValue);
        } else {
            Object currentValue = variables.getVariable(varName);
            VariableType currentType = variables.getType(varName); // 假设 PlayerVariables 有 getType 方法，如果没有需添加

            if (currentType != inferVariableType(addValue)) {
                LOGGER.error("ADD_VARIABLE 类型不匹配: 当前 {} 是 {}，尝试添加 {}", varName, currentType, inferVariableType(addValue));
                return;
            }

            if (currentType == VariableType.INTEGER) {
                int newValue = (Integer) currentValue + (Integer) addValue;
                variables.setVariable(varName, currentType, newValue);
            } else if (currentType == VariableType.FLOAT) {
                float newValue = (Float) currentValue + (Float) addValue;
                variables.setVariable(varName, currentType, newValue);
            } else {
                LOGGER.error("ADD_VARIABLE 不支持类型: {}", currentType);
                return;
            }
        }

        PlayerVariableManager.getInstance().markDirty(player);
        LOGGER.info("增加变量: {}", varName);
    }

    /**
     * 执行移除变量命令
     */
    public static void executeRemoveVariable(DialogueCommand command, PlayerVariables variables) {
        String varName = command.getVariableName();

        if (varName == null || varName.isEmpty()) {
            LOGGER.error("REMOVE_VARIABLE命令缺少变量名");
            return;
        }

        if (variables.hasVariable(varName)) {
            variables.removeVariable(varName); // 假设 PlayerVariables 有 removeVariable 方法，如果没有需添加
            LOGGER.info("移除变量: {}", varName);
        } else {
            LOGGER.warn("尝试移除不存在的变量: {}", varName);
        }
    }

    /**
     * 执行变量递增命令
     */
    public static void executeIncrementVariable(DialogueCommand command, PlayerVariables variables) {
        String varName = command.getVariableName();
        int amount = command.getValue(); // 假设 DialogueCommand 有 getValue() 返回增量，默认1

        if (varName == null || varName.isEmpty()) {
            LOGGER.error("VAR_INCREMENT命令缺少变量名");
            return;
        }

        if (!variables.hasVariable(varName)) {
            LOGGER.error("VAR_INCREMENT 变量不存在: {}", varName);
            return;
        }

        VariableType type = variables.getType(varName);
        Object current = variables.getVariable(varName);

        if (type == VariableType.INTEGER) {
            int newValue = (Integer) current + amount;
            variables.setVariable(varName, type, newValue);
        } else if (type == VariableType.FLOAT) {
            float newValue = (Float) current + amount;
            variables.setVariable(varName, type, newValue);
        } else {
            LOGGER.error("VAR_INCREMENT 不支持类型: {}", type);
        }
    }

    /**
     * 执行变量递减命令
     */
    public static void executeDecrementVariable(DialogueCommand command, PlayerVariables variables) {
        String varName = command.getVariableName();
        int amount = command.getValue(); // 默认1

        if (varName == null || varName.isEmpty()) {
            LOGGER.error("VAR_DECREMENT命令缺少变量名");
            return;
        }

        if (!variables.hasVariable(varName)) {
            LOGGER.error("VAR_DECREMENT 变量不存在: {}", varName);
            return;
        }

        VariableType type = variables.getType(varName);
        Object current = variables.getVariable(varName);

        if (type == VariableType.INTEGER) {
            int newValue = (Integer) current - amount;
            variables.setVariable(varName, type, newValue);
        } else if (type == VariableType.FLOAT) {
            float newValue = (Float) current - amount;
            variables.setVariable(varName, type, newValue);
        } else {
            LOGGER.error("VAR_DECREMENT 不支持类型: {}", type);
        }
    }

    /**
     * 解析变量值
     */
    private static Object parseVariableValue(String valueStr) {
        valueStr = valueStr.trim();

        if ("true".equalsIgnoreCase(valueStr)) {
            return true;
        } else if ("false".equalsIgnoreCase(valueStr)) {
            return false;
        } else if (isNumeric(valueStr)) {
            return parseNumber(valueStr);
        } else {
            // 不是布尔或数字，作为字符串
            return valueStr;
        }
    }

    /**
     * 推断变量类型
     */
    private static VariableType inferVariableType(Object value) {
        if (value instanceof Integer) return VariableType.INTEGER;
        if (value instanceof Boolean) return VariableType.BOOLEAN;
        if (value instanceof String) return VariableType.STRING;
        if (value instanceof Float || value instanceof Double) return VariableType.FLOAT;
        return VariableType.STRING; // 默认
    }

    /**
     * 解析数字
     */
    private static Number parseNumber(String valueStr) {
        try {
            if (valueStr.contains(".")) {
                return Float.parseFloat(valueStr);
            } else {
                return Integer.parseInt(valueStr);
            }
        } catch (NumberFormatException e) {
            LOGGER.error("解析数字失败: {}", valueStr);
            return 0; // 默认0，但记录错误
        }
    }

    /**
     * 检查字符串是否是数字
     */
    private static boolean isNumeric(String str) {
        if (str == null || str.isEmpty()) {
            return false;
        }
        try {
            Double.parseDouble(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}