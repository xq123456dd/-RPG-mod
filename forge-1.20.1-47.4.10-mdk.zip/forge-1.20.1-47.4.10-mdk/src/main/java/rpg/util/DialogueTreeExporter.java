package rpg.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import rpg.data.DialogueNode;
import rpg.data.DialogueOption;
import rpg.data.DialogueCommand;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * 对话树导入导出工具
 * 支持JSON格式的对话树文件
 */
public class DialogueTreeExporter {

    private static final Gson GSON = new GsonBuilder()
            .setPrettyPrinting()
            .create();

    /**
     * 导出对话树到JSON文件
     */
    public static boolean exportToJson(Map<String, DialogueNode> dialogueMap, String filePath) {
        try {
            JsonObject root = new JsonObject();
            JsonObject metadata = new JsonObject();

            metadata.addProperty("version", "1.0");
            metadata.addProperty("nodeCount", dialogueMap.size());
            metadata.addProperty("exportTime", System.currentTimeMillis());

            root.add("metadata", metadata);

            JsonObject nodes = new JsonObject();

            for (Map.Entry<String, DialogueNode> entry : dialogueMap.entrySet()) {
                DialogueNode node = entry.getValue();
                JsonObject nodeJson = serializeNode(node);
                nodes.add(entry.getKey(), nodeJson);
            }

            root.add("nodes", nodes);

            // 写入文件
            try (Writer writer = new OutputStreamWriter(
                    new FileOutputStream(filePath), StandardCharsets.UTF_8)) {
                GSON.toJson(root, writer);
            }

            System.out.println("成功导出对话树到: " + filePath + ", 节点数: " + dialogueMap.size());
            return true;

        } catch (Exception e) {
            System.err.println("导出对话树失败: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 从JSON文件导入对话树
     */
    public static Map<String, DialogueNode> importFromJson(String filePath) {
        try {
            // 读取文件
            String jsonContent;
            try (InputStream is = new FileInputStream(filePath)) {
                jsonContent = new String(is.readAllBytes(), StandardCharsets.UTF_8);
            }

            JsonObject root = GSON.fromJson(jsonContent, JsonObject.class);

            if (!root.has("nodes")) {
                throw new IllegalArgumentException("JSON文件中缺少nodes字段");
            }

            JsonObject nodesJson = root.getAsJsonObject("nodes");
            Map<String, DialogueNode> dialogueMap = new java.util.HashMap<>();

            for (String nodeId : nodesJson.keySet()) {
                JsonObject nodeJson = nodesJson.getAsJsonObject(nodeId);
                DialogueNode node = deserializeNode(nodeId, nodeJson);
                dialogueMap.put(nodeId, node);
            }

            System.out.println("成功导入对话树从: " + filePath + ", 节点数: " + dialogueMap.size());
            return dialogueMap;

        } catch (Exception e) {
            System.err.println("导入对话树失败: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 序列化单个节点到JSON
     */
    private static JsonObject serializeNode(DialogueNode node) {
        JsonObject nodeJson = new JsonObject();

        nodeJson.addProperty("id", node.getNodeId());
        nodeJson.addProperty("speaker", node.getSpeakerName());
        nodeJson.addProperty("text", node.getNpcText());

        if (!node.getOptions().isEmpty()) {
            JsonArray optionsJson = new JsonArray();

            for (DialogueOption option : node.getOptions()) {
                JsonObject optionJson = serializeOption(option);
                optionsJson.add(optionJson);
            }

            nodeJson.add("options", optionsJson);
        }

        return nodeJson;
    }

    /**
     * 序列化单个选项到JSON
     */
    private static JsonObject serializeOption(DialogueOption option) {
        JsonObject optionJson = new JsonObject();

        optionJson.addProperty("text", option.getOptionText());
        optionJson.addProperty("next", option.getNextNodeId());

        if (option.getAction() != null && !option.getAction().equals("NONE")) {
            optionJson.addProperty("action", option.getAction());
        }

        if (option.getCondition() != null && !option.getCondition().isEmpty()) {
            optionJson.addProperty("condition", option.getCondition());
        }

        if (!option.getCommands().isEmpty()) {
            JsonArray commandsJson = new JsonArray();

            for (DialogueCommand command : option.getCommands()) {
                JsonObject commandJson = serializeCommand(command);
                commandsJson.add(commandJson);
            }

            optionJson.add("commands", commandsJson);
        }

        return optionJson;
    }

    /**
     * 序列化单个命令到JSON
     */
    private static JsonObject serializeCommand(DialogueCommand command) {
        JsonObject commandJson = new JsonObject();

        commandJson.addProperty("type", command.getCommandType());

        if (command.getCommandArgument() != null && !command.getCommandArgument().isEmpty()) {
            commandJson.addProperty("argument", command.getCommandArgument());
        }

        if (command.getValue() != 0) {
            commandJson.addProperty("value", command.getValue());
        }

        if (command.getVariableName() != null && !command.getVariableName().isEmpty()) {
            commandJson.addProperty("variableName", command.getVariableName());
        }

        if (command.getVariableValue() != null && !command.getVariableValue().isEmpty()) {
            commandJson.addProperty("variableValue", command.getVariableValue());
        }

        return commandJson;
    }

    /**
     * 从JSON反序列化节点
     */
    private static DialogueNode deserializeNode(String nodeId, JsonObject nodeJson) {
        String speaker = nodeJson.has("speaker") ? nodeJson.get("speaker").getAsString() : "";
        String text = nodeJson.has("text") ? nodeJson.get("text").getAsString() : "";

        DialogueNode node = new DialogueNode(nodeId);
        node.setSpeakerName(speaker);
        node.setNpcText(text);

        if (nodeJson.has("options")) {
            JsonArray optionsJson = nodeJson.getAsJsonArray("options");

            for (int i = 0; i < optionsJson.size(); i++) {
                JsonObject optionJson = optionsJson.get(i).getAsJsonObject();
                DialogueOption option = deserializeOption(optionJson);
                node.getOptions().add(option);
            }
        }

        return node;
    }

    /**
     * 从JSON反序列化选项
     */
    private static DialogueOption deserializeOption(JsonObject optionJson) {
        String text = optionJson.get("text").getAsString();
        String next = optionJson.get("next").getAsString();
        String action = optionJson.has("action") ? optionJson.get("action").getAsString() : "NONE";
        String condition = optionJson.has("condition") ? optionJson.get("condition").getAsString() : "";

        DialogueOption option = new DialogueOption(text, next, action, condition);

        if (optionJson.has("commands")) {
            JsonArray commandsJson = optionJson.getAsJsonArray("commands");

            for (int i = 0; i < commandsJson.size(); i++) {
                JsonObject commandJson = commandsJson.get(i).getAsJsonObject();
                DialogueCommand command = deserializeCommand(commandJson);
                option.getCommands().add(command);
            }
        }

        return option;
    }

    /**
     * 从JSON反序列化命令
     */
    private static DialogueCommand deserializeCommand(JsonObject commandJson) {
        String type = commandJson.get("type").getAsString();
        DialogueCommand command = new DialogueCommand();
        command.setCommandType(type);

        if (commandJson.has("argument")) {
            command.setCommandArgument(commandJson.get("argument").getAsString());
        }

        if (commandJson.has("value")) {
            command.setValue(commandJson.get("value").getAsInt());
        }

        if (commandJson.has("variableName")) {
            command.setVariableName(commandJson.get("variableName").getAsString());
        }

        if (commandJson.has("variableValue")) {
            command.setVariableValue(commandJson.get("variableValue").getAsString());
        }

        return command;
    }

    /**
     * 导出为紧凑格式（用于网络传输）
     */
    public static String exportToCompactJson(Map<String, DialogueNode> dialogueMap) {
        try {
            JsonObject root = new JsonObject();
            JsonObject nodes = new JsonObject();

            for (Map.Entry<String, DialogueNode> entry : dialogueMap.entrySet()) {
                DialogueNode node = entry.getValue();
                JsonObject nodeJson = serializeNodeCompact(node);
                nodes.add(entry.getKey(), nodeJson);
            }

            root.add("n", nodes); // 使用短字段名

            return GSON.toJson(root);

        } catch (Exception e) {
            System.err.println("生成紧凑JSON失败: " + e.getMessage());
            return "{}";
        }
    }

    /**
     * 紧凑序列化节点
     */
    private static JsonObject serializeNodeCompact(DialogueNode node) {
        JsonObject nodeJson = new JsonObject();

        nodeJson.addProperty("s", node.getSpeakerName()); // speaker
        nodeJson.addProperty("t", node.getNpcText()); // text

        if (!node.getOptions().isEmpty()) {
            JsonArray optionsJson = new JsonArray();

            for (DialogueOption option : node.getOptions()) {
                JsonObject optionJson = serializeOptionCompact(option);
                optionsJson.add(optionJson);
            }

            nodeJson.add("o", optionsJson); // options
        }

        return nodeJson;
    }

    /**
     * 紧凑序列化选项
     */
    private static JsonObject serializeOptionCompact(DialogueOption option) {
        JsonObject optionJson = new JsonObject();

        optionJson.addProperty("t", option.getOptionText()); // text
        optionJson.addProperty("n", option.getNextNodeId()); // next

        if (option.getAction() != null && !option.getAction().equals("NONE")) {
            optionJson.addProperty("a", option.getAction()); // action
        }

        if (option.getCondition() != null && !option.getCondition().isEmpty()) {
            optionJson.addProperty("c", option.getCondition()); // condition
        }

        if (!option.getCommands().isEmpty()) {
            JsonArray commandsJson = new JsonArray();

            for (DialogueCommand command : option.getCommands()) {
                JsonObject commandJson = serializeCommandCompact(command);
                commandsJson.add(commandJson);
            }

            optionJson.add("cmds", commandsJson); // commands
        }

        return optionJson;
    }

    /**
     * 紧凑序列化命令
     */
    private static JsonObject serializeCommandCompact(DialogueCommand command) {
        JsonObject commandJson = new JsonObject();

        commandJson.addProperty("t", command.getCommandType()); // type

        if (command.getCommandArgument() != null && !command.getCommandArgument().isEmpty()) {
            commandJson.addProperty("a", command.getCommandArgument()); // argument
        }

        if (command.getVariableName() != null && !command.getVariableName().isEmpty()) {
            commandJson.addProperty("vn", command.getVariableName()); // variableName
        }

        if (command.getVariableValue() != null && !command.getVariableValue().isEmpty()) {
            commandJson.addProperty("vv", command.getVariableValue()); // variableValue
        }

        return commandJson;
    }
}