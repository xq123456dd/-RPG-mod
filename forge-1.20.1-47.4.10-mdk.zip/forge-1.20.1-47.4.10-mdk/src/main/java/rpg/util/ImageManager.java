package rpg.util;

import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import rpg.RpgDialogueMod;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

public class ImageManager {
    private static final File IMAGE_DIR = new File(Minecraft.getInstance().gameDirectory, "rpg_images");

    static {
        if (!IMAGE_DIR.exists()) {
            IMAGE_DIR.mkdirs();  // 自动创建文件夹
        }
    }

    public static String saveImage(File source) throws IOException {
        String newName = UUID.randomUUID().toString() + getExtension(source.getName());
        File dest = new File(IMAGE_DIR, newName);
        Files.copy(source.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING);
        return "rpg_images/" + newName;  // 返回相对路径
    }

    private static String getExtension(String filename) {
        int dot = filename.lastIndexOf('.');
        return dot > 0 ? filename.substring(dot) : ".png";
    }

    public static ResourceLocation getImageResource(String path) {
        // 在 Minecraft 中注册/加载纹理（假设已绑定）
        return ResourceLocation.fromNamespaceAndPath(RpgDialogueMod.MOD_ID, path);
    }
}