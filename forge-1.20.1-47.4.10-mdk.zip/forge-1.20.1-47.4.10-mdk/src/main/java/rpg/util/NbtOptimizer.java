package rpg.util;

import net.minecraft.nbt.CompoundTag;
import rpg.data.DialogueNode;
import java.util.HashMap;
import java.util.Map;

/**
 * NBT 优化器：负责将复杂的 Java 对象（如对话地图）序列化到 NBT，并从 NBT 反序列化回来。
 */
public class NbtOptimizer {

    /**
     * 将整个对话地图 Map<String, DialogueNode> 序列化为一个 CompoundTag。
     */
    public static CompoundTag serializeDialogueMap(Map<String, DialogueNode> dialogueMap) {
        CompoundTag rootNbt = new CompoundTag();
        for (Map.Entry<String, DialogueNode> entry : dialogueMap.entrySet()) {
            if (entry.getValue() != null) {
                try {
                    // 调用 DialogueNode.serializeNBT()
                    rootNbt.put(entry.getKey(), entry.getValue().serializeNBT());
                } catch (Exception e) {
                    System.err.println("序列化 DialogueNode 失败，ID: " + entry.getKey());
                    e.printStackTrace();
                }
            }
        }
        return rootNbt;
    }

    /**
     * 从 CompoundTag 反序列化回整个对话地图 Map<String, DialogueNode>。
     */
    public static Map<String, DialogueNode> deserializeDialogueMap(CompoundTag nbt) {
        Map<String, DialogueNode> map = new HashMap<>();
        for (String nodeId : nbt.getAllKeys()) {
            CompoundTag nodeNbt = nbt.getCompound(nodeId);
            try {
                // 修复点：调用 DialogueNode.deserializeNBT()
                map.put(nodeId, DialogueNode.deserializeNBT(nodeNbt));
            } catch (Exception e) {
                System.err.println("反序列化 DialogueNode 失败，ID: " + nodeId);
                e.printStackTrace();
            }
        }
        return map;
    }
}