
package rpg.data;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/**
 * 从JSON文件加载对话数据
 */
public class JsonDialogueLoader {
    private static final Logger LOGGER = LogManager.getLogger();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    // 对话数据文件夹
    private static final String DIALOGUE_FOLDER = "rpg_dialogues";

    /**
     * 从JSON文件夹加载所有对话数据
     */
    public static void loadDialoguesFromFolder(ServerLevel level) {
        if (level.dimension() != Level.OVERWORLD) return;

        File dialogueDir = getDialogueDirectory(level);

        if (!dialogueDir.exists()) {
            dialogueDir.mkdirs();
            LOGGER.info("对话数据文件夹不存在，已创建: " + dialogueDir.getAbsolutePath());
            return;
        }

        File[] jsonFiles = dialogueDir.listFiles((dir, name) -> name.endsWith(".json"));

        if (jsonFiles == null || jsonFiles.length == 0) {
            LOGGER.info("对话数据文件夹为空: " + dialogueDir.getAbsolutePath());
            return;
        }

        int loadedCount = 0;
        for (File jsonFile : jsonFiles) {
            try {
                Map<String, DialogueNode> nodes = loadFromJsonFile(jsonFile);
                if (nodes != null && !nodes.isEmpty()) {
                    DialogueLoader.DIALOGUE_MAP.putAll(nodes);
                    loadedCount += nodes.size();
                    LOGGER.info("成功加载对话文件: " + jsonFile.getName() + ", 节点数: " + nodes.size());
                }
            } catch (Exception e) {
                LOGGER.error("加载对话文件失败: " + jsonFile.getName(), e);
            }
        }

        LOGGER.info("=== 从JSON文件夹加载了 " + loadedCount + " 个对话节点 ===");
    }

    /**
     * 从单个JSON文件加载对话数据
     */
    public static Map<String, DialogueNode> loadFromJsonFile(File jsonFile) throws IOException {
        String jsonContent;
        try (InputStream is = new FileInputStream(jsonFile)) {
            jsonContent = new String(is.readAllBytes(), StandardCharsets.UTF_8);
        }

        JsonObject root = GSON.fromJson(jsonContent, JsonObject.class);

        if (!root.has("nodes")) {
            throw new IllegalArgumentException("JSON文件中缺少nodes字段");
        }

        JsonObject nodesJson = root.getAsJsonObject("nodes");
        Map<String, DialogueNode> dialogueMap = new HashMap<>();

        for (String nodeId : nodesJson.keySet()) {
            JsonObject nodeJson = nodesJson.getAsJsonObject(nodeId);
            DialogueNode node = deserializeNode(nodeId, nodeJson);
            dialogueMap.put(nodeId, node);
        }

        return dialogueMap;
    }

    /**
     * 反序列化对话节点
     */
    private static DialogueNode deserializeNode(String nodeId, JsonObject nodeJson) {
        DialogueNode node = new DialogueNode(nodeId);

        if (nodeJson.has("npcText")) {
            node.setNpcText(nodeJson.get("npcText").getAsString());
        }

        if (nodeJson.has("speakerName")) {
            node.setSpeakerName(nodeJson.get("speakerName").getAsString());
        }

        if (nodeJson.has("priority")) {
            node.setPriority(nodeJson.get("priority").getAsInt());
        }

        // 加载选项
        if (nodeJson.has("options")) {
            JsonArray optionsArray = nodeJson.getAsJsonArray("options");
            for (int i = 0; i < optionsArray.size(); i++) {
                JsonObject optionJson = optionsArray.get(i).getAsJsonObject();
                DialogueOption option = deserializeOption(optionJson);
                node.getOptions().add(option);
            }
        }

        // 加载图片
        if (nodeJson.has("images")) {
            JsonArray imagesArray = nodeJson.getAsJsonArray("images");
            for (int i = 0; i < imagesArray.size(); i++) {
                JsonObject imageJson = imagesArray.get(i).getAsJsonObject();
                DialogueNode.ImageData image = deserializeImage(imageJson);
                node.getImages().add(image);
            }
        }

        // 加载标签
        if (nodeJson.has("tags")) {
            JsonArray tagsArray = nodeJson.getAsJsonArray("tags");
            List<String> tags = new ArrayList<>();
            for (int i = 0; i < tagsArray.size(); i++) {
                tags.add(tagsArray.get(i).getAsString());
            }
            node.setTags(tags);
        }

        return node;
    }

    /**
     * 反序列化对话选项
     */
    private static DialogueOption deserializeOption(JsonObject optionJson) {
        String optionText = optionJson.has("optionText") ? optionJson.get("optionText").getAsString() : "";
        String nextNodeId = optionJson.has("nextNodeId") ? optionJson.get("nextNodeId").getAsString() : "";
        String action = optionJson.has("action") ? optionJson.get("action").getAsString() : "NONE";
        String condition = optionJson.has("condition") ? optionJson.get("condition").getAsString() : "";
        int priority = optionJson.has("priority") ? optionJson.get("priority").getAsInt() : 0;

        DialogueOption option = new DialogueOption(optionText, nextNodeId, action, condition);
        option.setPriority(priority);

        // 加载命令
        if (optionJson.has("commands")) {
            JsonArray commandsArray = optionJson.getAsJsonArray("commands");
            for (int i = 0; i < commandsArray.size(); i++) {
                JsonObject commandJson = commandsArray.get(i).getAsJsonObject();
                DialogueCommand command = deserializeCommand(commandJson);
                option.getCommands().add(command);
            }
        }

        return option;
    }

    /**
     * 反序列化对话命令
     */
    private static DialogueCommand deserializeCommand(JsonObject commandJson) {
        String commandType = commandJson.has("type") ? commandJson.get("type").getAsString() : "";
        String commandArgument = commandJson.has("data") ? commandJson.get("data").getAsString() : "";
        int value = commandJson.has("value") ? commandJson.get("value").getAsInt() : 0;
        String variableName = commandJson.has("varName") ? commandJson.get("varName").getAsString() : "";
        String variableValue = commandJson.has("varValue") ? commandJson.get("varValue").getAsString() : "";

        DialogueCommand command = new DialogueCommand(commandType, commandArgument);
        command.setValue(value);
        command.setVariableName(variableName);
        command.setVariableValue(variableValue);

        return command;
    }

    /**
     * 反序列化图片数据
     */
    private static DialogueNode.ImageData deserializeImage(JsonObject imageJson) {
        String path = imageJson.has("path") ? imageJson.get("path").getAsString() : "";
        int x = imageJson.has("x") ? imageJson.get("x").getAsInt() : 0;
        int y = imageJson.has("y") ? imageJson.get("y").getAsInt() : 0;
        float scale = imageJson.has("scale") ? imageJson.get("scale").getAsFloat() : 1.0f;

        DialogueNode.ImageData image = new DialogueNode.ImageData(path, x, y);
        image.setScale(scale);

        return image;
    }

    /**
     * 获取对话数据文件夹
     */
    private static File getDialogueDirectory(ServerLevel level) {
        File worldDir = level.getServer().getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).toFile();
        return new File(worldDir, DIALOGUE_FOLDER);
    }

    /**
     * 将对话数据保存到JSON文件
     */
    public static boolean saveToJsonFile(Map<String, DialogueNode> dialogueMap, String fileName, ServerLevel level) {
        File dialogueDir = getDialogueDirectory(level);
        if (!dialogueDir.exists()) {
            dialogueDir.mkdirs();
        }

        File jsonFile = new File(dialogueDir, fileName);

        try {
            JsonObject root = new JsonObject();
            JsonObject metadata = new JsonObject();

            metadata.addProperty("version", "1.0");
            metadata.addProperty("nodeCount", dialogueMap.size());
            metadata.addProperty("exportTime", System.currentTimeMillis());

            root.add("metadata", metadata);

            JsonObject nodes = new JsonObject();

            for (Map.Entry<String, DialogueNode> entry : dialogueMap.entrySet()) {
                DialogueNode node = entry.getValue();
                JsonObject nodeJson = serializeNode(node);
                nodes.add(entry.getKey(), nodeJson);
            }

            root.add("nodes", nodes);

            try (Writer writer = new OutputStreamWriter(
                    new FileOutputStream(jsonFile), StandardCharsets.UTF_8)) {
                GSON.toJson(root, writer);
            }

            LOGGER.info("成功导出对话树到: " + jsonFile.getAbsolutePath() + ", 节点数: " + dialogueMap.size());
            return true;

        } catch (Exception e) {
            LOGGER.error("导出对话树失败: " + e.getMessage(), e);
            return false;
        }
    }

    /**
     * 序列化对话节点
     */
    private static JsonObject serializeNode(DialogueNode node) {
        JsonObject nodeJson = new JsonObject();

        nodeJson.addProperty("npcText", node.getNpcText());
        nodeJson.addProperty("speakerName", node.getSpeakerName());
        nodeJson.addProperty("priority", node.getPriority());

        // 序列化选项
        JsonArray optionsArray = new JsonArray();
        for (DialogueOption option : node.getOptions()) {
            optionsArray.add(serializeOption(option));
        }
        nodeJson.add("options", optionsArray);

        // 序列化图片
        JsonArray imagesArray = new JsonArray();
        for (DialogueNode.ImageData image : node.getImages()) {
            imagesArray.add(serializeImage(image));
        }
        nodeJson.add("images", imagesArray);

        // 序列化标签
        JsonArray tagsArray = new JsonArray();
        for (String tag : node.getTags()) {
            tagsArray.add(tag);
        }
        nodeJson.add("tags", tagsArray);

        return nodeJson;
    }

    /**
     * 序列化对话选项
     */
    private static JsonObject serializeOption(DialogueOption option) {
        JsonObject optionJson = new JsonObject();

        optionJson.addProperty("optionText", option.getOptionText());
        optionJson.addProperty("nextNodeId", option.getNextNodeId());
        optionJson.addProperty("action", option.getAction());
        optionJson.addProperty("condition", option.getCondition());
        optionJson.addProperty("priority", option.getPriority());

        // 序列化命令
        JsonArray commandsArray = new JsonArray();
        for (DialogueCommand command : option.getCommands()) {
            commandsArray.add(serializeCommand(command));
        }
        optionJson.add("commands", commandsArray);

        return optionJson;
    }

    /**
     * 序列化对话命令
     */
    private static JsonObject serializeCommand(DialogueCommand command) {
        JsonObject commandJson = new JsonObject();

        commandJson.addProperty("type", command.getCommandType());
        commandJson.addProperty("data", command.getCommandArgument());
        commandJson.addProperty("value", command.getValue());

        if (command.getVariableName() != null && !command.getVariableName().isEmpty()) {
            commandJson.addProperty("varName", command.getVariableName());
        }

        if (command.getVariableValue() != null && !command.getVariableValue().isEmpty()) {
            commandJson.addProperty("varValue", command.getVariableValue());
        }

        return commandJson;
    }

    /**
     * 序列化图片数据
     */
    private static JsonObject serializeImage(DialogueNode.ImageData image) {
        JsonObject imageJson = new JsonObject();

        imageJson.addProperty("path", image.getPath());
        imageJson.addProperty("x", image.getX());
        imageJson.addProperty("y", image.getY());
        imageJson.addProperty("scale", image.getScale());

        return imageJson;
    }
}
