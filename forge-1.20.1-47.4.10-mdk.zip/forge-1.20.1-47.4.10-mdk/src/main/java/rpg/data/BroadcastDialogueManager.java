package rpg.data;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraftforge.server.ServerLifecycleHooks;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import rpg.network.ModPacketHandler;
import rpg.network.OpenDialogueS2CPacket;
import rpg.network.SyncDialogueDataPacket;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.HashMap;

public class BroadcastDialogueManager {
    private static final Logger LOGGER = LogManager.getLogger();
    private static final BroadcastDialogueManager INSTANCE = new BroadcastDialogueManager();

    private boolean isBroadcastActive = false;
    private String currentBroadcastNodeId = null;
    private int broadcastNpcId = -1;
    private final Set<UUID> participants = new HashSet<>();
    private long lastActivityTime = 0;

    // 存储广播对话的节点数据
    private final Map<String, DialogueNode> broadcastNodes = new HashMap<>();

    public static BroadcastDialogueManager getInstance() {
        return INSTANCE;
    }

    /** 开始全局广播对话 */
    public boolean startBroadcast(int npcId, String startNodeId) {
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) {
            LOGGER.error("无法获取服务器实例");
            return false;
        }

        // 如果已经有广播在进行，先停止
        if (isBroadcastActive) {
            LOGGER.warn("检测到旧的广播对话，强制停止后重新开始");
            forceStopBroadcast();
        }

        // 【关键修改】从NPC实体加载对话数据
        broadcastNodes.clear();

        // 1. 尝试从NPC实体加载对话数据
        Entity npcEntity = server.getLevel(Level.OVERWORLD).getEntity(npcId);
        if (npcEntity == null) {
            LOGGER.error("无法找到NPC实体，实体ID: {}", npcId);
            return false;
        }

        Map<String, DialogueNode> npcNodes = NpcDialogueLoader.loadNodesFromEntity(npcEntity);
        if (npcNodes != null && !npcNodes.isEmpty()) {
            broadcastNodes.putAll(npcNodes);
            LOGGER.info("从NPC实体 {} 加载了 {} 个对话节点", npcId, npcNodes.size());
        } else {
            // 2. 如果NPC没有对话数据，从全局对话中查找
            Map<String, DialogueNode> globalNodes = DialogueLoader.getAllNodes();
            if (globalNodes != null && !globalNodes.isEmpty()) {
                broadcastNodes.putAll(globalNodes);
                LOGGER.info("从全局对话加载了 {} 个对话节点", globalNodes.size());
            } else {
                LOGGER.error("NPC {} 没有对话数据，且全局对话为空", npcId);
                return false;
            }
        }

        // 检查起始节点是否存在
        if (!broadcastNodes.containsKey(startNodeId)) {
            LOGGER.error("起始节点 {} 不存在于广播节点中", startNodeId);
            LOGGER.error("可用的节点: {}", broadcastNodes.keySet());
            return false;
        }

        isBroadcastActive = true;
        currentBroadcastNodeId = startNodeId;
        broadcastNpcId = npcId;
        lastActivityTime = System.currentTimeMillis();
        participants.clear();

        // 添加所有在线玩家
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            participants.add(player.getUUID());
        }

        LOGGER.info("启动全局广播对话：NPC ID={}, 起始节点={}, 参与者={}人, 总节点数={}",
                npcId, startNodeId, participants.size(), broadcastNodes.size());

        // 【关键】先同步节点数据给所有客户端
        syncNodesToAllClients(npcId);

        // 然后发送起始节点
        boolean success = broadcastNodeToAll(startNodeId, npcId);

        if (success) {
            LOGGER.info("广播对话启动成功，已发送给所有玩家");
        } else {
            LOGGER.error("广播对话启动失败");
            forceStopBroadcast();
            return false;
        }

        return true;
    }

    /** 同步节点数据给所有客户端 */
    private void syncNodesToAllClients(int npcId) {
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null || broadcastNodes.isEmpty()) return;

        // 创建同步包
        SyncDialogueDataPacket syncPacket = new SyncDialogueDataPacket(broadcastNodes, npcId);

        // 发送给所有参与者
        for (UUID playerUUID : participants) {
            ServerPlayer player = server.getPlayerList().getPlayer(playerUUID);
            if (player != null) {
                try {
                    // 发送节点同步包给客户端
                    ModPacketHandler.sendToPlayer(syncPacket, player);
                    LOGGER.info("已发送节点同步包给玩家: {}, 节点数: {}", player.getName().getString(), broadcastNodes.size());
                } catch (Exception e) {
                    LOGGER.error("发送节点同步包失败", e);
                }
            }
        }
    }
    /** 推进到下一个节点 */
    public void advanceBroadcast(String nextNodeId) {
        if (!isBroadcastActive) {
            LOGGER.warn("尝试推进非活跃的广播对话");
            return;
        }

        lastActivityTime = System.currentTimeMillis();
        currentBroadcastNodeId = nextNodeId;

        if ("END".equalsIgnoreCase(nextNodeId)) {
            LOGGER.info("广播对话到达结束节点");
            stopBroadcast();
            return;
        }

        LOGGER.info("广播对话推进到节点：{}", nextNodeId);
        broadcastNodeToAll(nextNodeId, broadcastNpcId);
    }

    /** 正常停止广播 */
    public void stopBroadcast() {
        if (!isBroadcastActive) return;

        LOGGER.info("全局广播对话正常停止");

        // 发送END包给所有参与者
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server != null) {
            for (UUID playerUUID : participants) {
                ServerPlayer player = server.getPlayerList().getPlayer(playerUUID);
                if (player != null) {
                    try {
                        OpenDialogueS2CPacket packet = new OpenDialogueS2CPacket("END", -1, true);
                        ModPacketHandler.sendToPlayer(packet, player);
                    } catch (Exception e) {
                        LOGGER.error("发送结束包给玩家失败", e);
                    }
                }
            }
        }

        cleanup();
    }

    /** 强制停止广播（重置所有状态） */
    public void forceStopBroadcast() {
        LOGGER.info("强制停止广播对话");
        cleanup();
    }

    /** 清理所有资源 */
    private void cleanup() {
        isBroadcastActive = false;
        currentBroadcastNodeId = null;
        broadcastNpcId = -1;
        participants.clear();
        broadcastNodes.clear();
        lastActivityTime = 0;
    }

    /** 检查并清理超时的广播对话 */
    public void checkTimeout() {
        if (!isBroadcastActive) return;

        long currentTime = System.currentTimeMillis();
        // 30分钟超时（30 * 60 * 1000 = 1,800,000）
        if (currentTime - lastActivityTime > 1800000) {
            LOGGER.warn("广播对话超时，自动清理");
            forceStopBroadcast();
        }
    }

    /** 添加新玩家到广播对话 */
    public void addPlayer(ServerPlayer player) {
        if (!isBroadcastActive) return;

        UUID playerUUID = player.getUUID();
        if (!participants.contains(playerUUID)) {
            participants.add(playerUUID);
            LOGGER.info("添加新玩家到广播对话: {}", player.getName().getString());

            // 先同步所有节点数据给新玩家
            syncNodesToPlayer(player, broadcastNpcId);

            // 然后同步当前对话节点
            if (currentBroadcastNodeId != null && !"END".equals(currentBroadcastNodeId)) {
                sendNodeToPlayer(player, currentBroadcastNodeId, broadcastNpcId);
            }
        }
    }

    /** 移除玩家（玩家退出时调用） */
    public void removePlayer(ServerPlayer player) {
        participants.remove(player.getUUID());
    }

    /** 广播节点给所有参与者 */
    private boolean broadcastNodeToAll(String nodeId, int npcId) {
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) {
            LOGGER.error("无法获取服务器实例");
            return false;
        }

        int successCount = 0;
        int totalPlayers = participants.size();

        LOGGER.info("准备向 {} 名玩家广播节点: {}", totalPlayers, nodeId);

        // 获取节点数据
        DialogueNode node = broadcastNodes.get(nodeId);
        if (node == null) {
            LOGGER.error("无法找到广播节点: {}", nodeId);
            LOGGER.error("可用的节点: {}", broadcastNodes.keySet());
            return false;
        }

        for (UUID playerUUID : participants) {
            ServerPlayer player = server.getPlayerList().getPlayer(playerUUID);
            if (player != null) {
                try {
                    // 【关键修改】发送节点前，创建一个节点的副本并发送
                    // 这样客户端就能收到完整的节点数据
                    sendNodeToPlayer(player, nodeId, npcId, node);
                    successCount++;
                    LOGGER.debug("已发送对话节点 {} 给玩家 {}", nodeId, player.getName().getString());
                } catch (Exception e) {
                    LOGGER.error("发送对话节点给玩家 {} 失败: {}", player.getName().getString(), e.getMessage(), e);
                }
            } else {
                LOGGER.warn("玩家 {} 不在线，跳过发送", playerUUID);
            }
        }

        LOGGER.info("广播节点 {} 发送给 {}/{} 名玩家", nodeId, successCount, totalPlayers);
        return successCount > 0;
    }

    /** 发送节点给单个玩家（带节点数据） */
    private boolean sendNodeToPlayer(ServerPlayer player, String nodeId, int npcId, DialogueNode node) {
        try {
            // 在发送网络包之前，先将节点数据通过其他方式同步到客户端
            // 我们假设客户端已经有了节点数据（从之前的同步或实体加载）

            OpenDialogueS2CPacket packet = new OpenDialogueS2CPacket(nodeId, npcId, true);

            // 使用主线程发送
            player.getServer().execute(() -> {
                try {
                    ModPacketHandler.sendToPlayer(packet, player);
                    LOGGER.debug("已发送对话节点 {} 给玩家 {}", nodeId, player.getName().getString());
                } catch (Exception e) {
                    LOGGER.error("发送网络包失败", e);
                }
            });

            return true;
        } catch (Exception e) {
            LOGGER.error("发送对话节点给玩家 {} 失败: {}", player.getName().getString(), e.getMessage(), e);
            return false;
        }
    }

    /** 发送节点给单个玩家（重载版本，不带节点数据） */
    private boolean sendNodeToPlayer(ServerPlayer player, String nodeId, int npcId) {
        DialogueNode node = broadcastNodes.get(nodeId);
        if (node != null) {
            return sendNodeToPlayer(player, nodeId, npcId, node);
        }
        return false;
    }

    /** 获取广播状态（用于调试） */
    public String getStatus() {
        return String.format(
                "广播对话状态: %s, NPC ID: %d, 当前节点: %s, 参与者: %d人, 节点总数: %d, 最后活动: %d秒前",
                isBroadcastActive ? "活跃" : "非活跃",
                broadcastNpcId,
                currentBroadcastNodeId != null ? currentBroadcastNodeId : "无",
                participants.size(),
                broadcastNodes.size(),
                lastActivityTime > 0 ? (System.currentTimeMillis() - lastActivityTime) / 1000 : 0
        );
    }

    /** 重置管理器（用于调试和测试） */
    public void reset() {
        LOGGER.info("重置广播对话管理器");
        cleanup();
    }

    // Getters
    public boolean isBroadcastActive() {
        return isBroadcastActive;
    }

    public String getCurrentBroadcastNodeId() {
        return currentBroadcastNodeId;
    }

    public int getBroadcastNpcId() {
        return broadcastNpcId;
    }

    public Set<UUID> getParticipants() {
        return new HashSet<>(participants);
    }

    public Map<String, DialogueNode> getBroadcastNodes() {
        return new HashMap<>(broadcastNodes);
    }

    /** 同步节点数据给单个玩家 */
    private void syncNodesToPlayer(ServerPlayer player, int npcId) {
        if (broadcastNodes.isEmpty()) return;
        
        // 创建同步包
        SyncDialogueDataPacket syncPacket = new SyncDialogueDataPacket(broadcastNodes, npcId);
        
        try {
            // 发送节点同步包给客户端
            ModPacketHandler.sendToPlayer(syncPacket, player);
            LOGGER.info("已发送节点同步包给新玩家: {}, 节点数: {}", player.getName().getString(), broadcastNodes.size());
        } catch (Exception e) {
            LOGGER.error("发送节点同步包给新玩家失败", e);
        }
    }}