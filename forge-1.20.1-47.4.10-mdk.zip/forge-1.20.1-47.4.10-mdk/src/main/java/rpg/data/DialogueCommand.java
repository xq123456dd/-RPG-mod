package rpg.data;

import net.minecraft.nbt.CompoundTag;

public class DialogueCommand {

    private String commandType;
    private String commandArgument;
    private int value;
    private String variableName; // 新增：用于变量操作的变量名
    private String variableValue; // 新增：用于变量操作的值

    // 无参构造函数 (用于反序列化)
    public DialogueCommand() {
        this.commandType = "";
        this.commandArgument = "";
        this.value = 0;
        this.variableName = "";
        this.variableValue = "";
    }

    // 有参构造函数 (用于客户端创建新命令/Loader)
    public DialogueCommand(String commandType, String commandArgument) {
        this.commandType = commandType;
        this.commandArgument = commandArgument;
        this.value = 0;
        this.variableName = "";
        this.variableValue = "";
    }

    // 变量操作构造函数
    public DialogueCommand(String commandType, String variableName, String variableValue) {
        this.commandType = commandType;
        this.commandArgument = "";
        this.value = 0;
        this.variableName = variableName;
        this.variableValue = variableValue;
    }

    // --- Getters ---
    public String getCommandType() {
        return commandType;
    }
    public String getCommandArgument() {
        return commandArgument;
    }
    public int getValue() {
        return value;
    }
    public String getVariableName() {
        return variableName;
    }
    public String getVariableValue() {
        return variableValue;
    }

    // --- Setters ---
    public void setCommandType(String commandType) {
        this.commandType = commandType;
    }
    public void setCommandArgument(String commandArgument) {
        this.commandArgument = commandArgument;
    }
    public void setValue(int value) {
        this.value = value;
    }
    public void setVariableName(String variableName) {
        this.variableName = variableName;
    }
    public void setVariableValue(String variableValue) {
        this.variableValue = variableValue;
    }

    // --- NBT 序列化/反序列化 ---
    public CompoundTag serializeNBT() {
        CompoundTag tag = new CompoundTag();
        tag.putString("type", this.commandType);
        tag.putString("data", this.commandArgument);
        tag.putInt("value", this.value);

        if (this.variableName != null && !this.variableName.isEmpty()) {
            tag.putString("varName", this.variableName);
        }

        if (this.variableValue != null && !this.variableValue.isEmpty()) {
            tag.putString("varValue", this.variableValue);
        }

        return tag;
    }

    public static DialogueCommand deserializeNBT(CompoundTag tag) {
        DialogueCommand command = new DialogueCommand();
        command.setCommandType(tag.getString("type"));
        command.setCommandArgument(tag.getString("data"));
        command.setValue(tag.getInt("value"));

        if (tag.contains("varName")) {
            command.setVariableName(tag.getString("varName"));
        }

        if (tag.contains("varValue")) {
            command.setVariableValue(tag.getString("varValue"));
        }

        return command;
    }

    /**
     * 是否是变量操作命令
     */
    public boolean isVariableCommand() {
        return commandType.startsWith("VAR_") ||
                commandType.equals("SET_VARIABLE") ||
                commandType.equals("ADD_VARIABLE") ||
                commandType.equals("REMOVE_VARIABLE");
    }
}