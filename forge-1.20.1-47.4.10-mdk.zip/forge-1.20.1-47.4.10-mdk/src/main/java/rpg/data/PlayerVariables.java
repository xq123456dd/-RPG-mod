package rpg.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.player.Player;

import java.util.*;

/**
 * 玩家变量管理系统
 * 存储和跟踪玩家在对话中的状态和变量
 */
public class PlayerVariables {

    public enum VariableType {
        INTEGER, BOOLEAN, STRING, FLOAT
    }

    public static class Variable {
        private final String name;
        private final VariableType type;
        private Object value;

        public Variable(String name, VariableType type, Object value) {
            this.name = name;
            this.type = type;
            this.value = value;
        }

        public String getName() { return name; }
        public VariableType getType() { return type; }
        public Object getValue() { return value; }

        public void setValue(Object value) {
            if (isValidValueForType(value, type)) {
                this.value = value;
            } else {
                throw new IllegalArgumentException("Invalid value type for variable " + name);
            }
        }

        private static boolean isValidValueForType(Object value, VariableType type) {
            switch (type) {
                case INTEGER: return value instanceof Integer;
                case BOOLEAN: return value instanceof Boolean;
                case STRING: return value instanceof String;
                case FLOAT: return value instanceof Float || value instanceof Double;
                default: return false;
            }
        }

        public CompoundTag serializeNBT() {
            CompoundTag tag = new CompoundTag();
            tag.putString("name", name);
            tag.putString("type", type.name());
            switch (type) {
                case INTEGER -> tag.putInt("value", (Integer) value);
                case BOOLEAN -> tag.putBoolean("value", (Boolean) value);
                case STRING -> tag.putString("value", (String) value);
                case FLOAT -> tag.putFloat("value", ((Number) value).floatValue());
            }
            return tag;
        }

        public static Variable deserializeNBT(CompoundTag tag) {
            String name = tag.getString("name");
            VariableType type = VariableType.valueOf(tag.getString("type"));
            Object value = switch (type) {
                case INTEGER -> tag.getInt("value");
                case BOOLEAN -> tag.getBoolean("value");
                case STRING -> tag.getString("value");
                case FLOAT -> tag.getFloat("value");
            };
            return new Variable(name, type, value);
        }
    }

    private final UUID playerId;
    private final Map<String, Variable> variables = new HashMap<>();

    public PlayerVariables(UUID playerId) {
        this.playerId = playerId;
    }

    /**
     * 设置变量（覆盖或新建）
     */
    public void setVariable(String name, VariableType type, Object value) {
        if (!Variable.isValidValueForType(value, type)) {
            throw new IllegalArgumentException("Invalid value " + value + " for type " + type);
        }
        variables.put(name, new Variable(name, type, value));
    }

    /**
     * 获取变量值
     */
    public Object getVariable(String name) {
        Variable var = variables.get(name);
        return var != null ? var.getValue() : null;
    }

    /**
     * 检查变量是否存在
     */
    public boolean hasVariable(String name) {
        return variables.containsKey(name);
    }

    /**
     * 获取变量类型（新增方法，修复编译错误）
     */
    public VariableType getType(String name) {
        Variable var = variables.get(name);
        return var != null ? var.getType() : null;
    }

    /**
     * 移除变量（新增方法，修复编译错误）
     */
    public void removeVariable(String name) {
        variables.remove(name);
    }

    /**
     * 获取所有变量名
     */
    public Set<String> getAllVariableNames() {
        return variables.keySet();
    }

    /**
     * 序列化为NBT
     */
    public CompoundTag serializeNBT() {
        CompoundTag tag = new CompoundTag();
        tag.putUUID("playerId", playerId);

        ListTag variablesTag = new ListTag();
        for (Variable var : variables.values()) {
            variablesTag.add(var.serializeNBT());
        }
        tag.put("variables", variablesTag);

        return tag;
    }

    /**
     * 从NBT反序列化
     */
    public static PlayerVariables deserializeNBT(CompoundTag tag) {
        UUID playerId = tag.getUUID("playerId");
        PlayerVariables pv = new PlayerVariables(playerId);

        if (tag.contains("variables")) {
            ListTag variablesTag = tag.getList("variables", Tag.TAG_COMPOUND);
            for (int i = 0; i < variablesTag.size(); i++) {
                CompoundTag varTag = variablesTag.getCompound(i);
                Variable var = Variable.deserializeNBT(varTag);
                pv.variables.put(var.getName(), var);
            }
        }

        return pv;
    }

    /**
     * 获取玩家的变量管理器
     */
    public static PlayerVariables get(Player player) {
        return PlayerVariableManager.getInstance().getPlayerVariables(player);
    }
}