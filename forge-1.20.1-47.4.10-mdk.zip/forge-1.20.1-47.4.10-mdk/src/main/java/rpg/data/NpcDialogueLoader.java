package rpg.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.Entity;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.HashMap;
import java.util.Map;

public class NpcDialogueLoader {
    private static final Logger LOGGER = LogManager.getLogger();

    /**
     * 从实体的NBT中加载所有对话节点
     */
    public static Map<String, DialogueNode> loadNodesFromEntity(Entity entity) {
        Map<String, DialogueNode> nodeMap = new HashMap<>();

        if (entity == null) {
            return nodeMap;
        }

        CompoundTag entityNbt = entity.getPersistentData();

        // 检查是否有对话数据
        if (!entityNbt.contains("rpg_dialogue_data")) {
            return nodeMap;
        }

        CompoundTag dialogueData = entityNbt.getCompound("rpg_dialogue_data");

        if (dialogueData.isEmpty()) {
            return nodeMap;
        }

        // 获取节点数据
        if (dialogueData.contains("DialogueNodes")) {
            CompoundTag nodesTag = dialogueData.getCompound("DialogueNodes");

            for (String nodeId : nodesTag.getAllKeys()) {
                CompoundTag nodeTag = nodesTag.getCompound(nodeId);
                DialogueNode node = DialogueNode.deserializeNBT(nodeTag);
                if (node != null) {
                    nodeMap.put(nodeId, node);
                }
            }
        }

        return nodeMap;
    }

    /**
     * 检查实体是否有对话数据
     */
    public static boolean hasDialogueData(Entity entity) {
        if (entity == null) return false;
        CompoundTag entityNbt = entity.getPersistentData();
        return entityNbt.contains("rpg_dialogue_data");
    }

    /**
     * 获取实体的起始对话节点（默认第一个节点或"START"节点）
     */
    public static DialogueNode getStartNodeFromEntity(Entity entity) {
        Map<String, DialogueNode> nodes = loadNodesFromEntity(entity);
        if (nodes.isEmpty()) {
            return null;
        }

        CompoundTag persistentData = entity.getPersistentData();
        String startIdKey = "rpg_dialogue_start_id";

        // 1. 优先使用编辑器保存的起始节点ID
        if (persistentData.contains(startIdKey, Tag.TAG_STRING)) {
            String savedStartId = persistentData.getString(startIdKey).trim();
            if (!savedStartId.isEmpty() && nodes.containsKey(savedStartId)) {
                LOGGER.info("对话使用保存的起始节点: {}", savedStartId);
                return nodes.get(savedStartId);
            } else {
                LOGGER.warn("保存的起始节点ID '{}' 不存在或为空，回退到默认逻辑", savedStartId);
            }
        }

        // 2. 回退：查找传统 "START" 节点（兼容旧版本数据）
        if (nodes.containsKey("START")) {
            LOGGER.info("未找到有效起始ID，使用传统 START 节点");
            return nodes.get("START");
        }

        // 3. 最后回退：返回任意第一个节点
        DialogueNode first = nodes.values().stream().findFirst().orElse(null);
        if (first != null) {
            LOGGER.info("无 START 节点，使用第一个节点作为起始: {}", first.getNodeId());
        }
        return first;
    }
}