package rpg.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 管理所有玩家的变量
 */
public class PlayerVariableManager {

    private static final PlayerVariableManager INSTANCE = new PlayerVariableManager();

    // 内存中的玩家变量缓存
    private final Map<UUID, PlayerVariables> playerVariables = new HashMap<>();

    // 脏标记，用于优化保存
    private final Map<UUID, Boolean> dirtyFlags = new HashMap<>();

    public static PlayerVariableManager getInstance() {
        return INSTANCE;
    }

    /**
     * 获取玩家的变量管理器
     */
    public PlayerVariables getPlayerVariables(Player player) {
        UUID playerId = player.getUUID();

        // 如果内存中没有，从NBT加载
        if (!playerVariables.containsKey(playerId)) {
            loadPlayerVariables(player);
        }

        return playerVariables.get(playerId);
    }

    /**
     * 从玩家NBT加载变量
     */
    private void loadPlayerVariables(Player player) {
        UUID playerId = player.getUUID();
        CompoundTag playerData = player.getPersistentData();

        if (playerData.contains("rpg_dialogue_variables")) {
            CompoundTag variablesTag = playerData.getCompound("rpg_dialogue_variables");
            PlayerVariables pv = PlayerVariables.deserializeNBT(variablesTag);
            playerVariables.put(playerId, pv);
            dirtyFlags.put(playerId, false);

            System.out.println("加载玩家变量: " + playerId + ", 变量数: " + pv.getAllVariableNames().size());
        } else {
            // 如果没有变量，初始化一个空的
            playerVariables.put(playerId, new PlayerVariables(playerId));
            dirtyFlags.put(playerId, false);
        }
    }

    /**
     * 保存玩家变量到NBT
     */
    private void savePlayerVariables(Player player) {
        UUID playerId = player.getUUID();
        PlayerVariables pv = playerVariables.get(playerId);

        if (pv != null) {
            CompoundTag variablesTag = pv.serializeNBT();
            player.getPersistentData().put("rpg_dialogue_variables", variablesTag);
            dirtyFlags.put(playerId, false);

            System.out.println("保存玩家变量: " + playerId + ", 变量数: " + pv.getAllVariableNames().size());
        }
    }

    /**
     * 标记玩家变量为脏（需要保存）
     */
    public void markDirty(Player player) {
        UUID playerId = player.getUUID();
        dirtyFlags.put(playerId, true);
    }

    /**
     * 定期保存脏数据（可在服务器tick中调用）
     */
    public void saveDirtyData() {
        for (Map.Entry<UUID, Boolean> entry : dirtyFlags.entrySet()) {
            if (entry.getValue()) {
                UUID playerId = entry.getKey();
                // 假设可以通过 MinecraftServer 获取玩家（实际需注入服务器实例）
                // 这里简化，实际项目中需替换为真实获取方式，如从 World 或 Mod 主类
                // 示例：Player player = server.getPlayerManager().getPlayer(playerId);
                // 为演示，打印日志
                System.out.println("玩家变量已标记为脏，需要保存: " + playerId);
                // 如果有 player，调用 savePlayerVariables(player);
            }
        }
    }

    /**
     * 玩家登出时保存数据
     */
    public void onPlayerLogout(ServerPlayer player) {
        if (playerVariables.containsKey(player.getUUID())) {
            savePlayerVariables(player);
        }
    }

    /**
     * 清除玩家变量（用于测试或重置）
     */
    public void clearPlayerVariables(Player player) {
        UUID playerId = player.getUUID();
        playerVariables.remove(playerId);
        dirtyFlags.remove(playerId);

        player.getPersistentData().remove("rpg_dialogue_variables");
        System.out.println("清除玩家变量: " + playerId);
    }
}