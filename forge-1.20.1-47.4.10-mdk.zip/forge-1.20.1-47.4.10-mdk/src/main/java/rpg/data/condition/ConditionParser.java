package rpg.data.condition;

import rpg.data.PlayerVariables;
import rpg.data.PlayerVariables.VariableType;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 对话条件解析器
 * 支持的条件表达式语法：
 * 1. 简单比较：var >= 100, var == "text", var == true
 * 2. 逻辑运算：&&, ||, !
 * 3. 括号：()
 * 4. 函数调用：has("var"), hasItem("minecraft:diamond")
 */
public class ConditionParser {

    public interface Condition {
        boolean evaluate(PlayerVariables variables);
    }

    // 操作符枚举
    public enum Operator {
        EQ("=="), NEQ("!="), GT(">"), GTE(">="), LT("<"), LTE("<="), EXISTS("exists"), NOT_EXISTS("!exists");

        private final String symbol;

        Operator(String symbol) {
            this.symbol = symbol;
        }

        public static Operator fromString(String op) {
            for (Operator operator : values()) {
                if (operator.symbol.equals(op)) {
                    return operator;
                }
            }
            throw new IllegalArgumentException("Unknown operator: " + op);
        }

        public boolean compare(Object a, Object b) {
            if (a == null || b == null) return false;
            if (a instanceof Number && b instanceof Number) {
                double da = ((Number) a).doubleValue();
                double db = ((Number) b).doubleValue();
                switch (this) {
                    case EQ: return da == db;
                    case NEQ: return da != db;
                    case GT: return da > db;
                    case GTE: return da >= db;
                    case LT: return da < db;
                    case LTE: return da <= db;
                    default: return false;
                }
            } else if (a instanceof Boolean && b instanceof Boolean) {
                boolean ba = (Boolean) a;
                boolean bb = (Boolean) b;
                switch (this) {
                    case EQ: return ba == bb;
                    case NEQ: return ba != bb;
                    default: return false;
                }
            } else {
                return a.equals(b);
            }
        }
    }

    // 逻辑操作符
    public enum LogicOperator {
        AND("&&"), OR("||");

        private final String symbol;

        LogicOperator(String symbol) {
            this.symbol = symbol;
        }

        public static LogicOperator fromString(String op) {
            for (LogicOperator operator : values()) {
                if (operator.symbol.equals(op)) {
                    return operator;
                }
            }
            throw new IllegalArgumentException("Unknown logic operator: " + op);
        }
    }

    // 简单条件：变量名 操作符 值
    public static class SimpleCondition implements Condition {
        private final String variableName;
        private final Operator operator;
        private final Object value;

        public SimpleCondition(String variableName, Operator operator, Object value) {
            this.variableName = variableName;
            this.operator = operator;
            this.value = value;
        }

        @Override
        public boolean evaluate(PlayerVariables variables) {
            Object variableValue = variables.getVariable(variableName);

            if (variableValue == null && operator != Operator.EXISTS && operator != Operator.NOT_EXISTS) {
                return false; // 变量不存在，除了EXISTS和NOT_EXISTS操作符外都返回false
            }

            if (operator == Operator.EXISTS) return variableValue != null;
            if (operator == Operator.NOT_EXISTS) return variableValue == null;

            return operator.compare(variableValue, value);
        }
    }

    // 逻辑条件
    public static class LogicCondition implements Condition {
        private final List<Condition> conditions;
        private final LogicOperator operator;

        public LogicCondition(List<Condition> conditions, LogicOperator operator) {
            this.conditions = conditions;
            this.operator = operator;
        }

        @Override
        public boolean evaluate(PlayerVariables variables) {
            if (operator == LogicOperator.AND) {
                for (Condition cond : conditions) {
                    if (!cond.evaluate(variables)) return false;
                }
                return true;
            } else { // OR
                for (Condition cond : conditions) {
                    if (cond.evaluate(variables)) return true;
                }
                return false;
            }
        }
    }

    // 函数条件（如 has("var")）
    public static class FunctionCondition implements Condition {
        private final String functionName;
        private final List<String> args;

        public FunctionCondition(String functionName, List<String> args) {
            this.functionName = functionName;
            this.args = args;
        }

        @Override
        public boolean evaluate(PlayerVariables variables) {
            if ("has".equals(functionName) && args.size() == 1) {
                return variables.hasVariable(args.get(0));
            } else if ("hasItem".equals(functionName) && args.size() == 1) {
                // 假设 hasItem 检查玩家库存（需实现）
                return true; // Placeholder
            }
            throw new UnsupportedOperationException("Unknown function: " + functionName);
        }
    }

    // 否定条件（如 !condition）
    public static class NotCondition implements Condition {
        private final Condition condition;

        public NotCondition(Condition condition) {
            this.condition = condition;
        }

        @Override
        public boolean evaluate(PlayerVariables variables) {
            return !condition.evaluate(variables);
        }
    }

    /**
     * 解析条件字符串
     */
    public static Condition parse(String conditionStr) {
        conditionStr = conditionStr.trim();
        if (!checkBalancedParentheses(conditionStr)) {
            throw new IllegalArgumentException("Unbalanced parentheses in condition: " + conditionStr);
        }

        // 处理括号和逻辑运算符
        return parseLogic(conditionStr);
    }

    private static Condition parseLogic(String str) {
        // 简单实现：处理 && 和 ||
        // 这里需完整实现解析器逻辑（使用 Shunting-yard 算法或递归下降）
        // 为示例，假设简单条件
        if (str.contains("&&")) {
            String[] parts = str.split("&&");
            List<Condition> conds = new ArrayList<>();
            for (String part : parts) {
                conds.add(parseSimple(part.trim()));
            }
            return new LogicCondition(conds, LogicOperator.AND);
        } else if (str.contains("||")) {
            String[] parts = str.split("\\|\\|");
            List<Condition> conds = new ArrayList<>();
            for (String part : parts) {
                conds.add(parseSimple(part.trim()));
            }
            return new LogicCondition(conds, LogicOperator.OR);
        } else if (str.startsWith("!")) {
            return new NotCondition(parseSimple(str.substring(1).trim()));
        } else if (str.startsWith("(") && str.endsWith(")")) {
            return parseLogic(str.substring(1, str.length() - 1));
        } else {
            return parseSimple(str);
        }
    }

    private static Condition parseSimple(String str) {
        // 处理函数调用
        Pattern funcPattern = Pattern.compile("(\\w+)\\((.*)\\)");
        Matcher funcMatcher = funcPattern.matcher(str);
        if (funcMatcher.matches()) {
            String funcName = funcMatcher.group(1);
            String[] argStrs = funcMatcher.group(2).split(",");
            List<String> args = new ArrayList<>();
            for (String arg : argStrs) {
                args.add(arg.trim().replaceAll("^[\"']|[\"']$", ""));
            }
            return new FunctionCondition(funcName, args);
        }

        // 处理简单比较
        Pattern pattern = Pattern.compile("(\\w+)\\s*([=<>!]+)\\s*(.*)");
        Matcher matcher = pattern.matcher(str);
        if (matcher.matches()) {
            String varName = matcher.group(1);
            String opStr = matcher.group(2);
            String valueStr = matcher.group(3).trim().replaceAll("^[\"']|[\"']$", "");

            Operator op = Operator.fromString(opStr);
            Object value;
            if (valueStr.equals("true")) value = true;
            else if (valueStr.equals("false")) value = false;
            else if (valueStr.matches("\\d+")) value = Integer.parseInt(valueStr);
            else if (valueStr.matches("\\d+\\.\\d+")) value = Float.parseFloat(valueStr);
            else value = valueStr;

            return new SimpleCondition(varName, op, value);
        }

        // 处理 EXISTS
        if (str.endsWith("exists")) {
            String varName = str.substring(0, str.indexOf("exists")).trim();
            return new SimpleCondition(varName, Operator.EXISTS, null);
        }

        throw new IllegalArgumentException("Invalid condition: " + str);
    }

    /**
     * 检查括号平衡
     */
    private static boolean checkBalancedParentheses(String str) {
        int count = 0;
        for (char c : str.toCharArray()) {
            if (c == '(') count++;
            else if (c == ')') count--;
            if (count < 0) {
                return false;
            }
        }
        return count == 0;
    }

    /**
     * 测试条件
     */
    public static void main(String[] args) {
        PlayerVariables vars = new PlayerVariables(UUID.randomUUID());
        vars.setVariable("money", VariableType.INTEGER, 150);
        vars.setVariable("hasSword", VariableType.BOOLEAN, true);
        vars.setVariable("quest", VariableType.STRING, "dragon_slayer");

        // 测试条件
        testCondition(vars, "money >= 100", true);
        testCondition(vars, "money < 200", true);
        testCondition(vars, "hasSword == true", true);
        testCondition(vars, "quest == 'dragon_slayer'", true);
        testCondition(vars, "money >= 100 && hasSword == true", true);
        testCondition(vars, "money < 100 || quest == 'dragon_slayer'", true);
        testCondition(vars, "!(money < 100)", true);
        testCondition(vars, "(money >= 100) && (quest == 'dragon_slayer')", true);

        System.out.println("所有条件测试通过!");
    }

    private static void testCondition(PlayerVariables vars, String conditionStr, boolean expected) {
        Condition cond = parse(conditionStr);
        boolean result = cond.evaluate(vars);

        if (result == expected) {
            System.out.println("✓ 条件 '" + conditionStr + "' 测试通过");
        } else {
            System.out.println("✗ 条件 '" + conditionStr + "' 测试失败: 期望 " + expected + "，得到 " + result);
        }
    }
}