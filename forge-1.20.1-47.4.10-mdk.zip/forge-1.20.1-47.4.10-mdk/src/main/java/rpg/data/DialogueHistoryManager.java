package rpg.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

import java.util.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 对话历史管理器 - 记录玩家的对话历史
 */
public class DialogueHistoryManager {

    private static final Logger LOGGER = LogManager.getLogger();

    public static class DialogueHistoryEntry {
        private final String npcName;
        private final String nodeId;
        private final String npcText;
        private final String selectedOption;
        private final long timestamp;

        public DialogueHistoryEntry(String npcName, String nodeId, String npcText, String selectedOption) {
            this.npcName = npcName;
            this.nodeId = nodeId;
            this.npcText = npcText;
            this.selectedOption = selectedOption;
            this.timestamp = System.currentTimeMillis();
        }

        public DialogueHistoryEntry(String npcName, String nodeId, String npcText, String selectedOption, long timestamp) {
            this.npcName = npcName;
            this.nodeId = nodeId;
            this.npcText = npcText;
            this.selectedOption = selectedOption;
            this.timestamp = timestamp;
        }

        // Getter
        public String getNpcName() { return npcName; }
        public String getNodeId() { return nodeId; }
        public String getNpcText() { return npcText; }
        public String getSelectedOption() { return selectedOption; }
        public long getTimestamp() { return timestamp; }

        public CompoundTag serializeNBT() {
            CompoundTag tag = new CompoundTag();
            tag.putString("npcName", npcName);
            tag.putString("nodeId", nodeId);
            if (npcText != null) tag.putString("npcText", npcText);
            if (selectedOption != null) tag.putString("selectedOption", selectedOption);
            tag.putLong("timestamp", timestamp);
            return tag;
        }

        public static DialogueHistoryEntry deserializeNBT(CompoundTag tag) {
            return new DialogueHistoryEntry(
                    tag.getString("npcName"),
                    tag.getString("nodeId"),
                    tag.contains("npcText") ? tag.getString("npcText") : null,
                    tag.contains("selectedOption") ? tag.getString("selectedOption") : null,
                    tag.getLong("timestamp")
            );
        }
    }

    private static final DialogueHistoryManager INSTANCE = new DialogueHistoryManager();

    // 内存缓存：玩家UUID -> 历史列表
    private final Map<UUID, List<DialogueHistoryEntry>> playerHistories = new HashMap<>();

    // 每玩家最大历史条数，防止内存爆炸
    private static final int MAX_HISTORY_PER_PLAYER = 200;

    public static DialogueHistoryManager getInstance() {
        return INSTANCE;
    }

    /**
     * 添加一条历史记录（服务器端调用）
     */
    public void addHistory(ServerPlayer player, String npcName, String nodeId, String npcText, String selectedOption) {
        UUID playerId = player.getUUID();
        List<DialogueHistoryEntry> history = playerHistories.computeIfAbsent(playerId, k -> new ArrayList<>());

        history.add(new DialogueHistoryEntry(npcName, nodeId, npcText, selectedOption));

        // 限制大小
        if (history.size() > MAX_HISTORY_PER_PLAYER) {
            history.remove(0);
        }

        // 立即保存（或标记脏，后续定期保存）
        savePlayerHistory(player);
        LOGGER.debug("添加对话历史: {} 与 {} (选项: {})", player.getName().getString(), npcName, selectedOption);
    }

    /**
     * 获取玩家所有历史记录（客户端/服务器均可，自动加载）
     */
    public List<DialogueHistoryEntry> getAllHistory() {
        Player player = getCurrentPlayer();
        if (player == null) return Collections.emptyList();

        UUID playerId = player.getUUID();
        return playerHistories.computeIfAbsent(playerId, k -> loadPlayerHistoryFromNBT(player));
    }

    /**
     * 获取按NPC分组的历史记录（用于历史界面分组显示）
     */
    public Map<String, List<DialogueHistoryEntry>> getGroupedHistory() {
        List<DialogueHistoryEntry> all = getAllHistory();
        Map<String, List<DialogueHistoryEntry>> grouped = new LinkedHashMap<>();

        for (DialogueHistoryEntry entry : all) {
            grouped.computeIfAbsent(entry.getNpcName(), k -> new ArrayList<>()).add(entry);
        }

        return grouped;
    }

    // 辅助：获取当前玩家（客户端用 Minecraft.getInstance().player，服务器端需传入）
    private Player getCurrentPlayer() {
        if (net.minecraft.client.Minecraft.getInstance().player != null) {
            return net.minecraft.client.Minecraft.getInstance().player;
        }
        return null; // 服务器端需自行传入
    }

    // 从玩家NBT加载历史（仅在需要时调用）
    private List<DialogueHistoryEntry> loadPlayerHistoryFromNBT(Player player) {
        CompoundTag persistent = player.getPersistentData();
        if (!persistent.contains("rpg_dialogue_history")) {
            return new ArrayList<>();
        }

        CompoundTag historyTag = persistent.getCompound("rpg_dialogue_history");
        List<DialogueHistoryEntry> list = new ArrayList<>();

        if (historyTag.contains("entries")) {
            ListTag entries = historyTag.getList("entries", Tag.TAG_COMPOUND);
            for (int i = 0; i < entries.size(); i++) {
                list.add(DialogueHistoryEntry.deserializeNBT(entries.getCompound(i)));
            }
        }

        LOGGER.debug("从NBT加载 {} 条对话历史", list.size());
        return list;
    }

    // 保存到玩家NBT
    private void savePlayerHistory(ServerPlayer player) {
        UUID playerId = player.getUUID();
        List<DialogueHistoryEntry> history = playerHistories.get(playerId);
        if (history == null || history.isEmpty()) return;

        CompoundTag historyTag = new CompoundTag();
        ListTag entries = new ListTag();
        for (DialogueHistoryEntry entry : history) {
            entries.add(entry.serializeNBT());
        }
        historyTag.put("entries", entries);
        historyTag.putLong("lastSaved", System.currentTimeMillis());

        player.getPersistentData().put("rpg_dialogue_history", historyTag);
    }

    // 玩家登出时强制保存
    public void onPlayerLogout(ServerPlayer player) {
        savePlayerHistory(player);
        playerHistories.remove(player.getUUID());
        LOGGER.info("玩家 {} 登出，保存并清除对话历史缓存", player.getName().getString());
    }
}