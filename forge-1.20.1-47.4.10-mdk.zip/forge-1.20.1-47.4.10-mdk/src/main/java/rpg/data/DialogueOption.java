package rpg.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import rpg.data.condition.ConditionParser;
import rpg.data.DialogueCommand;
import rpg.data.PlayerVariables;

import java.util.ArrayList;
import java.util.List;

public class DialogueOption {

    private String optionText;
    private String nextNodeId;
    private String action;
    private String condition;


    private final List<DialogueCommand> commands = new ArrayList<>();

    private int priority = 0; // 新增：优先级，用于置顶排序

    public DialogueOption(String optionText, String nextNodeId, String action) {
        this.optionText = optionText;
        this.nextNodeId = nextNodeId;
        this.action = action != null ? action : "NONE";
        this.condition = "";
    }

    public DialogueOption(String optionText, String nextNodeId, String action, String condition) {
        this.optionText = optionText;
        this.nextNodeId = nextNodeId;
        this.action = action != null ? action : "NONE";
        this.condition = condition != null ? condition : "";
    }

    public String getOptionText() {
        return optionText;
    }

    public void setOptionText(String optionText) {
        this.optionText = optionText;
    }

    public String getNextNodeId() {
        return nextNodeId;
    }

    public void setNextNodeId(String nextNodeId) {
        this.nextNodeId = nextNodeId;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public List<DialogueCommand> getCommands() {
        return commands;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public DialogueOption(String optionText, String nextNodeId) {
        this.optionText = optionText;
        this.nextNodeId = nextNodeId;
    }
    public boolean isAvailableForPlayer(PlayerVariables variables) {
        if (condition == null || condition.isEmpty()) return true;
        return ConditionParser.parse(condition).evaluate(variables);
    }

    public CompoundTag serializeNBT() {
        CompoundTag tag = new CompoundTag();
        tag.putString("optionText", this.optionText);
        tag.putString("nextNodeId", this.nextNodeId);
        if (this.action != null) {
            tag.putString("action", this.action);
        }
        tag.putString("condition", this.condition);
        tag.putInt("priority", this.priority); // 保存优先级

        ListTag commandsTag = new ListTag();
        for (DialogueCommand cmd : this.commands) {
            commandsTag.add(cmd.serializeNBT());
        }
        tag.put("commands", commandsTag);

        return tag;
    }

    public static DialogueOption deserializeNBT(CompoundTag tag) {
        String optionText = tag.getString("optionText");
        String nextNodeId = tag.getString("nextNodeId");
        String action = tag.contains("action") ? tag.getString("action") : null;
        String condition = tag.contains("condition") ? tag.getString("condition") : "";

        DialogueOption option = new DialogueOption(optionText, nextNodeId, action, condition);
        option.setPriority(tag.contains("priority") ? tag.getInt("priority") : 0); // 加载优先级

        if (tag.contains("commands")) {
            ListTag commandsTag = tag.getList("commands", Tag.TAG_COMPOUND);
            for (int i = 0; i < commandsTag.size(); i++) {
                CompoundTag commandTag = commandsTag.getCompound(i);
                option.getCommands().add(DialogueCommand.deserializeNBT(commandTag));
            }
        }
        return option;
    }
}