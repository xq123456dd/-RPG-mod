package rpg.data;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtIo;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import rpg.util.NbtOptimizer;

public class DialogueLoader {
    // 【修复 1】：改为 public
    public static final Map<String, DialogueNode> DIALOGUE_MAP = new HashMap<>();
    public static final String VILLAGER_START_NODE_ID = "VILLAGER_START";

    // 【新增】临时节点存储（用于广播对话）
    private static final Map<String, DialogueNode> TEMPORARY_NODES = new HashMap<>();

    private static final String FILE_NAME = "rpg_global_dialogues.dat";

    /**
     * 初始化默认对话数据。
     */
    public static void init() {
        DIALOGUE_MAP.clear();

        List<DialogueOption> startOptions = new ArrayList<>();
        startOptions.add(new DialogueOption("告诉我你的历史。", "HISTORY_NODE", "NONE"));
        startOptions.add(new DialogueOption("我能为你做些什么？", "END", "NONE"));
        startOptions.add(new DialogueOption("再见。", "END", "NONE"));

        DialogueNode startNode = new DialogueNode(VILLAGER_START_NODE_ID, "神秘旅行者",
                "欢迎来到我的营地，旅行者。你似乎从远方而来。", startOptions);
        DIALOGUE_MAP.put(startNode.getNodeId(), startNode);

        List<DialogueOption> historyOptions = new ArrayList<>();
        historyOptions.add(new DialogueOption("回到刚才的话题。", VILLAGER_START_NODE_ID, "NONE"));

        DialogueNode historyNode = new DialogueNode("HISTORY_NODE", "神秘旅行者",
                "我曾是王国骑士，但在那场战役中失去了所有。现在只剩一把旧剑。", historyOptions);
        DIALOGUE_MAP.put(historyNode.getNodeId(), historyNode);

        System.out.println("加载了 " + DIALOGUE_MAP.size() + " 个默认对话节点。");
    }

    /**
     * 从世界文件加载全局对话数据到内存。
     */
    public static void loadDialogues(ServerLevel level) {
        if (level.dimension() != Level.OVERWORLD) return;

        DIALOGUE_MAP.clear();
        TEMPORARY_NODES.clear(); // 清空临时节点
        
        // 首先尝试从JSON文件夹加载对话数据
        JsonDialogueLoader.loadDialoguesFromFolder(level);
        
        // 如果JSON文件夹中没有数据，则尝试从NBT文件加载
        if (DIALOGUE_MAP.isEmpty()) {
            File dataFile = level.getServer().getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve(FILE_NAME).toFile();

            if (dataFile.exists()) {
                try {
                    CompoundTag rootNbt = NbtIo.readCompressed(dataFile);
                    CompoundTag mapTag = rootNbt.getCompound("GlobalDialogueMap");
                    Map<String, DialogueNode> loadedMap = NbtOptimizer.deserializeDialogueMap(mapTag);

                    DIALOGUE_MAP.putAll(loadedMap);

                    System.out.println("=== 成功加载了 " + DIALOGUE_MAP.size() + " 个全局对话节点 ===");
                    return;
                } catch (IOException e) {
                    System.err.println("错误：无法从文件加载对话数据: " + dataFile.getAbsolutePath());
                    e.printStackTrace();
                }
            }

            System.out.println("对话数据文件不存在或加载失败，加载默认对话。");
            init();
        }
    }

    /**
     * 将内存中的全局对话数据保存到文件。
     */
    public static void saveDialogues(ServerLevel level) {
        if (level.dimension() != Level.OVERWORLD || DIALOGUE_MAP.isEmpty()) return;

        CompoundTag rootNbt = new CompoundTag();
        rootNbt.put("GlobalDialogueMap", NbtOptimizer.serializeDialogueMap(DIALOGUE_MAP));

        File dataFile = level.getServer().getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve(FILE_NAME).toFile();

        try {
            NbtIo.writeCompressed(rootNbt, dataFile);
            System.out.println("=== 成功保存了 " + DIALOGUE_MAP.size() + " 个全局对话节点到文件 ===");
        } catch (IOException e) {
            System.err.println("错误：无法将对话数据保存到文件: " + dataFile.getAbsolutePath());
            e.printStackTrace();
        }
    }

    /**
     * 获取对话节点（支持临时节点）
     */
    public static DialogueNode getNode(String nodeId) {
        if (nodeId == null || "END".equalsIgnoreCase(nodeId)) {
            return null;
        }

        // 1. 先尝试从临时节点中获取（广播对话使用）
        DialogueNode node = TEMPORARY_NODES.get(nodeId);
        if (node != null) {
            System.out.println("[DialogueLoader] 从临时节点中获取到: " + nodeId);
            return node;
        }

        // 2. 从全局节点中获取
        node = DIALOGUE_MAP.get(nodeId);
        if (node != null) {
            System.out.println("[DialogueLoader] 从全局节点中获取到: " + nodeId);
            return node;
        }

        System.out.println("[DialogueLoader] 无法找到对话节点: " + nodeId);
        return null;
    }

    /**
     * 【新增】添加临时节点（用于广播对话）
     */
    public static void addTemporaryNode(DialogueNode node) {
        if (node != null && node.getNodeId() != null) {
            TEMPORARY_NODES.put(node.getNodeId(), node);
            System.out.println("[DialogueLoader] 添加临时对话节点: " + node.getNodeId());
        }
    }

    /**
     * 【新增】批量添加临时节点
     */
    public static void addTemporaryNodes(Map<String, DialogueNode> nodes) {
        if (nodes != null && !nodes.isEmpty()) {
            TEMPORARY_NODES.putAll(nodes);
            System.out.println("[DialogueLoader] 批量添加 " + nodes.size() + " 个临时对话节点");
        }
    }

    /**
     * 【新增】清除所有临时节点
     */
    public static void clearTemporaryNodes() {
        System.out.println("[DialogueLoader] 清除 " + TEMPORARY_NODES.size() + " 个临时对话节点");
        TEMPORARY_NODES.clear();
    }

    /**
     * 【新增】获取临时节点数量
     */
    public static int getTemporaryNodeCount() {
        return TEMPORARY_NODES.size();
    }

    /**
     * 【新增】获取临时节点ID列表
     */
    public static List<String> getTemporaryNodeIds() {
        return new ArrayList<>(TEMPORARY_NODES.keySet());
    }

    public static Map<String, DialogueNode> getAllNodes() {
        return DIALOGUE_MAP;
    }
}