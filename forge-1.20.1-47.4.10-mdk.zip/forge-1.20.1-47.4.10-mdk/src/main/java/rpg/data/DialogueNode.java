package rpg.data;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.nbt.StringTag;

public class DialogueNode {

    private final String nodeId;
    private String npcText = "";
    private String speakerName = "";

    private final List<DialogueOption> options = new ArrayList<>();
    private final List<String> tags = new ArrayList<>();

    private int priority = 0; // 优先级，用于置顶排序（越高越靠前）

    // 图片数据列表
    private final List<ImageData> images = new ArrayList<>();

    public static class ImageData {
        private String path; // 相对路径，如 "rpg_images/xxxx.png"
        private int x;
        private int y;
        private float scale = 1.0f; // 新增：缩放字段，默认为 1.0

        public ImageData(String path, int x, int y) {
            this.path = path;
            this.x = x;
            this.y = y;
        }

        public String getPath() { return path; }
        public void setPath(String path) { this.path = path; }
        public int getX() { return x; }
        public void setX(int x) { this.x = x; }
        public int getY() { return y; }
        public void setY(int y) { this.y = y; }

        // 新增：缩放的 getter 和 setter
        public float getScale() { return scale; }
        public void setScale(float scale) { this.scale = scale; }

        public CompoundTag serializeNBT() {
            CompoundTag tag = new CompoundTag();
            tag.putString("path", path);
            tag.putInt("x", x);
            tag.putInt("y", y);
            tag.putFloat("scale", scale); // 保存缩放
            return tag;
        }

        public static ImageData deserializeNBT(CompoundTag tag) {
            ImageData data = new ImageData(
                    tag.getString("path"),
                    tag.getInt("x"),
                    tag.getInt("y")
            );
            // 向后兼容：如果旧数据没有 scale，则保持默认值 1.0f
            if (tag.contains("scale")) {
                data.scale = tag.getFloat("scale");
            }
            return data;
        }
    }

    public DialogueNode(String nodeId) {
        this.nodeId = nodeId;
    }

    public DialogueNode(String nodeId, String speakerName, String npcText, List<DialogueOption> options) {
        this.nodeId = nodeId;
        this.speakerName = speakerName;
        this.npcText = npcText;
        this.options.addAll(options);
    }

    public String getNodeId() {
        return nodeId;
    }

    public String getNpcText() {
        return npcText;
    }

    public void setNpcText(String npcText) {
        this.npcText = npcText;
    }

    public String getSpeakerName() {
        return speakerName;
    }

    public void setSpeakerName(String speakerName) {
        this.speakerName = speakerName;
    }

    public List<DialogueOption> getOptions() {
        return options;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags.clear();
        if (tags != null) {
            this.tags.addAll(tags);
        }
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public List<ImageData> getImages() {
        return images;
    }

    public CompoundTag serializeNBT() {
        CompoundTag tag = new CompoundTag();
        tag.putString("nodeId", nodeId);
        tag.putString("npcText", npcText);
        tag.putString("speakerName", speakerName);
        tag.putInt("priority", priority);

        ListTag optionsTag = new ListTag();
        for (DialogueOption option : options) {
            optionsTag.add(option.serializeNBT());
        }
        tag.put("options", optionsTag);

        ListTag tagsTag = new ListTag();
        for (String t : tags) {
            tagsTag.add(StringTag.valueOf(t));
        }
        tag.put("tags", tagsTag);

        // 序列化图片（包含 scale）
        ListTag imagesTag = new ListTag();
        for (ImageData img : images) {
            imagesTag.add(img.serializeNBT());
        }
        tag.put("images", imagesTag);

        return tag;
    }

    public static DialogueNode deserializeNBT(CompoundTag tag) {
        String nodeId = tag.getString("nodeId");
        DialogueNode node = new DialogueNode(nodeId);

        node.setNpcText(tag.contains("npcText") ? tag.getString("npcText") : "");
        node.setSpeakerName(tag.contains("speakerName") ? tag.getString("speakerName") : "");
        node.setPriority(tag.contains("priority") ? tag.getInt("priority") : 0);

        if (tag.contains("options")) {
            ListTag optionsTag = tag.getList("options", Tag.TAG_COMPOUND);
            for (int i = 0; i < optionsTag.size(); i++) {
                CompoundTag optionTag = optionsTag.getCompound(i);
                node.getOptions().add(DialogueOption.deserializeNBT(optionTag));
            }
        }

        if (tag.contains("tags")) {
            ListTag tagsTag = tag.getList("tags", Tag.TAG_STRING);
            List<String> loadedTags = new ArrayList<>();
            for (int i = 0; i < tagsTag.size(); i++) {
                loadedTags.add(tagsTag.getString(i));
            }
            node.setTags(loadedTags);
        }

        // 反序列化图片（支持 scale）
        if (tag.contains("images")) {
            ListTag imagesTag = tag.getList("images", Tag.TAG_COMPOUND);
            for (int i = 0; i < imagesTag.size(); i++) {
                node.getImages().add(ImageData.deserializeNBT(imagesTag.getCompound(i)));
            }
        }

        return node;
    }

    public DialogueNode copyWithNewId(String newId) {
        DialogueNode newNode = new DialogueNode(newId);
        newNode.setNpcText(this.npcText);
        newNode.setSpeakerName(this.speakerName);
        newNode.setPriority(this.priority);

        newNode.getOptions().addAll(this.options);
        newNode.getTags().addAll(this.tags);
        newNode.getImages().addAll(this.images);

        return newNode;
    }

    // 你要求的：通过反射修改 final 的 nodeId
    public void setNodeId(String nodeId) {
        try {
            java.lang.reflect.Field field = DialogueNode.class.getDeclaredField("nodeId");
            field.setAccessible(true);
            field.set(this, nodeId);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}