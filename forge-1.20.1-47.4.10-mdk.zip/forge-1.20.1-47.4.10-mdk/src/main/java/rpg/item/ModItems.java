package rpg.item;

import net.minecraft.world.item.Item;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import rpg.RpgDialogueMod;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, RpgDialogueMod.MOD_ID);

    // 注册 NPC 对话编辑工具
    public static final RegistryObject<Item> DIALOGUE_TOOL = ITEMS.register("dialogue_tool",
            () -> new DialogueToolItem());

    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }
}