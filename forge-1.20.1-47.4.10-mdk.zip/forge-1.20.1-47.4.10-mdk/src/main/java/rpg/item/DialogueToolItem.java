package rpg.item;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;

public class DialogueToolItem extends Item {

    public DialogueToolItem() {
        super(new Properties().stacksTo(1).rarity(Rarity.RARE));
    }

    // 逻辑已移动到 DialogueEventHandler 以解决与原版交易界面的冲突
    // 这里保留方法是为了兼容性，但返回 PASS 让 EventHandler 接管
    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity entity, InteractionHand hand) {
        return InteractionResult.PASS;
    }
}