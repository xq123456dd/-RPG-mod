package rpg.events;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;
import rpg.RpgDialogueMod;
import rpg.data.DialogueLoader;
import rpg.data.NpcDialogueLoader;
import rpg.network.ModPacketHandler;
import rpg.network.OpenDialogueS2CPacket;
import rpg.network.OpenNpcEditorPacket;

@Mod.EventBusSubscriber(modid = RpgDialogueMod.MOD_ID)
public class DialogueEventHandler {

    @SubscribeEvent
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        // 确保只在主手交互时处理 (防止副手再次触发)
        if (event.getHand() != InteractionHand.MAIN_HAND) {
            return;
        }

        Player player = event.getEntity();
        if (!(event.getTarget() instanceof LivingEntity targetEntity)) {
            return;
        }

        // 1. 处理 NPC 编辑工具 (优先级最高)
        if (player.getItemInHand(event.getHand()).getItem() == rpg.item.ModItems.DIALOGUE_TOOL.get()) {
            // 关键修复：取消事件，防止原版村民交易界面弹出
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.SUCCESS);

            // 只在服务器端执行逻辑
            if (!event.getLevel().isClientSide && player instanceof ServerPlayer serverPlayer) {
                System.out.println("=== 服务器：使用工具，准备打开NPC编辑器 ===");

                // 获取实体数据
                CompoundTag entityData = targetEntity.getPersistentData();
                CompoundTag dialogueData = new CompoundTag();

                // 提取对话数据（如果存在）
                if (entityData.contains("rpg_dialogue_data")) {
                    dialogueData.put("rpg_dialogue_data", entityData.getCompound("rpg_dialogue_data"));
                }

                // 发送打开编辑器的数据包
                ModPacketHandler.INSTANCE.send(
                        PacketDistributor.PLAYER.with(() -> serverPlayer),
                        new OpenNpcEditorPacket(
                                targetEntity.getId(),
                                targetEntity.getName().getString(),
                                dialogueData
                        )
                );
            }
            return; // 工具逻辑结束
        }

        // 2. 处理普通对话交互 (潜行时不触发)
        if (!player.isShiftKeyDown()) {
            // 检查NPC是否有自定义对话数据，只有有对话数据才打开对话界面
            if (NpcDialogueLoader.hasDialogueData(targetEntity)) {
                // 取消原版交互，阻止交易界面
                event.setCanceled(true);
                event.setCancellationResult(InteractionResult.SUCCESS);

                if (!event.getLevel().isClientSide && player instanceof ServerPlayer serverPlayer) {
                    // 激活NPC行为管理
                    NpcBehaviorHandler.onDialogueStarted(targetEntity, player);

                    String startNodeId = DialogueLoader.VILLAGER_START_NODE_ID;
                    
                    // 获取自定义对话的起始节点
                    var startNode = NpcDialogueLoader.getStartNodeFromEntity(targetEntity);
                    if (startNode != null) {
                        startNodeId = startNode.getNodeId();
                    }

                    // 发送S2C包到客户端，打开对话屏幕
                    ModPacketHandler.sendToPlayer(
                            new OpenDialogueS2CPacket(startNodeId, targetEntity.getId()),
                            serverPlayer
                    );
                }
            }
        }
    }
}