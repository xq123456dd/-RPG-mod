package rpg.events;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import rpg.RpgDialogueMod;

import java.util.*;

@Mod.EventBusSubscriber(modid = RpgDialogueMod.MOD_ID)
public class NpcBehaviorHandler {

    // 缓存活跃的对话NPC，减少每tick的遍历开销
    private static final Map<Integer, ActiveDialogueSession> activeSessions = new HashMap<>();
    private static final int MAX_SEARCH_RANGE = 150;
    private static final int BEHAVIOR_UPDATE_INTERVAL = 2; // 每2tick更新一次
    private static int tickCounter = 0;

    public static class ActiveDialogueSession {
        public final int npcId;
        public final int playerId;
        public final Level level;
        public long lastUpdateTick;

        public ActiveDialogueSession(int npcId, int playerId, Level level) {
            this.npcId = npcId;
            this.playerId = playerId;
            this.level = level;
            this.lastUpdateTick = System.currentTimeMillis();
        }
    }

    /**
     * 添加活跃对话会话
     */
    public static void addActiveSession(int npcId, int playerId, Level level) {
        activeSessions.put(npcId, new ActiveDialogueSession(npcId, playerId, level));
        System.out.println("添加活跃对话会话: NPC=" + npcId + ", Player=" + playerId);
    }

    /**
     * 移除活跃对话会话
     */
    public static void removeActiveSession(int npcId) {
        activeSessions.remove(npcId);
        System.out.println("移除活跃对话会话: NPC=" + npcId);
    }

    /**
     * 检查会话是否过期（超过30秒无更新）
     */
    private static void cleanupExpiredSessions() {
        long currentTime = System.currentTimeMillis();
        Iterator<Map.Entry<Integer, ActiveDialogueSession>> iterator = activeSessions.entrySet().iterator();

        while (iterator.hasNext()) {
            Map.Entry<Integer, ActiveDialogueSession> entry = iterator.next();
            ActiveDialogueSession session = entry.getValue();

            // 超过30秒无更新，清理会话
            if (currentTime - session.lastUpdateTick > 30000) {
                iterator.remove();
                System.out.println("清理过期会话: NPC=" + session.npcId);

                // 清理NPC的对话标记
                Entity npc = session.level.getEntity(session.npcId);
                if (npc != null) {
                    npc.getPersistentData().putBoolean("rpg.dialogue_active", false);
                }
            }
        }
    }

    @SubscribeEvent
    public static void onWorldTick(TickEvent.LevelTickEvent event) {
        // 只在服务器端、tick结束时执行
        if (event.phase != TickEvent.Phase.END || event.level.isClientSide()) {
            return;
        }

        Level level = event.level;
        tickCounter++;

        // 每10tick清理一次过期会话
        if (tickCounter % 10 == 0) {
            cleanupExpiredSessions();
        }

        // 每2tick更新一次NPC行为（减少性能开销）
        if (tickCounter % BEHAVIOR_UPDATE_INTERVAL != 0) {
            return;
        }

        // 首先更新活跃会话中的NPC
        for (ActiveDialogueSession session : activeSessions.values()) {
            if (session.level != level) {
                continue;
            }

            Entity npc = level.getEntity(session.npcId);
            Entity player = level.getEntity(session.playerId);

            if (npc instanceof Mob mobNpc && player instanceof Player) {
                // 更新会话时间戳
                session.lastUpdateTick = System.currentTimeMillis();

                // 强制 NPC 头部转向玩家
                lookAtPlayer(mobNpc, (Player) player);

                // 阻止 NPC 移动
                mobNpc.setDeltaMovement(0, mobNpc.getDeltaMovement().y, 0);

                // 禁用 AI 移动，防止其乱跑
                mobNpc.setNoAi(true);
            }
        }

        // 同时扫描新激活的NPC（确保不会漏掉）
        // 但搜索范围可以更小，因为我们已经有活跃会话列表
        AABB searchBox = new AABB(-MAX_SEARCH_RANGE, -MAX_SEARCH_RANGE, -MAX_SEARCH_RANGE,
                MAX_SEARCH_RANGE, MAX_SEARCH_RANGE, MAX_SEARCH_RANGE);

        for (Entity entity : level.getEntities(null, searchBox)) {
            // 仅处理未在活跃会话中的Mob实体
            if (entity instanceof Mob npc &&
                    !activeSessions.containsKey(entity.getId()) &&
                    isDialogueActive(npc)) {

                // 找到最近的玩家
                Player closestPlayer = level.getNearestPlayer(npc, 10.0);

                if (closestPlayer != null) {
                    // 添加到活跃会话
                    addActiveSession(npc.getId(), closestPlayer.getId(), level);

                    // 更新NPC行为
                    lookAtPlayer(npc, closestPlayer);
                    npc.setDeltaMovement(0, npc.getDeltaMovement().y, 0);
                    npc.setNoAi(true);
                }
            }
        }
    }

    /**
     * 检查实体是否处于对话激活状态
     */
    private static boolean isDialogueActive(Entity entity) {
        return entity.getPersistentData().getBoolean("rpg.dialogue_active");
    }

    /**
     * 强制 NPC 转向目标玩家
     */
    private static void lookAtPlayer(Mob npc, Player target) {
        double dx = target.getX() - npc.getX();
        double dy = target.getEyeY() - npc.getEyeY();
        double dz = target.getZ() - npc.getZ();

        double distance = Math.sqrt(dx * dx + dz * dz);

        // 计算偏航角 (Yaw)
        float yaw = (float) (Mth.atan2(dz, dx) * (180 / Math.PI)) - 90.0F;
        // 计算俯仰角 (Pitch)
        float pitch = (float) (-(Mth.atan2(dy, distance) * (180 / Math.PI)));

        // 平滑旋转
        npc.setYRot(updateRotation(npc.getYRot(), yaw, 30.0F)); // 降低旋转速度，更自然
        npc.setXRot(updateRotation(npc.getXRot(), pitch, 30.0F));
        npc.yHeadRot = npc.getYRot();
        npc.yBodyRot = npc.getYRot();
    }

    /**
     * 更新旋转角度（平滑插值）
     */
    private static float updateRotation(float currentRotation, float targetRotation, float maxDelta) {
        float f = Mth.wrapDegrees(targetRotation - currentRotation);
        if (f > maxDelta) {
            f = maxDelta;
        }
        if (f < -maxDelta) {
            f = -maxDelta;
        }
        return currentRotation + f;
    }

    /**
     * 在对话开始时调用，激活NPC行为管理
     */
    public static void onDialogueStarted(Entity npc, Player player) {
        if (npc != null && player != null) {
            npc.getPersistentData().putBoolean("rpg.dialogue_active", true);
            addActiveSession(npc.getId(), player.getId(), npc.level());
        }
    }

    /**
     * 在对话结束时调用，恢复NPC正常行为
     */
    public static void onDialogueEnded(Entity npc) {
        if (npc != null) {
            npc.getPersistentData().putBoolean("rpg.dialogue_active", false);
            removeActiveSession(npc.getId());

            if (npc instanceof Mob mob) {
                mob.setNoAi(false); // 恢复AI
            }
        }
    }
}