package rpg.client;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.gui.components.toasts.SystemToast;
import rpg.data.DialogueNode;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ImagePositionScreen extends Screen {
    private final Screen parentScreen;
    private final DialogueNode node;
    private final List<LoadedImage> loadedImages = new ArrayList<>();

    private LoadedImage draggingImage = null;
    private int dragOffsetX, dragOffsetY;

    private static final int BOX_WIDTH = 400;
    private static final int BOX_HEIGHT = 120;
    private static final int BOX_Y_FROM_TOP = 135;

    private static class LoadedImage {
        DialogueNode.ImageData data;
        ResourceLocation texture;
        DynamicTexture dynamicTexture;
        int originalW, originalH;

        public LoadedImage(DialogueNode.ImageData data, ResourceLocation texture, DynamicTexture dt, int w, int h) {
            this.data = data;
            this.texture = texture;
            this.dynamicTexture = dt;
            this.originalW = w;
            this.originalH = h;
        }
    }

    public ImagePositionScreen(Screen parent, DialogueNode node) {
        super(Component.literal("可视化调整"));
        this.parentScreen = parent;
        this.node = node;
    }

    @Override
    protected void init() {
        loadImages();

        this.addRenderableWidget(Button.builder(Component.literal("确认并保存"), btn -> {
                    saveChanges();
                    onClose();
                })
                .bounds(this.width / 2 - 100, 10, 100, 20).build());

        this.addRenderableWidget(Button.builder(Component.literal("取消"), btn -> onClose())
                .bounds(this.width / 2 + 10, 10, 80, 20).build());
    }

    private void loadImages() {
        clearResources();
        for (DialogueNode.ImageData imgData : node.getImages()) {
            File file = new File(Minecraft.getInstance().gameDirectory, imgData.getPath());
            if (file.exists()) {
                try {
                    NativeImage ni = NativeImage.read(new FileInputStream(file));

                    if (imgData.getScale() <= 0 || (imgData.getScale() == 1.0f && ni.getWidth() > 200)) {
                        float safeScale = (float) 60 / ni.getHeight();
                        imgData.setScale(Math.min(safeScale, 1.0f));
                    }

                    DynamicTexture dt = new DynamicTexture(ni);
                    ResourceLocation res = Minecraft.getInstance().getTextureManager()
                            .register("pos_edit_" + System.currentTimeMillis(), dt);
                    loadedImages.add(new LoadedImage(imgData, res, dt, ni.getWidth(), ni.getHeight()));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void saveChanges() {
        // 这里假设 DialogueManager 有 syncToServer 方法
        // DialogueManager.getInstance().syncToServer();

        SystemToast.add(
                Minecraft.getInstance().getToasts(),
                SystemToast.SystemToastIds.PERIODIC_NOTIFICATION,
                Component.literal("§a保存成功"),
                Component.literal("图片位置和缩放已更新")
        );
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        g.fill(0, 0, this.width, this.height, 0xCC000000);

        int dialogX = (this.width - BOX_WIDTH) / 2;
        int dialogY = BOX_Y_FROM_TOP;

        g.fill(dialogX, dialogY, dialogX + BOX_WIDTH, dialogY + BOX_HEIGHT, 0xFF101010);
        g.renderOutline(dialogX, dialogY, BOX_WIDTH, BOX_HEIGHT, 0xFFFFFFFF);

        g.drawCenteredString(this.font, Component.literal(node.getSpeakerName()),
                dialogX + BOX_WIDTH / 2, dialogY - 15, 0xFFFFFF);

        var lines = this.font.split(Component.literal(node.getNpcText()), BOX_WIDTH - 40);
        for (int i = 0; i < lines.size(); i++) {
            g.drawString(this.font, lines.get(i), dialogX + 20, dialogY + 15 + i * (this.font.lineHeight + 2), 0xFFFFFF);
        }

        int imageBaseX = dialogX + 15;
        int imageBaseY = dialogY + 15;

        for (LoadedImage img : loadedImages) {
            float scale = img.data.getScale();
            int scaledW = (int) (img.originalW * scale);
            int scaledH = (int) (img.originalH * scale);

            int drawX = imageBaseX + img.data.getX();
            int drawY = imageBaseY + img.data.getY();

            // 【修复】blit 方法的最后两个参数应该是 scaledW, scaledH 而不是 img.originalW, img.originalH
            // 这确保了纹理的 UV 坐标正确映射到缩放后的图片
            g.blit(img.texture, drawX, drawY, 0, 0, scaledW, scaledH, scaledW, scaledH);

            if (isMouseOver(mouseX, mouseY, drawX, drawY, scaledW, scaledH)) {
                g.renderOutline(drawX, drawY, scaledW, scaledH, 0xFF00FF00);
                g.renderTooltip(this.font, Component.literal("比例: " + String.format("%.2f", scale) + "x"), mouseX, mouseY);
            }
        }

        if (draggingImage != null) {
            int newDrawX = (int)mouseX - dragOffsetX;
            int newDrawY = (int)mouseY - dragOffsetY;
            draggingImage.data.setX(newDrawX - imageBaseX);
            draggingImage.data.setY(newDrawY - imageBaseY);
        }

        g.drawCenteredString(this.font, "左键拖动 | 滚轮缩放大小", this.width / 2, 35, 0xAAAAAA);
        super.render(g, mouseX, mouseY, partialTick);
    }

    // 使用第一个文件的缩放逻辑
    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        int imageBaseX = (this.width - BOX_WIDTH) / 2 + 15;
        int imageBaseY = BOX_Y_FROM_TOP + 15;

        for (int i = loadedImages.size() - 1; i >= 0; i--) {
            LoadedImage img = loadedImages.get(i);
            float currentScale = img.data.getScale();
            int scaledW = (int) (img.originalW * currentScale);
            int scaledH = (int) (img.originalH * currentScale);
            int drawX = imageBaseX + img.data.getX();
            int drawY = imageBaseY + img.data.getY();

            if (isMouseOver(mouseX, mouseY, drawX, drawY, scaledW, scaledH)) {
                float oldScale = img.data.getScale();
                // 每次滚动缩放 0.05
                float newScale = Math.max(0.1f, oldScale + (delta > 0 ? 0.05f : -0.05f));
                img.data.setScale(newScale);
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int imageBaseX = (this.width - BOX_WIDTH) / 2 + 15;
            int imageBaseY = BOX_Y_FROM_TOP + 15;

            for (int i = loadedImages.size() - 1; i >= 0; i--) {
                LoadedImage img = loadedImages.get(i);
                int scaledW = (int) (img.originalW * img.data.getScale());
                int scaledH = (int) (img.originalH * img.data.getScale());
                int drawX = imageBaseX + img.data.getX();
                int drawY = imageBaseY + img.data.getY();

                if (isMouseOver(mouseX, mouseY, drawX, drawY, scaledW, scaledH)) {
                    draggingImage = img;
                    dragOffsetX = (int)mouseX - drawX;
                    dragOffsetY = (int)mouseY - drawY;
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        draggingImage = null;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    private boolean isMouseOver(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    private void clearResources() {
        for (LoadedImage img : loadedImages) {
            img.dynamicTexture.close();
            Minecraft.getInstance().getTextureManager().release(img.texture);
        }
        loadedImages.clear();
    }

    @Override
    public void onClose() {
        clearResources();
        Minecraft.getInstance().setScreen(parentScreen);
    }
}