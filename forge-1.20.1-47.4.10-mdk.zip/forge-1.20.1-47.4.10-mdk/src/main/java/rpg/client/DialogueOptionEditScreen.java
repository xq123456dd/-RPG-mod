package rpg.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import rpg.data.DialogueOption;
import rpg.client.DialogueManager; // 确保导入这个，用于同步服务器

public class DialogueOptionEditScreen extends Screen {

    private static final Component TITLE = Component.literal("编辑对话选项");

    // 布局常量
    private static final int PANEL_WIDTH = 340;
    private static final int PANEL_HEIGHT = 280;
    private static final int INPUT_WIDTH = 240;
    private static final int LABEL_WIDTH = 90;
    private static final int ELEMENT_HEIGHT = 20;
    private static final int PADDING = 10;
    private static final int BUTTON_HEIGHT = 20;

    private final Screen parent;
    private final DialogueOption editingOption;

    private EditBox optionTextInput;
    private EditBox targetNodeIdInput;
    private EditBox actionArgumentBox;
    private EditBox conditionInput;

    public DialogueOptionEditScreen(Screen parent, DialogueOption option) {
        super(TITLE);
        this.parent = parent;
        this.editingOption = option;
    }

    @Override
    protected void init() {
        int centerX = (this.width - PANEL_WIDTH) / 2;
        int centerY = (this.height - PANEL_HEIGHT) / 2;

        int inputX = centerX + LABEL_WIDTH + PADDING;
        int currentY = centerY + 30;

        // 选项文本
        this.optionTextInput = new EditBox(this.font, inputX, currentY, INPUT_WIDTH, ELEMENT_HEIGHT, Component.literal("选项文本"));
        this.optionTextInput.setValue(safeString(editingOption.getOptionText()));
        this.optionTextInput.setMaxLength(256);
        this.addRenderableWidget(this.optionTextInput);
        currentY += ELEMENT_HEIGHT + PADDING;

        // 下一节点ID
        this.targetNodeIdInput = new EditBox(this.font, inputX, currentY, INPUT_WIDTH, ELEMENT_HEIGHT, Component.literal("下一节点ID"));
        this.targetNodeIdInput.setValue(safeString(editingOption.getNextNodeId()));
        this.targetNodeIdInput.setMaxLength(64);
        this.addRenderableWidget(this.targetNodeIdInput);
        currentY += ELEMENT_HEIGHT + PADDING;

        // 执行动作（可选）
        this.actionArgumentBox = new EditBox(this.font, inputX, currentY, INPUT_WIDTH, ELEMENT_HEIGHT, Component.literal("执行动作"));
        this.actionArgumentBox.setValue(safeString(editingOption.getAction()));
        this.actionArgumentBox.setHint(Component.literal("可选，旧版功能"));
        this.addRenderableWidget(this.actionArgumentBox);
        currentY += ELEMENT_HEIGHT + PADDING;

        // 条件表达式
        this.conditionInput = new EditBox(this.font, inputX, currentY, INPUT_WIDTH, ELEMENT_HEIGHT, Component.literal("条件表达式"));
        this.conditionInput.setValue(safeString(editingOption.getCondition()));
        this.conditionInput.setHint(Component.literal("如: money >= 100 && has_item diamond"));
        this.addRenderableWidget(this.conditionInput);
        currentY += ELEMENT_HEIGHT + PADDING;

        // 命令编辑按钮（缩小、文字简洁）
        this.addRenderableWidget(Button.builder(
                Component.literal("命令 (" + editingOption.getCommands().size() + ")"),
                button -> {
                    if (this.minecraft != null) {
                        this.minecraft.setScreen(new DialogueCommandScreen(this, editingOption));
                    }
                }
        ).bounds(centerX + (PANEL_WIDTH - 150) / 2, currentY, 150, BUTTON_HEIGHT).build());

        // 底部保存/取消按钮
        int buttonY = centerY + PANEL_HEIGHT - 40;
        int buttonStartX = centerX + (PANEL_WIDTH - (100 * 2 + PADDING)) / 2;

        this.addRenderableWidget(Button.builder(Component.literal("保存"), this::saveAndClose)
                .bounds(buttonStartX, buttonY, 100, BUTTON_HEIGHT).build());

        this.addRenderableWidget(Button.builder(Component.literal("取消"), btn -> this.onClose())
                .bounds(buttonStartX + 100 + PADDING, buttonY, 100, BUTTON_HEIGHT).build());
    }

    private void saveAndClose(Button button) {
        String text = optionTextInput.getValue().trim();
        String nextId = targetNodeIdInput.getValue().trim();

        if (text.isEmpty()) {
            optionTextInput.setTextColor(0xFF5555);
            return;
        }
        if (nextId.isEmpty()) {
            targetNodeIdInput.setTextColor(0xFF5555);
            return;
        }

        // 保存到对象
        editingOption.setOptionText(text);
        editingOption.setNextNodeId(nextId);
        editingOption.setAction(actionArgumentBox.getValue().trim());
        editingOption.setCondition(conditionInput.getValue().trim());

        // 刷新父界面（选项列表）显示
        if (this.parent instanceof DialogueOptionScreen optionScreen) {
            optionScreen.init();
        }

        // 同步到服务器（关键！让修改永久保存到NPC）
        DialogueManager.getInstance().syncToServer();

        // 重置输入框颜色
        optionTextInput.setTextColor(0xFFFFFF);
        targetNodeIdInput.setTextColor(0xFFFFFF);

        this.onClose();
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
        this.renderBackground(graphics);

        int centerX = (this.width - PANEL_WIDTH) / 2;
        int centerY = (this.height - PANEL_HEIGHT) / 2;

        // 面板背景
        graphics.fill(centerX, centerY, centerX + PANEL_WIDTH, centerY + PANEL_HEIGHT, 0xDD000000);

        // 标题
        graphics.drawCenteredString(this.font, this.title, this.width / 2, centerY + 10, 0xFFFFFF);

        // 标签
        int labelRightX = centerX + LABEL_WIDTH;
        int labelY = centerY + 35;

        drawLabel(graphics, "选项文本:", labelRightX, labelY);
        labelY += ELEMENT_HEIGHT + PADDING;
        drawLabel(graphics, "下一节点ID:", labelRightX, labelY);
        labelY += ELEMENT_HEIGHT + PADDING;
        drawLabel(graphics, "执行动作:", labelRightX, labelY);
        labelY += ELEMENT_HEIGHT + PADDING;
        drawLabel(graphics, "条件表达式:", labelRightX, labelY);

        super.render(graphics, mouseX, mouseY, partialTicks);
    }

    private void drawLabel(GuiGraphics g, String text, int rightX, int y) {
        int textWidth = this.font.width(text);
        g.drawString(this.font, text, rightX - textWidth, y, 0xCCCCCC, false);
    }

    @Override
    public void onClose() {
        if (this.minecraft != null) {
            this.minecraft.setScreen(this.parent);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private String safeString(String str) {
        return str == null ? "" : str;
    }
}