package rpg.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import rpg.RpgDialogueMod;
import rpg.data.DialogueHistoryManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class DialogueHistoryScreen extends Screen {
    private static final Logger LOGGER = LogManager.getLogger();
    private final Screen parent;

    // 历史数据
    private List<DialogueHistoryManager.DialogueHistoryEntry> currentHistory;
    private final Map<String, List<DialogueHistoryManager.DialogueHistoryEntry>> groupedHistory;

    // UI 常量
    private static final int WIDTH = 700;
    private static final int HEIGHT = 500;
    private static final int BUTTON_WIDTH = 150;
    private static final int BUTTON_HEIGHT = 20;
    private static final int ELEMENT_HEIGHT = 60; // 增加高度以容纳头像
    private static final int AVATAR_SIZE = 50; // 头像大小

    // 分页
    private int currentPage = 0;
    private static final int ENTRIES_PER_PAGE = 10; // 减少每页条目数

    // 搜索
    private String searchQuery = "";
    private EditBox searchBox;

    // 背景纹理
    private static final ResourceLocation BACKGROUND_TEXTURE =
            ResourceLocation.fromNamespaceAndPath(RpgDialogueMod.MOD_ID, "textures/gui/dialogue_history_bg.png");
    private static final ResourceLocation SCROLLBAR_TEXTURE =
            ResourceLocation.fromNamespaceAndPath(RpgDialogueMod.MOD_ID, "textures/gui/scrollbar.png");

    public DialogueHistoryScreen(Screen parent) {
        super(Component.literal("对话历史"));
        this.parent = parent;

        // 初始化历史数据
        this.groupedHistory = DialogueHistoryManager.getInstance().getGroupedHistory();
        this.currentHistory = new ArrayList<>(DialogueHistoryManager.getInstance().getAllHistory());
    }

    @Override
    protected void init() {
        super.init();
        this.clearWidgets();

        int startX = (this.width - WIDTH) / 2;
        int startY = (this.height - HEIGHT) / 2;

        // 搜索框
        searchBox = new EditBox(this.font, startX + 10, startY + 10, WIDTH - 20, 20, Component.literal("搜索..."));
        searchBox.setValue(searchQuery);
        searchBox.setMaxLength(128);
        searchBox.setResponder(this::onSearchChanged);
        this.addRenderableWidget(searchBox);

        // 分组按钮（按 NPC 分组）
        if (!groupedHistory.isEmpty()) {
            int groupX = startX + 10;
            int groupY = startY + 40;
            for (String group : groupedHistory.keySet()) {
                Button groupButton = Button.builder(Component.literal(group), btn -> {
                    currentHistory = new ArrayList<>(groupedHistory.get(group));
                    currentPage = 0;
                    this.init(); // 刷新界面
                }).bounds(groupX, groupY, BUTTON_WIDTH, BUTTON_HEIGHT).build();
                this.addRenderableWidget(groupButton);

                groupX += BUTTON_WIDTH + 5;
                if (groupX + BUTTON_WIDTH > startX + WIDTH - 10) {
                    groupX = startX + 10;
                    groupY += BUTTON_HEIGHT + 5;
                }
            }
        }

        // 分页按钮
        int buttonY = startY + HEIGHT - 30;

        // 上一页
        this.addRenderableWidget(Button.builder(Component.literal("上一页"), btn -> {
            if (currentPage > 0) {
                currentPage--;
                this.init();
            }
        }).bounds(startX + 10, buttonY, BUTTON_WIDTH, BUTTON_HEIGHT).build());

        // 下一页（修复乱码！）
        this.addRenderableWidget(Button.builder(Component.literal("下一页"), btn -> {
            if ((currentPage + 1) * ENTRIES_PER_PAGE < currentHistory.size()) {
                currentPage++;
                this.init();
            }
        }).bounds(startX + WIDTH - BUTTON_WIDTH - 10, buttonY, BUTTON_WIDTH, BUTTON_HEIGHT).build());

        // 关闭按钮
        this.addRenderableWidget(Button.builder(Component.literal("关闭"), btn -> this.onClose())
                .bounds(startX + (WIDTH - BUTTON_WIDTH) / 2, buttonY, BUTTON_WIDTH, BUTTON_HEIGHT).build());
    }

    private void onSearchChanged(String query) {
        this.searchQuery = query.toLowerCase().trim();
        this.currentHistory = filterHistory(DialogueHistoryManager.getInstance().getAllHistory(), this.searchQuery);
        this.currentPage = 0;
        this.init(); // 刷新显示
    }

    private List<DialogueHistoryManager.DialogueHistoryEntry> filterHistory(
            List<DialogueHistoryManager.DialogueHistoryEntry> history, String query) {
        if (query.isEmpty()) {
            return new ArrayList<>(history);
        }
        return history.stream()
                .filter(entry -> entry.getNpcName().toLowerCase().contains(query) ||
                        (entry.getNpcText() != null && entry.getNpcText().toLowerCase().contains(query)) ||
                        (entry.getSelectedOption() != null && entry.getSelectedOption().toLowerCase().contains(query)))
                .toList();
    }

    private List<DialogueHistoryManager.DialogueHistoryEntry> getCurrentPageEntries() {
        int start = currentPage * ENTRIES_PER_PAGE;
        int end = Math.min(start + ENTRIES_PER_PAGE, currentHistory.size());
        if (start >= currentHistory.size()) {
            return new ArrayList<>();
        }
        return currentHistory.subList(start, end);
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
        this.renderBackground(guiGraphics);

        int startX = (width - WIDTH) / 2;
        int startY = (height - HEIGHT) / 2;

        // 绘制半透明背景
        guiGraphics.fill(startX, startY, startX + WIDTH, startY + HEIGHT, 0xDD000000);

        // 绘制边框
        drawBorder(guiGraphics, startX, startY, WIDTH, HEIGHT);

        // 标题
        guiGraphics.drawCenteredString(this.font, this.title, this.width / 2, startY - 15, 0xFFFFFF);

        // 渲染当前页条目
        List<DialogueHistoryManager.DialogueHistoryEntry> pageEntries = getCurrentPageEntries();
        int entryY = startY + 70; // 留出空间给搜索框和分组按钮
        for (int i = 0; i < pageEntries.size(); i++) {
            DialogueHistoryManager.DialogueHistoryEntry entry = pageEntries.get(i);
            int globalIndex = currentPage * ENTRIES_PER_PAGE + i;
            renderEntry(guiGraphics, startX + 10, entryY, entry, globalIndex);
            entryY += ELEMENT_HEIGHT + 8;
        }

        // 绘制滚动条
        drawScrollbar(guiGraphics, startX + WIDTH - 15, startY + 70, HEIGHT - 100);

        // 分页信息
        int totalPages = (int) Math.ceil((double) currentHistory.size() / ENTRIES_PER_PAGE);
        String pageInfo = String.format("第 %d / %d 页 (共 %d 条)",
                currentPage + 1, Math.max(1, totalPages), currentHistory.size());
        guiGraphics.drawCenteredString(this.font, pageInfo, width / 2, startY + HEIGHT - 50, 0xAAAAAA);

        super.render(guiGraphics, mouseX, mouseY, partialTicks);
    }

    private void drawBorder(GuiGraphics guiGraphics, int x, int y, int width, int height) {
        int borderColor = 0xFF404040;
        int borderWidth = 2;

        // 上边框
        guiGraphics.fill(x, y, x + width, y + borderWidth, borderColor);
        // 下边框
        guiGraphics.fill(x, y + height - borderWidth, x + width, y + height, borderColor);
        // 左边框
        guiGraphics.fill(x, y, x + borderWidth, y + height, borderColor);
        // 右边框
        guiGraphics.fill(x + width - borderWidth, y, x + width, y + height, borderColor);
    }

    private void drawScrollbar(GuiGraphics guiGraphics, int x, int y, int height) {
        int scrollbarWidth = 8;
        int handleHeight = 30;
        float progress = (float) currentPage / Math.max(1, (float) currentHistory.size() / ENTRIES_PER_PAGE);
        int handleY = y + (int) ((height - handleHeight) * progress);

        // 滚动条槽
        guiGraphics.fill(x, y, x + scrollbarWidth, y + height, 0x44000000);

        // 滚动条手柄
        guiGraphics.fill(x, handleY, x + scrollbarWidth, handleY + handleHeight, 0x88FFFFFF);
    }

    private void renderEntry(GuiGraphics guiGraphics, int x, int y,
                             DialogueHistoryManager.DialogueHistoryEntry entry, int index) {
        int width = WIDTH - 20;

        // 交替背景
        if (index % 2 == 0) {
            guiGraphics.fill(x - 2, y - 1, x + width, y + ELEMENT_HEIGHT - 1, 0x22FFFFFF);
        }

        // 绘制NPC头像
        drawAvatar(guiGraphics, x, y, entry.getNpcName());

        // 时间 + NPC 名称
        String timeStr = String.format("[%tR]", entry.getTimestamp());
        String header = String.format("§e%s §7%s§r", timeStr, entry.getNpcName());
        guiGraphics.drawString(this.font, header, x + AVATAR_SIZE + 10, y + 5, 0xFFFFFF, false);

        // 内容
        String content = entry.getSelectedOption() != null ?
                "选择: " + entry.getSelectedOption() :
                "对话: " + (entry.getNpcText() != null ?
                        entry.getNpcText().substring(0, Math.min(60, entry.getNpcText().length())) +
                                (entry.getNpcText().length() > 60 ? "..." : "") : "(无文本)");

        // 多行显示内容
        List<net.minecraft.util.FormattedCharSequence> formattedLines = Minecraft.getInstance().font.split(Component.literal(content), width - AVATAR_SIZE - 20);
        List<Component> lines = new ArrayList<>();
        for (net.minecraft.util.FormattedCharSequence seq : formattedLines) {
            lines.add(Component.literal(seq.toString()));
        }
        for (int i = 0; i < lines.size() && i < 2; i++) {
            guiGraphics.drawString(this.font, lines.get(i), x + AVATAR_SIZE + 10, y + 20 + i * 12, 0xCCCCCC, false);
        }
    }

    private void drawAvatar(GuiGraphics guiGraphics, int x, int y, String npcName) {
        // 尝试加载NPC头像
        String avatarPath = "textures/gui/avatars/" + npcName + ".png";
        ResourceLocation avatarTexture = ResourceLocation.fromNamespaceAndPath(RpgDialogueMod.MOD_ID, avatarPath);

        try {
            guiGraphics.blit(avatarTexture, x, y, 0, 0, AVATAR_SIZE, AVATAR_SIZE, AVATAR_SIZE, AVATAR_SIZE);
        } catch (Exception e) {
            // 如果找不到头像，绘制默认头像
            drawDefaultAvatar(guiGraphics, x, y);
        }
    }

    private void drawDefaultAvatar(GuiGraphics guiGraphics, int x, int y) {
        // 绘制默认头像背景
        guiGraphics.fill(x, y, x + AVATAR_SIZE, y + AVATAR_SIZE, 0xFF333333);
        // 绘制默认头像边框
        guiGraphics.fill(x, y, x + AVATAR_SIZE, y + 2, 0xFF666666);
        guiGraphics.fill(x, y, x + 2, y + AVATAR_SIZE, 0xFF666666);
        guiGraphics.fill(x + AVATAR_SIZE - 2, y, x + AVATAR_SIZE, y + AVATAR_SIZE, 0xFF666666);
        guiGraphics.fill(x, y + AVATAR_SIZE - 2, x + AVATAR_SIZE, y + AVATAR_SIZE, 0xFF666666);
        // 绘制问号
        guiGraphics.drawCenteredString(this.font, "?", x + AVATAR_SIZE / 2, y + AVATAR_SIZE / 2 - 4, 0xFFFFFF);
    }

    @Override
    public void onClose() {
        if (this.minecraft != null) {
            this.minecraft.setScreen(this.parent);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}