package rpg.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.ParametersAreNonnullByDefault; // 添加此注解，消除非空警告
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@ParametersAreNonnullByDefault
public class BatchOperationScreen extends Screen {

    private static final Logger LOGGER = LogManager.getLogger();

    private final Screen parent;
    private final Map<String, rpg.data.DialogueNode> nodeMap;

    // UI 常量
    private static final int WIDTH = 600;
    private static final int HEIGHT = 500;
    private static final int BUTTON_WIDTH = 150;
    private static final int BUTTON_HEIGHT = 20;

    // UI 组件
    private EditBox findText;
    private EditBox replaceText;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    public BatchOperationScreen(Screen parent) {
        super(Component.literal("批量操作"));
        this.parent = parent;
        this.nodeMap = rpg.client.DialogueManager.getInstance().getCurrentNpcDialogueMap();
    }

    @Override
    protected void init() {
        super.init();
        clearWidgets();

        int startX = (width - WIDTH) / 2;
        int startY = (height - HEIGHT) / 2;
        int labelX = startX + 20;
        int fieldX = startX + 150;
        int currentY = startY + 50;

        // 查找文本标签 + 输入框
        addRenderableWidget(new StringWidget(labelX, currentY, 120, 20, Component.literal("查找文本:"), font));
        findText = new EditBox(font, fieldX, currentY, 300, 20, Component.literal("查找"));
        addRenderableWidget(findText);
        currentY += 40;

        // 替换文本标签 + 输入框
        addRenderableWidget(new StringWidget(labelX, currentY, 120, 20, Component.literal("替换为:"), font));
        replaceText = new EditBox(font, fieldX, currentY, 300, 20, Component.literal("替换"));
        addRenderableWidget(replaceText);
        currentY += 60;

        // 执行按钮
        addRenderableWidget(Button.builder(Component.literal("执行查找替换"), btn -> performBatchReplace())
                .bounds(startX + (WIDTH - BUTTON_WIDTH) / 2, currentY, BUTTON_WIDTH, BUTTON_HEIGHT)
                .build());

        currentY += 40;

        // 返回按钮
        addRenderableWidget(Button.builder(Component.literal("返回"), btn -> onClose())
                .bounds(startX + (WIDTH - BUTTON_WIDTH) / 2, currentY, BUTTON_WIDTH, BUTTON_HEIGHT)
                .build());
    }

    private void performBatchReplace() {
        String find = findText.getValue().trim();
        String replace = replaceText.getValue();

        if (find.isEmpty()) {
            LOGGER.warn("批量替换失败：查找文本为空");
            return;
        }

        executor.submit(() -> {
            try {
                int affected = BatchOperationManager.getInstance()
                        .batchFindAndReplace(nodeMap, find, replace, false, false);
                LOGGER.info("批量查找替换完成，影响了 {} 处内容", affected);

                // 主线程更新 UI（安全检查 NPE）
                if (this.minecraft != null) {
                    this.minecraft.execute(() -> {
                        // 可选：在这里添加一个临时提示，如聊天消息或屏幕提示
                        // 例如：minecraft.player.sendSystemMessage(Component.literal("替换完成，影响 " + affected + " 处"));
                    });
                }
            } catch (Exception e) {
                LOGGER.error("批量替换执行出错", e);
            }
        });
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
        renderBackground(guiGraphics);

        int startX = (width - WIDTH) / 2;
        int startY = (height - HEIGHT) / 2;

        // 半透明背景框
        guiGraphics.fill(startX, startY, startX + WIDTH, startY + HEIGHT, 0xAA000000);

        // 标题
        guiGraphics.drawCenteredString(font, title, width / 2, startY + 15, 0xFFFFFF);

        // 分隔线
        guiGraphics.fill(startX + 10, startY + 140, startX + WIDTH - 10, startY + 142, 0x55FFFFFF);
        guiGraphics.fill(startX + 10, startY + 240, startX + WIDTH - 10, startY + 242, 0x55FFFFFF);

        super.render(guiGraphics, mouseX, mouseY, partialTicks);
    }

    @Override
    public void onClose() {
        executor.shutdownNow();
        if (minecraft != null) {
            minecraft.setScreen(parent);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}