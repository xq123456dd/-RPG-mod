package rpg.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import rpg.data.DialogueNode;
import rpg.data.DialogueOption;

import java.util.List;

public class DialogueOptionScreen extends Screen {

    private final Screen parentScreen;
    private final DialogueNode node;

    // 常量定义
    private static final int BUTTON_HEIGHT = 20;
    private static final int PADDING = 5;
    private static final int MAIN_BTN_WIDTH = 180;

    public DialogueOptionScreen(Screen parent, DialogueNode node) {
        // --- 调试标记：如果你没看到红色标题，说明代码没生效 ---
        super(Component.literal("§f编辑节点: " + node.getNodeId()));
        this.parentScreen = parent;
        this.node = node;
    }

    @Override
    protected void init() {
        super.init();
        this.clearWidgets();

        List<DialogueOption> options = node.getOptions();
        // 1. 排序：置顶的(priority=1000)排在最前
        options.sort((a, b) -> Integer.compare(b.getPriority(), a.getPriority()));

        int centerX = this.width / 2;

        // 2. 布局：强制从屏幕高度的 40% 处开始绘制，绝对不会顶在最上面
        int startY = (int) (this.height * 0.4);

        for (int i = 0; i < options.size(); i++) {
            final DialogueOption currentOption = options.get(i);
            int btnY = startY + i * (BUTTON_HEIGHT + PADDING);

            // 检查置顶状态
            boolean isTop = currentOption.getPriority() > 0;

            // --- 视觉反馈 ---
            // 置顶：金字 + 金星
            // 普通：白字 + 灰星
            String textColor = isTop ? "§6" : "§f";
            String textContent = currentOption.getOptionText().isEmpty() ? "未命名选项" : currentOption.getOptionText();
            String buttonLabel = textColor + (isTop ? "[置顶] " : "") + textContent;

            // [左侧] 编辑按钮
            this.addRenderableWidget(Button.builder(
                    Component.literal(buttonLabel),
                    btn -> openOptionEditScreen(currentOption)
            ).bounds(centerX - 120, btnY, MAIN_BTN_WIDTH, BUTTON_HEIGHT).build());

            // [中间] 置顶开关 (不再是箭头，而是星星)
            String starIcon = isTop ? "§e★" : "§7☆";
            this.addRenderableWidget(Button.builder(
                            Component.literal(starIcon),
                            btn -> {
                                // 逻辑：如果已经置顶，就取消；如果没置顶，就先清空其他人，再置顶自己
                                if (isTop) {
                                    currentOption.setPriority(0);
                                } else {
                                    node.getOptions().forEach(opt -> opt.setPriority(0)); // 只有这里有循环清零
                                    currentOption.setPriority(1000);
                                }
                                saveAndRefresh();
                            }
                    ).bounds(centerX + 65, btnY, 25, BUTTON_HEIGHT)
                    .tooltip(Tooltip.create(Component.literal(isTop ? "点击取消置顶" : "点击设为第一")))
                    .build());

            // [右侧] 删除按钮 (红色 X)
            this.addRenderableWidget(Button.builder(
                    Component.literal("§c✕"),
                    btn -> {
                        node.getOptions().remove(currentOption);
                        saveAndRefresh();
                    }
            ).bounds(centerX + 95, btnY, 25, BUTTON_HEIGHT).build());
        }

        // 底部按钮：放在列表下面，或者固定在屏幕底部
        int footerY = Math.max(startY + options.size() * (BUTTON_HEIGHT + PADDING) + 20, this.height - 50);

        this.addRenderableWidget(Button.builder(Component.literal("§a➕ 添加选项"), btn -> openOptionEditScreen(null))
                .bounds(centerX - 105, footerY, 100, BUTTON_HEIGHT).build());

        this.addRenderableWidget(Button.builder(Component.literal("§7返回"), btn -> this.onClose())
                .bounds(centerX + 5, footerY, 100, BUTTON_HEIGHT).build());
    }

    private void saveAndRefresh() {
        DialogueManager.getInstance().syncToServer();
        this.init();
    }

    private void openOptionEditScreen(DialogueOption option) {
        DialogueOption target = option;
        if (target == null) {
            target = new DialogueOption("新选项", "END", "NONE", "");
            node.getOptions().add(target);
        }
        if (this.minecraft != null) {
            this.minecraft.setScreen(new DialogueOptionEditScreen(this, target));
        }
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
        this.renderBackground(guiGraphics);

        // 黑色背景板
        int panelX = this.width / 2 - 140;
        guiGraphics.fill(panelX, 20, panelX + 280, this.height - 20, 0x88000000);

        // 标题绘制
        guiGraphics.drawCenteredString(this.font, this.title, this.width / 2, 35, 0xFFFFFF);

        super.render(guiGraphics, mouseX, mouseY, partialTicks);
    }

    @Override
    public void onClose() {
        if (this.minecraft != null) {
            this.minecraft.setScreen(this.parentScreen);
        }
    }
}