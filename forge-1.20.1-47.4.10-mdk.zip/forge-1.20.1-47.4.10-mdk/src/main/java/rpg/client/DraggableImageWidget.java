package rpg.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

public class DraggableImageWidget extends AbstractWidget {
    private ResourceLocation texture;
    private boolean dragging = false;
    private final int imageWidth;  // 实际图片宽度
    private final int imageHeight; // 实际图片高度

    public DraggableImageWidget(int x, int y, int width, int height, ResourceLocation texture) {
        super(x, y, width, height, Component.literal("Image"));
        this.texture = texture;
        this.imageWidth = width;  // 可以动态加载图片尺寸，但简化假设固定
        this.imageHeight = height;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (this.isMouseOver(mouseX, mouseY)) {
            dragging = true;
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragging = false;
        return true;
    }

    @Override
    public void mouseMoved(double mouseX, double mouseY) {
        if (dragging) {
            this.setX((int) mouseX - width / 2);
            this.setY((int) mouseY - height / 2);
        }
    }

    @Override
    public void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
        graphics.blit(texture, getX(), getY(), 0, 0, width, height, imageWidth, imageHeight);
    }

    @Override
    protected void updateWidgetNarration(NarrationElementOutput narration) {
        // 可选：添加旁白支持
    }
}