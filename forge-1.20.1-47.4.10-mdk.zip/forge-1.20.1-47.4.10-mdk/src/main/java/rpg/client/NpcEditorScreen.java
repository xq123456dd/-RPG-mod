package rpg.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.ChatFormatting;
import rpg.data.DialogueNode;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class NpcEditorScreen extends Screen {
    private static final Logger LOGGER = LogManager.getLogger();

    // 自适应UI参数
    private int uiWidth;
    private int uiHeight;
    private int buttonHeight;
    private int itemHeight;
    private int headerHeight;
    private int footerHeight;
    private int nodesPerPage;

    private final int entityId;
    private final String entityName;
    private Component screenTitle;

    // 颜色常量
    private final int BACKGROUND_COLOR = 0xDD000000;
    private final int HEADER_COLOR = 0xDD2C3E50;
    private final int LIST_BG_COLOR = 0xCC000000;
    private final int LIST_BORDER_COLOR = 0xFF444444;
    private final int START_NODE_COLOR = 0xFF27AE60;
    private final int TOP_NODE_COLOR = 0xFFF39C12;

    private List<DialogueNode> nodes = new ArrayList<>();
    private int currentPage = 0;

    // 存储当前起始节点ID
    private String currentStartNodeId = "";
    
    // 状态消息
    private String statusMessage = "";
    private long statusMessageTime = 0;
    private int statusColor = 0xFFFFFF;

    public NpcEditorScreen(Component title, int entityId, String entityName) {
        super(title);
        this.entityId = entityId;
        this.entityName = entityName;

        MutableComponent titleComponent = Component.literal("对话编辑器: ")
                .append(Component.literal(entityName).withStyle(ChatFormatting.YELLOW));
        this.screenTitle = titleComponent;
    }

    /**
     * 导出对话到JSON文件
     */
    private void exportDialogueToJson() {
        Map<String, DialogueNode> dialogueMap = DialogueManager.getInstance().getAllNodes();
        String fileName = entityName + "_dialogue.json";
        
        // 发送到服务器进行导出
        rpg.network.ModPacketHandler.sendToServer(new rpg.network.ExportDialogueC2SPacket(dialogueMap, fileName));
        
        // 显示成功消息
        statusMessage = "正在导出对话到JSON文件...";
        statusMessageTime = System.currentTimeMillis();
        statusColor = 0x00FF00;
    }

    private void calculateUISize() {
        int screenWidth = this.width;
        int screenHeight = this.height;

        uiWidth = Math.min(500, Math.max(300, (int)(screenWidth * 0.9)));
        uiHeight = Math.min(400, Math.max(200, (int)(screenHeight * 0.8)));
        buttonHeight = Math.max(16, Math.min(22, uiHeight / 20));
        nodesPerPage = Math.max(3, Math.min(10, (uiHeight - 100) / 28));

        itemHeight = buttonHeight + 4;
        headerHeight = buttonHeight * 2 + 10;
        footerHeight = buttonHeight * 2 + 10;
    }

    public void loadNodes() {
        this.nodes = new ArrayList<>(DialogueManager.getInstance().getAllNodes().values());
        this.nodes.sort(Comparator.comparingInt(DialogueNode::getPriority).reversed());
        this.currentStartNodeId = DialogueManager.getInstance().getNpcStartNode(entityName);
    }

    @Override
    protected void init() {
        super.init();
        this.clearWidgets();
        calculateUISize();
        loadNodes();

        int centerX = this.width / 2;
        int startY = (this.height - uiHeight) / 2;
        int startX = centerX - uiWidth / 2;

        // 新增节点按钮 - 改为弹出输入框
        this.addRenderableWidget(Button.builder(Component.literal("+ 新增节点"), btn -> {
                    // 打开新建节点界面，让用户输入节点名称
                    this.minecraft.setScreen(new CreateNodeScreen(this, entityName));
                })
                .bounds(startX + 10, startY - buttonHeight - 5,
                        uiWidth/3, buttonHeight)
                .build());

        // 返回按钮
        this.addRenderableWidget(Button.builder(Component.literal("返回"), btn -> {
            this.onClose();
        }).bounds(startX + uiWidth - uiWidth/3 - 10, startY - buttonHeight - 5,
                uiWidth/3, buttonHeight).build());

        int startIndex = currentPage * nodesPerPage;
        int endIndex = Math.min(startIndex + nodesPerPage, nodes.size());

        int listStartY = startY + headerHeight;
        int listEndY = startY + uiHeight - footerHeight;

        for (int i = startIndex; i < endIndex; i++) {
            DialogueNode node = nodes.get(i);
            int itemIndex = i - startIndex;
            int itemY = listStartY + itemIndex * itemHeight + 10;

            if (itemY + buttonHeight > listEndY) break;

            boolean isStartNode = node.getNodeId().equals(currentStartNodeId);
            boolean isTopNode = node.getPriority() > 0;
            String displayText = formatNodeDisplayText(node, isStartNode, isTopNode);

            // 节点主体按钮
            NodeButton nodeButton = new NodeButton(
                    startX + 15,
                    itemY,
                    uiWidth - 110,
                    buttonHeight,
                    Component.literal(displayText),
                    btn -> {
                        this.minecraft.setScreen(new DialogueEditScreen(this, node, entityName, false));
                    },
                    isStartNode,
                    isTopNode
            );
            this.addRenderableWidget(nodeButton);

            // 操作按钮
            int buttonX = startX + uiWidth - 95;
            final int index = i;

            // 置顶按钮
            String topSymbol = isTopNode ? "★" : "↑";
            Component topText = Component.literal(topSymbol);
            if (isTopNode) topText = topText.copy().withStyle(ChatFormatting.YELLOW);

            Button topButton = Button.builder(topText, btn -> {
                        DialogueNode n = nodes.get(index);
                        n.setPriority(n.getPriority() > 0 ? 0 : 1000);
                        DialogueManager.getInstance().syncToServer();
                        this.loadNodes();
                        this.init();
                    })
                    .bounds(buttonX, itemY, 20, buttonHeight)
                    .build();
            this.addRenderableWidget(topButton);

            // 起始按钮
            Component startText = Component.literal(isStartNode ? "✓" : "起");
            if (isStartNode) startText = startText.copy().withStyle(ChatFormatting.GREEN);

            Button startButton = Button.builder(startText, btn -> {
                        DialogueManager.getInstance().setStartNodeId(node.getNodeId());
                        node.setPriority(1000);
                        DialogueManager.getInstance().syncToServer();
                        this.loadNodes();
                        this.init();
                    })
                    .bounds(buttonX + 22, itemY, 20, buttonHeight)
                    .build();
            this.addRenderableWidget(startButton);

            // 编辑按钮
            Button editButton = Button.builder(Component.literal("E").withStyle(ChatFormatting.BLUE), btn -> {
                        this.minecraft.setScreen(new DialogueEditScreen(this, node, entityName, false));
                    })
                    .bounds(buttonX + 44, itemY, 20, buttonHeight)
                    .build();
            this.addRenderableWidget(editButton);

            // 删除按钮
            Button deleteButton = Button.builder(Component.literal("X").withStyle(ChatFormatting.RED), btn -> {
                        DialogueManager.getInstance().deleteNode(node.getNodeId());
                        this.loadNodes();
                        this.init();
                    })
                    .bounds(buttonX + 66, itemY, 20, buttonHeight)
                    .build();
            this.addRenderableWidget(deleteButton);
        }

        // 分页按钮
        int pageControlY = startY + uiHeight - footerHeight + 8;

        // 上一页按钮
        if (currentPage > 0) {
            this.addRenderableWidget(Button.builder(Component.literal("◀ 上一页"), btn -> {
                        currentPage--;
                        this.init();
                    })
                    .bounds(centerX - 70, pageControlY, 70, buttonHeight)
                    .build());
        }

        // 下一页按钮
        int maxPages = Math.max(1, (int) Math.ceil((double) nodes.size() / nodesPerPage));
        if (currentPage < maxPages - 1) {
            this.addRenderableWidget(Button.builder(Component.literal("下一页 ▶"), btn -> {
                        currentPage++;
                        this.init();
                    })
                    .bounds(centerX, pageControlY, 70, buttonHeight)
                    .build());
        }

        // 跳转按钮（当有多个页面时）
        if (maxPages > 3) {
            // 第一页按钮
            if (currentPage > 1) {
                this.addRenderableWidget(Button.builder(Component.literal("1"), btn -> {
                            currentPage = 0;
                            this.init();
                        })
                        .bounds(startX + 10, pageControlY, 20, buttonHeight)
                        .build());
            }

            // 最后一页按钮
            if (currentPage < maxPages - 2) {
                this.addRenderableWidget(Button.builder(Component.literal(String.valueOf(maxPages)), btn -> {
                            currentPage = maxPages - 1;
                            this.init();
                        })
                        .bounds(startX + uiWidth - 30, pageControlY, 20, buttonHeight)
                        .build());
            }
        }
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
        this.renderBackground(guiGraphics);

        int centerX = this.width / 2;
        int startX = centerX - uiWidth / 2;
        int startY = (this.height - uiHeight) / 2;

        // 背景和标题
        guiGraphics.fill(startX, startY, startX + uiWidth, startY + uiHeight, BACKGROUND_COLOR);
        guiGraphics.fill(startX, startY, startX + uiWidth, startY + headerHeight, HEADER_COLOR);

        // 标题
        guiGraphics.drawString(this.font, screenTitle, startX + 10, startY + 8, 0xFFFFFF, false);

        // 信息文本
        String entityInfo = "实体ID: " + entityId;
        guiGraphics.drawString(this.font, entityInfo, startX + 10, startY + headerHeight - 12, 0xAAAAAA, false);

        String nodeInfo = "节点数: " + nodes.size();
        guiGraphics.drawString(this.font, nodeInfo, startX + uiWidth - this.font.width(nodeInfo) - 10,
                startY + headerHeight - 12, 0xAAAAAA, false);

        // 分隔线
        guiGraphics.fill(startX, startY + headerHeight, startX + uiWidth, startY + headerHeight + 1, 0xFF555555);
        guiGraphics.fill(startX, startY + uiHeight - footerHeight, startX + uiWidth,
                startY + uiHeight - footerHeight + 1, 0xFF555555);

        // 绘制列表框背景
        int listStartY = startY + headerHeight;
        int listEndY = startY + uiHeight - footerHeight;
        int listWidth = uiWidth - 16;

        // 黑色半透明背景
        guiGraphics.fill(startX + 8, listStartY + 5, startX + 8 + listWidth, listEndY - 5, LIST_BG_COLOR);
        // 边框
        guiGraphics.renderOutline(startX + 8, listStartY + 5, listWidth, listEndY - listStartY - 10, LIST_BORDER_COLOR);

        // 空状态提示
        if (nodes.isEmpty()) {
            String emptyText = "暂无对话节点，点击上方按钮添加";
            int textX = centerX - this.font.width(emptyText) / 2;
            int textY = listStartY + (listEndY - listStartY) / 2 - 4;
            guiGraphics.drawString(this.font, emptyText, textX, textY, 0x888888, false);
        }

        // 渲染按钮组件
        super.render(guiGraphics, mouseX, mouseY, partialTicks);

        // 页码显示
        int maxPages = Math.max(1, (int) Math.ceil((double) nodes.size() / nodesPerPage));
        String pageInfo = String.format("第 %d/%d 页", currentPage + 1, maxPages);
        guiGraphics.drawString(this.font, pageInfo, centerX - this.font.width(pageInfo) / 2,
                startY + uiHeight - footerHeight + 12, 0xAAAAAA, false);

        // 鼠标悬停提示
        for (var widget : this.renderables) {
            if (widget instanceof Button button && button.isMouseOver(mouseX, mouseY)) {
                String text = button.getMessage().getString();

                // 按钮功能提示
                if (text.equals("★") || text.equals("↑")) {
                    guiGraphics.renderTooltip(this.font, Component.literal("置顶/取消置顶"), mouseX, mouseY);
                } else if (text.equals("✓") || text.equals("起")) {
                    guiGraphics.renderTooltip(this.font, Component.literal("设为起始节点"), mouseX, mouseY);
                } else if (text.equals("E")) {
                    guiGraphics.renderTooltip(this.font, Component.literal("编辑节点"), mouseX, mouseY);
                } else if (text.equals("X")) {
                    guiGraphics.renderTooltip(this.font, Component.literal("删除节点"), mouseX, mouseY);
                } else if (text.equals("1") && button.getX() == startX + 10) {
                    guiGraphics.renderTooltip(this.font, Component.literal("跳转到第一页"), mouseX, mouseY);
                } else if (text.equals(String.valueOf(maxPages)) && button.getX() == startX + uiWidth - 30) {
                    guiGraphics.renderTooltip(this.font, Component.literal("跳转到最后一页"), mouseX, mouseY);
                }

                // 节点按钮的额外提示
                if (widget instanceof NodeButton nodeButton && nodeButton.getMessage().getString().contains("▶")) {
                    guiGraphics.renderTooltip(this.font, Component.literal("这是起始节点"), mouseX, mouseY);
                } else if (widget instanceof NodeButton nodeButton && nodeButton.getMessage().getString().contains("★")) {
                    guiGraphics.renderTooltip(this.font, Component.literal("这是置顶节点"), mouseX, mouseY);
                }
            }
        }
    }

    private String formatNodeDisplayText(DialogueNode node, boolean isStartNode, boolean isTopNode) {
        String nodeId = node.getNodeId();

        // 根据UI宽度动态截断节点ID
        int maxLength = Math.max(10, (uiWidth - 180) / 6);
        if (nodeId.length() > maxLength) {
            nodeId = nodeId.substring(0, maxLength - 3) + "...";
        }

        // 添加图标前缀
        String prefix = "";
        if (isStartNode) prefix += "▶ ";
        if (isTopNode && !isStartNode) prefix += "★ "; // 起始节点不显示置顶符号

        int optionCount = node.getOptions().size();
        String suffix = optionCount > 0 ? " (" + optionCount + "个选项)" : "";

        return prefix + nodeId + suffix;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (delta > 0 && currentPage > 0) {
            currentPage--;
            init();
            return true;
        }
        if (delta < 0) {
            int maxPages = Math.max(1, (int) Math.ceil((double) nodes.size() / nodesPerPage));
            if (currentPage < maxPages - 1) {
                currentPage++;
                init();
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private class NodeButton extends Button {
        private final boolean isStartNode;
        private final boolean isTopNode;

        public NodeButton(int x, int y, int width, int height, Component message, OnPress onPress,
                          boolean isStartNode, boolean isTopNode) {
            super(x, y, width, height, message, onPress, DEFAULT_NARRATION);
            this.isStartNode = isStartNode;
            this.isTopNode = isTopNode;
        }

        @Override
        public void renderWidget(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
            // 根据节点状态选择颜色
            int bgColor;
            if (isStartNode) {
                // 起始节点：绿色背景
                bgColor = isHovered() ? 0x9966BB6A : 0x994CAF50;
            } else if (isTopNode) {
                // 置顶节点：橙色背景
                bgColor = isHovered() ? 0x99FFB74D : 0x99FF9800;
            } else {
                // 普通节点：灰色背景
                bgColor = isHovered() ? 0x995A5A5A : 0x99444444;
            }

            // 绘制背景
            guiGraphics.fill(getX(), getY(), getX() + width, getY() + height, bgColor);

            // 绘制边框
            int borderColor = isHovered() ? 0xFF888888 : 0xFF555555;
            guiGraphics.renderOutline(getX(), getY(), width, height, borderColor);

            // 绘制左侧标识条
            if (isStartNode) {
                // 起始节点：绿色条
                guiGraphics.fill(getX(), getY(), getX() + 4, getY() + height, START_NODE_COLOR);
            } else if (isTopNode) {
                // 置顶节点：橙色条
                guiGraphics.fill(getX(), getY(), getX() + 4, getY() + height, TOP_NODE_COLOR);
            }

            // 绘制文本
            int textColor = 0xFFFFFF; // 白色文本
            int textX = getX() + 8;
            int textY = getY() + (height - 8) / 2;

            guiGraphics.drawString(NpcEditorScreen.this.font, getMessage(), textX, textY, textColor, false);

            // 鼠标悬停效果
            if (isHovered()) {
                guiGraphics.fill(getX(), getY(), getX() + width, getY() + height, 0x33FFFFFF);
            }
        }
    }
}