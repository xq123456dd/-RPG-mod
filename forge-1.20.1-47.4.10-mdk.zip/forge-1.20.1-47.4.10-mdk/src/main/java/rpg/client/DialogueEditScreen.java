package rpg.client;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import rpg.data.DialogueNode;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class DialogueEditScreen extends Screen {

    private static final Logger LOGGER = LogManager.getLogger();

    private final Screen parent;
    private DialogueNode editingNode;
    private final String currentNpcName;
    private final boolean isNewNode;

    // UI 组件
    private EditBox nodeIdInput;
    private MultilineEditBox dialogueText;
    private EditBox speakerName;
    private EditBox tagsInput;

    private String statusMessage = "";
    private long statusMessageTime = 0;
    private int statusColor = 0xFFFFFF;

    // 布局常量
    private int panelX, panelY, panelWidth, panelHeight;
    private int imgAreaX, imgAreaY, imgAreaW, imgAreaH;

    // 预览用的缩略图列表
    private final List<ThumbnailPreview> thumbnails = new ArrayList<>();
    // 根目录
    private static final File ROOT_IMAGE_DIR = new File(Minecraft.getInstance().gameDirectory, "rpg_images");
    private static final int THUMB_SIZE = 48; // 缩略图大小

    static {
        if (!ROOT_IMAGE_DIR.exists()) ROOT_IMAGE_DIR.mkdirs();
    }

    // 仅用于在此界面显示缩略图，不负责位置
    private static class ThumbnailPreview {
        ResourceLocation texture;
        DynamicTexture dynamicTexture;
        String fileName;

        ThumbnailPreview(ResourceLocation texture, DynamicTexture dynamicTexture, String fileName) {
            this.texture = texture;
            this.dynamicTexture = dynamicTexture;
            this.fileName = fileName;
        }
    }

    public DialogueEditScreen(Screen parent, DialogueNode node, String npcName, boolean isNew) {
        super(Component.literal(isNew ? "新建对话节点" : "编辑对话节点"));
        this.parent = parent;
        this.editingNode = node;
        this.currentNpcName = npcName;
        this.isNewNode = isNew;
    }

    @Override
    protected void init() {
        super.init();

        this.panelWidth = 380;
        this.panelHeight = 260;

        if (this.width < panelWidth + 20) this.panelWidth = this.width - 20;
        if (this.height < panelHeight + 20) this.panelHeight = this.height - 20;

        this.panelX = (this.width - panelWidth) / 2;
        this.panelY = (this.height - panelHeight) / 2;

        int contentX = panelX + 15;
        int contentY = panelY + 35;
        int gap = 12;

        int leftColW = (int) ((panelWidth - 45) * 0.55);
        int rightColW = (panelWidth - 45) - leftColW;
        int rightColX = contentX + leftColW + 15;

        // --- 左侧：表单区 ---
        this.nodeIdInput = new EditBox(this.font, contentX, contentY, leftColW, 18, Component.literal("ID"));
        this.nodeIdInput.setMaxLength(50);
        this.addRenderableWidget(this.nodeIdInput);

        int currentY = contentY + 18 + gap + 10;
        this.speakerName = new EditBox(this.font, contentX, currentY, leftColW, 18, Component.literal("Speaker"));
        this.speakerName.setMaxLength(50);
        this.addRenderableWidget(this.speakerName);

        currentY += 18 + gap + 10;
        this.tagsInput = new EditBox(this.font, contentX, currentY, leftColW, 18, Component.literal("Tags"));
        this.tagsInput.setMaxLength(100);
        this.addRenderableWidget(this.tagsInput);

        currentY += 18 + gap + 10;
        int bottomAreaHeight = 30;
        int availableH = (panelY + panelHeight - bottomAreaHeight - 10) - currentY;
        this.dialogueText = new MultilineEditBox(this.font, contentX, currentY, leftColW, availableH, Component.literal("Text"));
        this.addRenderableWidget(this.dialogueText);

        // --- 右侧：图片区 ---

        // 1. 文件夹操作按钮
        int btnW = (rightColW - 4) / 2;
        this.addRenderableWidget(Button.builder(Component.literal("📂 打开文件夹"), btn -> openNodeFolder())
                .bounds(rightColX, contentY - 10, btnW, 20).build());

        this.addRenderableWidget(Button.builder(Component.literal("🔄 刷新列表"), btn -> reloadImages())
                .bounds(rightColX + btnW + 4, contentY - 10, btnW, 20).build());

        // 2. 可视化调整按钮 (核心新功能)
        this.addRenderableWidget(Button.builder(Component.literal("✨ 可视化调整位置 (HUD)"), btn -> openPositionEditor())
                .bounds(rightColX, contentY + 15, rightColW, 20).build());

        // 3. 缩略图列表区
        this.imgAreaX = rightColX;
        this.imgAreaY = contentY + 40;
        this.imgAreaW = rightColW;
        this.imgAreaH = (panelY + panelHeight - bottomAreaHeight - 45) - 40; // 减去上面的按钮空间

        // --- 底部按钮 ---
        int btnY = panelY + panelHeight - 25;
        int mainBtnW = 60;
        int startBtnX = panelX + (panelWidth - (mainBtnW * 3 + 10)) / 2;

        this.addRenderableWidget(Button.builder(Component.literal("选项..."), btn -> this.openOptionsScreen())
                .bounds(startBtnX, btnY, mainBtnW, 20).build());

        this.addRenderableWidget(Button.builder(Component.literal("保存"), btn -> this.saveChanges())
                .bounds(startBtnX + mainBtnW + 5, btnY, mainBtnW, 20).build());

        this.addRenderableWidget(Button.builder(Component.literal("取消"), btn -> this.onClose())
                .bounds(startBtnX + (mainBtnW + 5) * 2, btnY, mainBtnW, 20).build());

        loadNodeData();

        // 如果有ID，尝试加载一次图片
        if (!nodeIdInput.getValue().isEmpty()) {
            reloadImages();
        }
    }

    private void loadNodeData() {
        if (!isNewNode) {
            this.nodeIdInput.setValue(editingNode.getNodeId() != null ? editingNode.getNodeId() : "");
            this.speakerName.setValue(editingNode.getSpeakerName() != null ? editingNode.getSpeakerName() : "");
            this.dialogueText.setValue(editingNode.getNpcText() != null ? editingNode.getNpcText() : "");
            this.tagsInput.setValue(String.join(", ", editingNode.getTags()));
        } else {
            this.nodeIdInput.setValue("");
            this.speakerName.setValue(currentNpcName);
            this.dialogueText.setValue("");
        }
        setInitialFocus(this.nodeIdInput);
    }

    /**
     * 获取当前节点的专属文件夹路径
     */
    private File getCurrentNodeDir() {
        String id = nodeIdInput.getValue().trim();
        if (id.isEmpty()) return null;
        // 过滤非法字符，防止文件名错误
        String safeId = id.replaceAll("[^a-zA-Z0-9_\\-]", "_");
        return new File(ROOT_IMAGE_DIR, safeId);
    }

    private void openNodeFolder() {
        File dir = getCurrentNodeDir();
        if (dir == null) {
            setStatus("请先输入节点 ID", 0xFFFF55);
            return;
        }
        if (!dir.exists()) dir.mkdirs();

        try {
            Util.getPlatform().openUri(dir.toURI());
            setStatus("文件夹已打开，请放入图片", 0x55FF55);
        } catch (Exception e) {
            setStatus("打开失败: " + e.getMessage(), 0xFF5555);
        }
    }

    /**
     * 打开全屏可视化编辑器
     */
    private void openPositionEditor() {
        // 先临时保存数据，以便编辑器能读取到最新的ID和文本
        updateNodeFromFields();

        if (editingNode.getNodeId() == null || editingNode.getNodeId().isEmpty()) {
            setStatus("必须先填写节点ID", 0xFF5555);
            return;
        }

        // 切换屏幕
        this.minecraft.setScreen(new ImagePositionScreen(this, editingNode));
    }

    private void reloadImages() {
        clearThumbnails();
        File dir = getCurrentNodeDir();

        if (dir == null) return;
        if (!dir.exists()) return; // 文件夹不存在则不加载

        File[] files = dir.listFiles((d, name) ->
                name.toLowerCase().endsWith(".png") || name.toLowerCase().endsWith(".jpg")
        );

        if (files == null) return;

        List<DialogueNode.ImageData> nodeImages = editingNode.getImages();

        // 【修复】确保图片路径正确
        // 这里的路径保存为 "rpg_images/节点ID/文件名.png"
        String folderName = dir.getName();
        String folderPrefix = "rpg_images/" + folderName + "/";

        // 清理不存在的图片
        nodeImages.removeIf(imgData -> {
            String path = imgData.getPath();
            // 如果图片路径不以当前文件夹前缀开头，删除
            if (!path.startsWith(folderPrefix)) {
                return true;
            }
            // 提取文件名
            String fileName = path.substring(folderPrefix.length());
            File imgFile = new File(dir, fileName);
            return !imgFile.exists();
        });

        // 添加新图片
        for (File f : files) {
            String fullPath = folderPrefix + f.getName();
            boolean exists = nodeImages.stream().anyMatch(img -> img.getPath().equals(fullPath));

            if (!exists) {
                // 新图片默认坐标 (100, 100)，缩放比例1.0
                DialogueNode.ImageData newImage = new DialogueNode.ImageData(fullPath, 100, 100);
                newImage.setScale(1.0f); // 设置默认缩放比例
                nodeImages.add(newImage);
            }
        }

        // 2. 加载缩略图用于列表显示
        for (DialogueNode.ImageData imgData : nodeImages) {
            // 检查该图片是否属于当前节点文件夹
            if (!imgData.getPath().startsWith(folderPrefix)) continue;

            File imgFile = new File(Minecraft.getInstance().gameDirectory, imgData.getPath());
            if (imgFile.exists()) {
                try {
                    NativeImage nativeImg = NativeImage.read(new FileInputStream(imgFile));
                    DynamicTexture dynTex = new DynamicTexture(nativeImg);
                    ResourceLocation res = Minecraft.getInstance().getTextureManager()
                            .register("thumb_" + System.currentTimeMillis(), dynTex);

                    thumbnails.add(new ThumbnailPreview(res, dynTex, imgFile.getName()));
                } catch (IOException e) {
                    LOGGER.warn("加载缩略图失败: " + imgFile);
                }
            }
        }

        setStatus("已加载 " + thumbnails.size() + " 张图片", 0x55FF55);
    }

    private void clearThumbnails() {
        for (ThumbnailPreview t : thumbnails) {
            t.dynamicTexture.close();
            Minecraft.getInstance().getTextureManager().release(t.texture);
        }
        thumbnails.clear();
    }

    private void updateNodeFromFields() {

        editingNode.setSpeakerName(speakerName.getValue().trim());
        editingNode.setNpcText(dialogueText.getValue());
        List<String> tags = Arrays.stream(tagsInput.getValue().split(","))
                .map(String::trim).filter(s -> !s.isEmpty()).collect(Collectors.toList());
        editingNode.setTags(tags);
    }

    private void saveChanges() {
        String newId = this.nodeIdInput.getValue().trim();
        if (newId.isEmpty()) {
            setStatus("ID不能为空", 0xFF5555);
            return;
        }

        if (isNewNode) {

        } else if (!newId.equals(editingNode.getNodeId())) {
            setStatus("不可修改已有ID", 0xFF5555);
            return;
        }

        updateNodeFromFields();

        if (isNewNode) {
            if (!DialogueManager.getInstance().addNode(editingNode)) {
                setStatus("ID已存在", 0xFF5555);
                return;
            }
        } else {
            DialogueManager.getInstance().syncToServer();
        }
        this.onClose();
    }

    // --- 渲染部分 ---

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTicks) {
        this.renderBackground(g);

        // 面板背景
        g.fill(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xFF212121);
        g.renderOutline(panelX, panelY, panelWidth, panelHeight, 0xFF555555);

        // 标题
        g.fill(panelX, panelY, panelX + panelWidth, panelY + 24, 0xFF303030);
        g.drawCenteredString(this.font, this.title, this.width / 2, panelY + 8, 0xFFFFFF);

        // 标签
        int labelColor = 0xAAAAAA;
        g.drawString(this.font, "ID:", nodeIdInput.getX(), nodeIdInput.getY() - 10, labelColor);
        g.drawString(this.font, "说话者:", speakerName.getX(), speakerName.getY() - 10, labelColor);
        g.drawString(this.font, "标签:", tagsInput.getX(), tagsInput.getY() - 10, labelColor);
        g.drawString(this.font, "文本:", dialogueText.getX(), dialogueText.getY() - 10, labelColor);

        // 图片列表区背景
        g.drawString(this.font, "", imgAreaX, imgAreaY - 12, 0xFFD700);
        g.fill(imgAreaX, imgAreaY, imgAreaX + imgAreaW, imgAreaY + imgAreaH, 0xFF151515);
        g.renderOutline(imgAreaX, imgAreaY, imgAreaW, imgAreaH, 0xFF444444);

        // 渲染缩略图列表 (简单的网格排列)
        double scale = Minecraft.getInstance().getWindow().getGuiScale();
        RenderSystem.enableScissor(
                (int)(imgAreaX * scale),
                (int)((this.height - (imgAreaY + imgAreaH)) * scale),
                (int)(imgAreaW * scale),
                (int)(imgAreaH * scale)
        );

        int gridX = imgAreaX + 5;
        int gridY = imgAreaY + 5;

        for (ThumbnailPreview t : thumbnails) {
            g.blit(t.texture, gridX, gridY, 0, 0, THUMB_SIZE, THUMB_SIZE, THUMB_SIZE, THUMB_SIZE);

            // 悬停显示文件名
            if (mouseX >= gridX && mouseX <= gridX + THUMB_SIZE && mouseY >= gridY && mouseY <= gridY + THUMB_SIZE) {
                g.renderOutline(gridX, gridY, THUMB_SIZE, THUMB_SIZE, 0xFFFFFFFF);
                g.renderTooltip(this.font, Component.literal(t.fileName), mouseX, mouseY);
            }

            // 换行逻辑
            gridX += THUMB_SIZE + 5;
            if (gridX + THUMB_SIZE > imgAreaX + imgAreaW) {
                gridX = imgAreaX + 5;
                gridY += THUMB_SIZE + 5;
            }
        }
        RenderSystem.disableScissor();

        super.render(g, mouseX, mouseY, partialTicks);

        if (!statusMessage.isEmpty() && System.currentTimeMillis() - statusMessageTime < 3000) {
            g.drawCenteredString(this.font, Component.literal(statusMessage), this.width / 2, panelY + panelHeight + 5, statusColor);
        }
    }

    private void setStatus(String msg, int color) {
        this.statusMessage = msg;
        this.statusColor = color;
        this.statusMessageTime = System.currentTimeMillis();
    }

    private void openOptionsScreen() {
        if (this.minecraft != null) {
            updateNodeFromFields();
            this.minecraft.setScreen(new DialogueOptionScreen(this, editingNode));
        }
    }

    @Override
    public void onClose() {
        clearThumbnails();
        if (this.minecraft != null) {
            if (this.parent instanceof NpcEditorScreen npcEditor) {
                npcEditor.loadNodes();
            }
            this.minecraft.setScreen(this.parent);
        }
    }

    @Override
    public boolean isPauseScreen() { return false; }
}