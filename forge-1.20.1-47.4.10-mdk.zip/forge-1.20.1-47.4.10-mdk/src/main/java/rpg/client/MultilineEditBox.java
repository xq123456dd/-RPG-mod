package rpg.client;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.narration.NarratedElementType;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.SharedConstants;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class MultilineEditBox extends AbstractWidget {

    private final Font font;
    private String value = "";
    private Consumer<String> responder;
    private int maxTextLength = 32767;
    private int cursorPos = 0; // 绝对光标位置（字符索引）
    private int selectionPos = 0; // 选中起点（暂简单支持）
    private final int lineHeight;
    private List<String> lines = new ArrayList<>();
    private int scrollOffset = 0; // 滚动行数
    private int maxVisibleLines;

    public MultilineEditBox(Font font, int x, int y, int width, int height, Component message) {
        super(x, y, width, height, message);
        this.font = font;
        this.lineHeight = font.lineHeight + 3;
        this.maxVisibleLines = (height - 8) / lineHeight;
        this.responder = s -> {};
        updateLines();
    }

    public void setResponder(Consumer<String> responder) {
        this.responder = responder;
    }

    public void setValue(String value) {
        this.value = value == null ? "" : value;
        this.cursorPos = this.value.length();
        this.selectionPos = this.cursorPos;
        updateLines();
        scrollToCursor();
    }

    public String getValue() {
        return value;
    }

    private void updateLines() {
        lines.clear();
        if (value.isEmpty()) {
            lines.add("");
        } else {
            lines.addAll(List.of(value.split("\n")));
        }
    }

    private void updateValueFromLines() {
        value = String.join("\n", lines);
        responder.accept(value);
    }

    // 获取光标所在行和行内位置
    private int getCursorLine() {
        int pos = 0;
        for (int i = 0; i < lines.size(); i++) {
            int next = pos + lines.get(i).length() + (i < lines.size() - 1 ? 1 : 0);
            if (cursorPos <= next) return i;
            pos = next;
        }
        return lines.size() - 1;
    }

    private int getCursorPosInLine() {
        int pos = 0;
        for (int i = 0; i < getCursorLine(); i++) {
            pos += lines.get(i).length() + 1;
        }
        return cursorPos - pos;
    }

    private void scrollToCursor() {
        int cursorLine = getCursorLine();
        if (cursorLine < scrollOffset) {
            scrollOffset = cursorLine;
        } else if (cursorLine >= scrollOffset + maxVisibleLines) {
            scrollOffset = cursorLine - maxVisibleLines + 1;
        }
        scrollOffset = Mth.clamp(scrollOffset, 0, Math.max(0, lines.size() - maxVisibleLines));
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (isMouseOver(mouseX, mouseY) && button == 0) {
            setFocused(true);
            // 计算点击位置的光标
            int relY = (int) (mouseY - getY() - 4);
            int lineIndex = relY / lineHeight + scrollOffset;
            lineIndex = Mth.clamp(lineIndex, 0, lines.size() - 1);

            int relX = (int) (mouseX - getX() - 4);
            String line = lines.get(lineIndex);
            int charPos = 0;
            while (charPos < line.length()) {
                int w = font.width(line.substring(0, charPos + 1));
                if (w > relX) break;
                charPos++;
            }

            // 计算绝对cursorPos
            int absPos = 0;
            for (int i = 0; i < lineIndex; i++) {
                absPos += lines.get(i).length() + 1;
            }
            absPos += charPos;

            cursorPos = absPos;
            selectionPos = cursorPos;
            scrollToCursor();
            return true;
        }
        return false;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!isFocused()) return false;

        if (keyCode == 257 || keyCode == 335) { // Enter
            insertText("\n");
            return true;
        } else if (keyCode == 259) { // Backspace
            if (cursorPos > 0) {
                value = value.substring(0, cursorPos - 1) + value.substring(cursorPos);
                cursorPos--;
                updateLines();
                scrollToCursor();
                updateValueFromLines();
            }
            return true;
        } else if (keyCode == 261) { // Delete
            if (cursorPos < value.length()) {
                value = value.substring(0, cursorPos) + value.substring(cursorPos + 1);
                updateLines();
                scrollToCursor();
                updateValueFromLines();
            }
            return true;
        } else if (keyCode == 263) { // Left
            if (cursorPos > 0) cursorPos--;
            scrollToCursor();
            return true;
        } else if (keyCode == 262) { // Right
            if (cursorPos < value.length()) cursorPos++;
            scrollToCursor();
            return true;
        } else if (keyCode == 265) { // Up
            int line = getCursorLine();
            if (line > 0) {
                int posInLine = getCursorPosInLine();
                line--;
                String newLine = lines.get(line);
                int newPos = Math.min(posInLine, newLine.length());
                int abs = 0;
                for (int i = 0; i < line; i++) abs += lines.get(i).length() + 1;
                cursorPos = abs + newPos;
                scrollToCursor();
            }
            return true;
        } else if (keyCode == 264) { // Down
            int line = getCursorLine();
            if (line < lines.size() - 1) {
                int posInLine = getCursorPosInLine();
                line++;
                String newLine = lines.get(line);
                int newPos = Math.min(posInLine, newLine.length());
                int abs = 0;
                for (int i = 0; i < line; i++) abs += lines.get(i).length() + 1;
                cursorPos = abs + newPos;
                scrollToCursor();
            }
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (!isFocused() || !SharedConstants.isAllowedChatCharacter(chr)) return false;
        insertText(String.valueOf(chr));
        return true;
    }

    private void insertText(String text) {
        value = value.substring(0, cursorPos) + text + value.substring(cursorPos);
        cursorPos += text.length();
        updateLines();
        scrollToCursor();
        updateValueFromLines();
    }

    @Override
    public void renderWidget(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
        // 背景
        guiGraphics.fill(getX(), getY(), getX() + width, getY() + height, 0xFF000000);
        guiGraphics.renderOutline(getX(), getY(), width, height, isFocused() ? 0xFFFFFFFF : 0xFF888888);

        int textY = getY() + 4;
        for (int i = 0; i < maxVisibleLines && scrollOffset + i < lines.size(); i++) {
            String line = lines.get(scrollOffset + i);
            guiGraphics.drawString(font, line, getX() + 4, textY + i * lineHeight, 0xE0E0E0, false);
        }

        // 光标
        if (isFocused() && (System.currentTimeMillis() / 500 % 2 == 0)) {
            int cursorLine = getCursorLine() - scrollOffset;
            if (cursorLine >= 0 && cursorLine < maxVisibleLines) {
                String line = lines.get(getCursorLine());
                int posInLine = getCursorPosInLine();
                int x = getX() + 4 + font.width(line.substring(0, posInLine));
                int y = getY() + 4 + cursorLine * lineHeight;
                guiGraphics.fill(x, y, x + 1, y + font.lineHeight, 0xFFFFFFFF);
            }
        }
    }

    @Override
    protected void updateWidgetNarration(NarrationElementOutput output) {
        output.add(NarratedElementType.TITLE, Component.literal("多行文本框"));
    }
}