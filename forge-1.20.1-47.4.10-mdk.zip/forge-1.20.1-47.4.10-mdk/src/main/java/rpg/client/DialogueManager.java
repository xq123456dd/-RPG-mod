package rpg.client;

import rpg.data.DialogueNode;
import rpg.data.DialogueOption; // 导入 DialogueOption
import rpg.network.ModPacketHandler;
import rpg.network.UpdateDialogueDataC2SPacket; // 假设此包已更新以接受起始节点 ID

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Iterator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class DialogueManager {
    private static final Logger LOGGER = LogManager.getLogger();

    // 用于客户端编辑的对话节点地图
    private final Map<String, DialogueNode> currentNpcDialogueMap = new ConcurrentHashMap<>();
    private int editingEntityId = -1;
    private String editingNpcName = "";

    // 存储当前编辑NPC的起始节点ID
    private String startNodeId = "";

    private static final DialogueManager INSTANCE = new DialogueManager();

    public static DialogueManager getInstance() {
        return INSTANCE;
    }

    /**
     * 开始编辑一个 NPC 的对话数据
     */
    // 【更新】现在接受 startNodeId
    public void startEditing(int entityId, String npcName, Map<String, DialogueNode> existingNodes, String startNodeId) {
        this.editingEntityId = entityId;
        this.editingNpcName = npcName;
        this.currentNpcDialogueMap.clear();
        this.startNodeId = startNodeId != null ? startNodeId : ""; // 初始化起始节点ID

        // --- 数据清洗 ---
        for (Map.Entry<String, DialogueNode> entry : existingNodes.entrySet()) {
            String key = entry.getKey();
            DialogueNode node = entry.getValue();

            if (key == null || key.trim().isEmpty() || !key.equals(node.getNodeId())) {
                LOGGER.warn("发现并丢弃一个ID为空或不匹配的对话节点: {}", key);
                continue;
            }
            this.currentNpcDialogueMap.put(key, node);
        }
    }

    // -----------------------------------------------------------------------------------------------------
    // 【新增/修复方法】：获取当前编辑的对话地图 (解决 'getCurrentNpcDialogueMap' 错误)
    // -----------------------------------------------------------------------------------------------------
    public Map<String, DialogueNode> getCurrentNpcDialogueMap() {
        return this.currentNpcDialogueMap;
    }


    /**
     * 获取当前编辑的 NPC 的起始节点 ID
     */
    public String getNpcStartNode(String npcName) {
        if (this.editingNpcName.equals(npcName)) {
            return this.startNodeId;
        }
        return "";
    }

    /**
     * 设置当前编辑的 NPC 的起始节点 ID
     */
    public boolean setNpcStartNode(String npcName, String nodeId) {
        if (!this.editingNpcName.equals(npcName) || nodeId == null) {
            return false;
        }

        if (nodeId.isEmpty() || this.currentNpcDialogueMap.containsKey(nodeId)) {
            if (!this.startNodeId.equals(nodeId)) {
                this.startNodeId = nodeId;
                syncToServer();
            }
            return true;
        }

        LOGGER.warn("尝试将NPC {}的起始节点设置为不存在的节点ID: {}", npcName, nodeId);
        return false;
    }


    // -----------------------------------------------------------------------------------------------------
    // 【新增/修复方法】：删除一个节点 (解决 'deleteNode' 错误)
    // -----------------------------------------------------------------------------------------------------
    public void deleteNode(DialogueNode nodeToDelete) {
        if (nodeToDelete == null || nodeToDelete.getNodeId() == null) return;

        String nodeId = nodeToDelete.getNodeId();

        // 1. 从地图中移除节点
        currentNpcDialogueMap.remove(nodeId);

        // 2. 检查是否是起始节点
        if (nodeId.equals(this.startNodeId)) {
            this.startNodeId = "";
        }

        // 3. 遍历所有其他节点，更新指向被删除节点的选项
        for (DialogueNode node : currentNpcDialogueMap.values()) {
            for (DialogueOption option : node.getOptions()) {
                if (nodeId.equals(option.getNextNodeId())) {
                    // 将目标节点ID重置为 END
                    option.setNextNodeId("END");
                }
            }
        }

        syncToServer();
    }


    /**
     * 重命名节点，同时更新所有指向旧 ID 的选项
     */
    public boolean renameNode(String oldId, String newId) {
        // 确保新 ID 不为空且不与现有节点 ID 重复
        if (oldId == null || oldId.isEmpty() || newId == null || newId.isEmpty() || currentNpcDialogueMap.containsKey(newId)) {
            return false;
        }

        DialogueNode oldNode = currentNpcDialogueMap.remove(oldId);
        if (oldNode != null) {
            DialogueNode newNode = oldNode.copyWithNewId(newId);
            currentNpcDialogueMap.put(newId, newNode);

            // 遍历所有节点，更新指向旧 ID 的选项
            for (DialogueNode node : currentNpcDialogueMap.values()) {
                for (DialogueOption option : node.getOptions()) {
                    if (oldId.equals(option.getNextNodeId())) {
                        option.setNextNodeId(newId);
                    }
                }
            }

            // 如果旧 ID 是起始节点，则更新为新 ID
            if (oldId.equals(this.startNodeId)) {
                this.startNodeId = newId;
            }

            syncToServer();
            return true;
        }
        return false;
    }
    public void setStartNodeId(String startNodeId) {
        this.startNodeId = startNodeId != null ? startNodeId.trim() : "";
        syncToServer(); // 保存到服务器
        LOGGER.info("设置起始节点ID为: {}", this.startNodeId);
    }

    // 新增：根据节点ID删除节点
    public void deleteNode(String nodeId) {
        if (nodeId != null && currentNpcDialogueMap.containsKey(nodeId)) {
            currentNpcDialogueMap.remove(nodeId);
            syncToServer();
            LOGGER.info("删除节点: {}", nodeId);
        }
    }
    /**
     * 更新一个节点，通常从编辑屏幕调用
     */
    public void updateNode(DialogueNode node) {
        if (node.getNodeId() == null || node.getNodeId().isEmpty()) {
            LOGGER.error("尝试更新空ID节点，已拦截");
            return;
        }
        currentNpcDialogueMap.put(node.getNodeId(), node);
        syncToServer();
    }

    public void updateNodeWithUndoRedo(DialogueNode node) {
        updateNode(node);
    }

    /**
     * 将当前对话图同步到服务器
     */
    public void syncToServer() {
        if (editingEntityId != -1) {
            ModPacketHandler.sendToServer(new UpdateDialogueDataC2SPacket(
                    editingEntityId,
                    new HashMap<>(currentNpcDialogueMap),
                    this.startNodeId
            ));
        }
    }
    public boolean addNode(DialogueNode node) {
        if (node == null || node.getNodeId() == null || node.getNodeId().isEmpty()) {
            LOGGER.error("尝试添加空ID节点，已拦截");
            return false;
        }

        if (currentNpcDialogueMap.containsKey(node.getNodeId())) {
            LOGGER.warn("节点ID已存在: {}", node.getNodeId());
            return false;
        }

        currentNpcDialogueMap.put(node.getNodeId(), node);
        LOGGER.info("成功添加新节点: {}", node.getNodeId());
        syncToServer();
        return true;
    }

    // --- Getter 方法 ---

    public int getEditingEntityId() {
        return editingEntityId;
    }

    public String getEditingNpcName() {
        return editingNpcName;
    }

    // NpcEditorScreen 中 loadNodes 方法可能会用到 getAllNodes
    public Map<String, DialogueNode> getAllNodes() {
        return currentNpcDialogueMap;
    }

    public DialogueNode getNode(String id) {
        return currentNpcDialogueMap.get(id);
    }
}