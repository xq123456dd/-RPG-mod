package rpg.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import rpg.data.DialogueCommand;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class DialogueCommandEditScreen extends Screen {

    private static final Logger LOGGER = LogManager.getLogger();

    private final Screen parent;
    private final DialogueCommand editingCommand;

    private EditBox commandTypeBox;
    private EditBox commandArgumentBox;

    // UI 常量
    private static final int ELEMENT_WIDTH = 350;
    private static final int ELEMENT_HEIGHT = 20;

    public DialogueCommandEditScreen(Screen parent, DialogueCommand command) {
        // 正确写法：super() 为第一条语句，直接在参数里处理 null
        super(Component.literal("编辑命令: " +
                (command != null && command.getCommandType() != null
                        ? command.getCommandType().trim()
                        : "NONE")));
        this.parent = parent;
        this.editingCommand = command;
    }

    @Override
    protected void init() {
        super.init();
        this.clearWidgets();

        int centerX = this.width / 2;
        int elementX = centerX - ELEMENT_WIDTH / 2;
        int currentY = this.height / 4;

        // 命令类型输入框
        this.commandTypeBox = new EditBox(this.font, elementX, currentY, ELEMENT_WIDTH, ELEMENT_HEIGHT, Component.literal("命令类型"));
        this.commandTypeBox.setValue(editingCommand.getCommandType() != null ? editingCommand.getCommandType() : "NONE");
        this.commandTypeBox.setMaxLength(64);
        this.addRenderableWidget(this.commandTypeBox);
        currentY += ELEMENT_HEIGHT + 20;

        // 命令参数输入框
        this.commandArgumentBox = new EditBox(this.font, elementX, currentY, ELEMENT_WIDTH, ELEMENT_HEIGHT, Component.literal("命令参数"));
        this.commandArgumentBox.setValue(editingCommand.getCommandArgument() != null ? editingCommand.getCommandArgument() : "");
        this.commandArgumentBox.setMaxLength(256);
        this.commandArgumentBox.setHint(Component.literal("例如: diamond 1 或 /say Hello"));
        this.addRenderableWidget(this.commandArgumentBox);

        // 保存和取消按钮
        int buttonY = currentY + 60;
        this.addRenderableWidget(Button.builder(Component.literal("保存"), btn -> saveChanges())
                .bounds(elementX, buttonY, ELEMENT_WIDTH / 2 - 5, ELEMENT_HEIGHT).build());

        this.addRenderableWidget(Button.builder(Component.literal("取消"), btn -> this.onClose())
                .bounds(elementX + ELEMENT_WIDTH / 2 + 5, buttonY, ELEMENT_WIDTH / 2 - 5, ELEMENT_HEIGHT).build());
    }

    private void saveChanges() {
        String type = this.commandTypeBox.getValue().trim();
        if (type.isEmpty()) {
            type = "NONE";
        }
        String arg = this.commandArgumentBox.getValue().trim();

        editingCommand.setCommandType(type);
        editingCommand.setCommandArgument(arg);

        if (this.minecraft != null) {
            this.minecraft.setScreen(this.parent);
        }
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
        this.renderBackground(guiGraphics);
        guiGraphics.drawCenteredString(this.font, this.title, this.width / 2, 20, 0xFFFFFF);

        int centerX = this.width / 2;
        int elementX = centerX - ELEMENT_WIDTH / 2;
        guiGraphics.drawString(this.font, "命令类型:", elementX, this.height / 4 - 12, 0xFFFFFF);
        guiGraphics.drawString(this.font, "命令参数:", elementX, this.height / 4 + ELEMENT_HEIGHT + 20 - 12, 0xFFFFFF);

        super.render(guiGraphics, mouseX, mouseY, partialTicks);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}