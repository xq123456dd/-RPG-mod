package rpg.client.editor;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class ConditionVisualEditor extends Screen {

    // UI 常量
    private static final int WIDTH = 800;
    private static final int HEIGHT = 600;
    private static final int BUTTON_WIDTH = 120;
    private static final int BUTTON_HEIGHT = 20;

    private final Screen parent;
    private final ConditionEditCallback callback;

    // 条件部分列表（后续可扩展为复杂树结构）
    private final List<String> conditionParts = new ArrayList<>();

    public interface ConditionEditCallback {
        void onConditionEdited(String condition);
    }

    public ConditionVisualEditor(Screen parent, String initialCondition, ConditionEditCallback callback) {
        super(Component.literal("条件可视化编辑器"));
        this.parent = parent;
        this.callback = callback;

        if (initialCondition != null && !initialCondition.isEmpty()) {
            conditionParts.add(initialCondition.trim());
        }
    }

    @Override
    protected void init() {
        super.init();
        clearWidgets();

        int startX = (width - WIDTH) / 2;
        int startY = (height - HEIGHT) / 2;

        // 添加变量比较按钮
        addRenderableWidget(Button.builder(Component.literal("添加变量比较"), b -> addConditionPart("money >= 100"))
                .bounds(startX + 20, startY + 20, BUTTON_WIDTH + 40, BUTTON_HEIGHT)
                .build());

        // 添加逻辑运算按钮
        addRenderableWidget(Button.builder(Component.literal("添加 AND/OR"), b -> addConditionPart("AND"))
                .bounds(startX + 20, startY + 60, BUTTON_WIDTH + 40, BUTTON_HEIGHT)
                .build());

        // 保存按钮
        addRenderableWidget(Button.builder(Component.literal("保存"), b -> saveCondition())
                .bounds(startX + WIDTH - BUTTON_WIDTH - 20, startY + HEIGHT - 60, BUTTON_WIDTH, BUTTON_HEIGHT)
                .build());

        // 取消按钮
        addRenderableWidget(Button.builder(Component.literal("取消"), b -> onClose())
                .bounds(startX + WIDTH - 2 * (BUTTON_WIDTH + 20), startY + HEIGHT - 60, BUTTON_WIDTH, BUTTON_HEIGHT)
                .build());
    }

    /**
     * 提取的公共方法：添加一个条件部分并刷新界面
     */
    private void addConditionPart(String part) {
        conditionParts.add(part);
        init(); // 刷新按钮和预览
    }

    private void saveCondition() {
        String built = String.join(" ", conditionParts);
        callback.onConditionEdited(built.isEmpty() ? "" : built);
        onClose();
    }

    @Override
    public void render(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
        renderBackground(guiGraphics);

        int startX = (width - WIDTH) / 2;
        int startY = (height - HEIGHT) / 2;

        guiGraphics.fill(startX, startY, startX + WIDTH, startY + HEIGHT, 0xAA000000);
        guiGraphics.drawCenteredString(font, title, width / 2, startY + 15, 0xFFFFFF);

        String preview = "当前条件: " + (conditionParts.isEmpty() ? "<空>" : String.join(" ", conditionParts));
        guiGraphics.drawString(font, preview, startX + 20, startY + 120, 0xCCCCCC);

        guiGraphics.fill(startX + 210, startY + 40, startX + 215, startY + HEIGHT - 60, 0x55FFFFFF);

        super.render(guiGraphics, mouseX, mouseY, partialTicks);
    }

    @Override
    public void onClose() {
        if (minecraft != null) {
            minecraft.setScreen(parent);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}