package rpg.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
import rpg.data.DialogueNode;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CreateNodeScreen extends Screen {
    private static final Logger LOGGER = LogManager.getLogger();

    private final NpcEditorScreen parentScreen;
    private final String entityName;
    private EditBox nodeNameField;
    private Button createButton;

    // UI参数
    private int uiWidth = 250;
    private int uiHeight = 100;
    private int buttonHeight = 20;

    public CreateNodeScreen(NpcEditorScreen parentScreen, String entityName) {
        super(Component.literal("创建新节点"));
        this.parentScreen = parentScreen;
        this.entityName = entityName;
    }

    @Override
    protected void init() {
        super.init();

        int centerX = this.width / 2;
        int centerY = this.height / 2;
        int startX = centerX - uiWidth / 2;
        int startY = centerY - uiHeight / 2;

        // 节点名称输入框
        this.nodeNameField = new EditBox(this.font, startX + 10, startY + 30, uiWidth - 20, buttonHeight,
                Component.literal("节点名称"));
        this.nodeNameField.setMaxLength(50);
        this.nodeNameField.setValue("新节点"); // 默认名称，用户可以修改
        this.nodeNameField.setFocused(true);
        this.addRenderableWidget(this.nodeNameField);

        // 创建按钮
        this.createButton = Button.builder(Component.literal("创建"), btn -> {
            createNewNode();
        }).bounds(startX + 10, startY + 60, (uiWidth - 30) / 2, buttonHeight).build();
        this.addRenderableWidget(this.createButton);

        // 取消按钮
        this.addRenderableWidget(Button.builder(Component.literal("取消"), btn -> {
            this.minecraft.setScreen(parentScreen);
        }).bounds(startX + 20 + (uiWidth - 30) / 2, startY + 60, (uiWidth - 30) / 2, buttonHeight).build());
    }

    private void createNewNode() {
        String nodeName = this.nodeNameField.getValue().trim();

        if (nodeName.isEmpty()) {
            nodeName = "未命名节点";
        }

        // 检查节点ID是否已存在
        boolean exists = DialogueManager.getInstance().getAllNodes().containsKey(nodeName);
        int counter = 1;
        String originalName = nodeName;

        // 如果已存在，添加数字后缀直到找到不重复的名称
        while (exists) {
            nodeName = originalName + "_" + counter;
            exists = DialogueManager.getInstance().getAllNodes().containsKey(nodeName);
            counter++;
        }

        // 创建新节点
        DialogueNode newNode = new DialogueNode(nodeName);
        DialogueManager.getInstance().addNode(newNode);

        // 返回父界面
        this.minecraft.setScreen(parentScreen);
        parentScreen.loadNodes();
        parentScreen.init();

        // 提示信息
        LOGGER.info("创建新节点: {}", nodeName);
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
        this.renderBackground(guiGraphics);

        int centerX = this.width / 2;
        int centerY = this.height / 2;
        int startX = centerX - uiWidth / 2;
        int startY = centerY - uiHeight / 2;

        // 绘制UI背景
        guiGraphics.fill(startX, startY, startX + uiWidth, startY + uiHeight, 0xDD000000);
        guiGraphics.renderOutline(startX, startY, uiWidth, uiHeight, 0xFF4A4A4A);

        // 标题
        guiGraphics.drawCenteredString(this.font, "创建新对话节点", centerX, startY + 10, 0xFFFFFF);

        // 提示文本
        guiGraphics.drawString(this.font, "请输入节点名称:", startX + 10, startY + 15, 0xAAAAAA, false);

        // 渲染所有组件
        super.render(guiGraphics, mouseX, mouseY, partialTicks);

        // 输入框光标闪烁
        this.nodeNameField.render(guiGraphics, mouseX, mouseY, partialTicks);

        // 显示当前NPC信息
        guiGraphics.drawCenteredString(this.font,
                Component.literal("NPC: ").append(Component.literal(entityName).withStyle(ChatFormatting.YELLOW)),
                centerX, startY + 80, 0xAAAAAA);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 257) { // Enter键
            createNewNode();
            return true;
        } else if (keyCode == 256) { // ESC键
            this.minecraft.setScreen(parentScreen);
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void tick() {
        this.nodeNameField.tick();

        // 启用/禁用创建按钮
        boolean canCreate = !this.nodeNameField.getValue().trim().isEmpty();
        this.createButton.active = canCreate;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}