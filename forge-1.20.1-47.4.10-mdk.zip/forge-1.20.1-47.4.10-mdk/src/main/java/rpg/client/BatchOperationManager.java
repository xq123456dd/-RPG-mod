package rpg.client;
import rpg.data.DialogueNode;
import rpg.data.DialogueOption;

import java.util.Map;
import java.util.regex.Pattern;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 批量操作管理器
 * 当前主要提供文本查找替换功能
 */
public class BatchOperationManager {

    private static final Logger LOGGER = LogManager.getLogger();

    private static final BatchOperationManager INSTANCE = new BatchOperationManager();

    public static BatchOperationManager getInstance() {
        return INSTANCE;
    }

    /**
     * 批量查找并替换文本（支持 NPC 对话文本 和 选项文本）
     *
     * @param nodeMap     当前NPC的所有对话节点
     * @param find        要查找的文本
     * @param replace     替换为的文本
     * @param matchCase   是否区分大小写
     * @param wholeWord   是否全词匹配
     * @return 实际替换的次数
     */
    public int batchFindAndReplace(Map<String, DialogueNode> nodeMap,
                                   String find,
                                   String replace,
                                   boolean matchCase,
                                   boolean wholeWord) {
        if (find == null || find.isEmpty()) {
            return 0;
        }

        int totalReplaced = 0;
        String findText = matchCase ? find : find.toLowerCase();

        for (DialogueNode node : nodeMap.values()) {
            // 替换 NPC 文本
            String npcText = node.getNpcText();
            if (npcText != null) {
                String processedNpcText = matchCase ? npcText : npcText.toLowerCase();
                if (matches(processedNpcText, findText, wholeWord)) {
                    String newNpcText = npcText.replace(find, replace);
                    node.setNpcText(newNpcText);
                    totalReplaced++;
                }
            }

            // 替换所有选项文本
            for (DialogueOption option : node.getOptions()) {
                String optionText = option.getOptionText();
                if (optionText != null) {
                    String processedOptionText = matchCase ? optionText : optionText.toLowerCase();
                    if (matches(processedOptionText, findText, wholeWord)) {
                        String newOptionText = optionText.replace(find, replace);
                        option.setOptionText(newOptionText);
                        totalReplaced++;
                    }
                }
            }
        }

        // 替换完成后同步到服务器
        DialogueManager.getInstance().syncToServer();
        LOGGER.info("批量查找替换完成：替换了 {} 处，查找=\"{}\", 替换为=\"{}\"", totalReplaced, find, replace);
        return totalReplaced;
    }

    /**
     * 判断文本是否匹配（支持全词匹配）
     */
    private boolean matches(String text, String find, boolean wholeWord) {
        if (text == null) return false;
        if (wholeWord) {
            Pattern p = Pattern.compile("\\b" + Pattern.quote(find) + "\\b");
            return p.matcher(text).find();
        } else {
            return text.contains(find);
        }
    }
}