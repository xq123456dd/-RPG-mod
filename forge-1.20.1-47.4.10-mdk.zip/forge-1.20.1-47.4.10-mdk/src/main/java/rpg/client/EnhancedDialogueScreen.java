package rpg.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import rpg.RpgDialogueMod;
import rpg.data.DialogueNode;
import rpg.data.DialogueOption;
import rpg.network.ModPacketHandler;
import rpg.network.SelectOptionC2SPacket;
import rpg.network.CloseDialogueC2SPacket;
import java.nio.file.Files;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.renderer.texture.DynamicTexture;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class EnhancedDialogueScreen extends Screen {

    // ==================== 图片渲染相关 ====================
    private final List<DynamicTexture> imageTextures = new ArrayList<>();
    private final List<ResourceLocation> imageResources = new ArrayList<>();
    private final List<Integer> imageWidths = new ArrayList<>();
    private final List<Integer> imageHeights = new ArrayList<>();
    private final List<DialogueNode.ImageData> currentImageData = new ArrayList<>(); // 存储图片数据用于渲染
    private boolean imagesLoaded = false;

    private void loadNodeImages() {
        if (imagesLoaded || currentNode == null || currentNode.getImages().isEmpty()) return;

        Minecraft mc = Minecraft.getInstance();
        File imageDir = new File(mc.gameDirectory, "rpg_images");

        currentImageData.clear(); // 清空旧数据

        for (DialogueNode.ImageData imgData : currentNode.getImages()) {
            // 保存图片数据
            currentImageData.add(imgData);

            // 加载图片纹理
            String fileName = imgData.getPath().substring("rpg_images/".length());
            File imgFile = new File(imageDir, fileName);

            if (imgFile.exists()) {
                try (NativeImage nativeImg = NativeImage.read(Files.newInputStream(imgFile.toPath()))) {
                    int w = nativeImg.getWidth();
                    int h = nativeImg.getHeight();
                    imageWidths.add(w);
                    imageHeights.add(h);

                    DynamicTexture dynTex = new DynamicTexture(nativeImg);
                    ResourceLocation res = mc.getTextureManager()
                            .register("dialogue_runtime_" + UUID.randomUUID(), dynTex);
                    imageTextures.add(dynTex);
                    imageResources.add(res);
                } catch (IOException e) {
                    // 静默忽略损坏的图片
                }
            }
        }
        imagesLoaded = true;
    }

    private void clearImages() {
        for (DynamicTexture tex : imageTextures) {
            tex.close();
        }
        imageTextures.clear();
        imageResources.clear();
        imageWidths.clear();
        imageHeights.clear();
        currentImageData.clear(); // 清空图片数据
        imagesLoaded = false;
    }
    // ============================================================

    public int getEntityId() {
        return entityId;
    }

    public enum AnimationState {
        FADE_IN, TEXT_TYPING, IDLE, FADE_OUT
    }

    private static final ResourceLocation DIALOGUE_BOX =
            ResourceLocation.fromNamespaceAndPath(RpgDialogueMod.MOD_ID, "textures/gui/dialogue_box.png");
    private static final ResourceLocation DIALOGUE_BUTTON =
            ResourceLocation.fromNamespaceAndPath(RpgDialogueMod.MOD_ID, "textures/gui/dialogue_button.png");

    private DialogueNode currentNode;
    private int textDisplayTimer = 0;
    private int displayedCharCount = 0;
    private boolean fullyDisplayed = false;
    private final int entityId;

    private boolean isBroadcast = false;

    private final int BOX_WIDTH = 400;
    private final int BOX_HEIGHT = 120;
    private final int BUTTON_WIDTH = 140;
    private final int BUTTON_HEIGHT = 25;

    private final int BOX_BORDER = 10;

    private final int BUTTON_BORDER_LEFT = 20;
    private final int BUTTON_BORDER_TOP = 20;
    private final int BUTTON_BORDER_RIGHT = 20;
    private final int BUTTON_BORDER_BOTTOM = 20;

    private final int BUTTON_TEXTURE_WIDTH = 1479;
    private final int BUTTON_TEXTURE_HEIGHT = 509;

    private final int BOX_Y = 135;

    private static class DialogueButton {
        int x, y, width, height;
        String text;
        int optionIndex;

        DialogueButton(int x, int y, int width, int height, String text, int optionIndex) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
            this.text = text;
            this.optionIndex = optionIndex;
        }
    }

    private final List<DialogueButton> dialogueButtons = new ArrayList<>();

    private AnimationState animationState = AnimationState.FADE_IN;
    private float fadeAlpha = 0.0f;
    private float typingSpeed = 5.0f;
    private boolean skipRequested = false;
    private float textReveal = 0.0f;

    public EnhancedDialogueScreen(DialogueNode startNode, int entityId) {
        super(Component.literal("对话"));
        this.currentNode = startNode;
        this.entityId = entityId;
        this.isBroadcast = false;
    }

    public EnhancedDialogueScreen(DialogueNode startNode, int entityId, boolean isBroadcast) {
        super(Component.literal("对话"));
        this.currentNode = startNode;
        this.entityId = entityId;
        this.isBroadcast = isBroadcast;
    }

    @Override
    public void tick() {
        super.tick();

        switch (animationState) {
            case FADE_IN:
                fadeAlpha = Math.min(fadeAlpha + 0.05f, 1.0f);
                if (fadeAlpha >= 0.95f) {
                    animationState = AnimationState.TEXT_TYPING;
                }
                break;

            case TEXT_TYPING:
                if (currentNode != null) {
                    textDisplayTimer++;
                    if (skipRequested) {
                        displayedCharCount = currentNode.getNpcText().length();
                        fullyDisplayed = true;
                        textReveal = 1.0f;
                        animationState = AnimationState.IDLE;
                        recreateButtons();
                    } else {
                        displayedCharCount = (int) (textDisplayTimer * typingSpeed);
                        if (displayedCharCount >= currentNode.getNpcText().length()) {
                            displayedCharCount = currentNode.getNpcText().length();
                            fullyDisplayed = true;
                            textReveal = 1.0f;
                            animationState = AnimationState.IDLE;
                            recreateButtons();
                        }
                    }
                    if (!skipRequested) {
                        textReveal = Mth.lerp(0.1f, textReveal, Math.min(displayedCharCount / (float) currentNode.getNpcText().length(), 1.0f));
                    }
                }
                break;

            case FADE_OUT:
                fadeAlpha = Math.max(fadeAlpha - 0.08f, 0.0f);
                if (fadeAlpha <= 0.05f) {
                    this.onClose();
                }
                break;
        }
    }

    private void recreateButtons() {
        dialogueButtons.clear();

        if (currentNode == null || currentNode.getOptions().isEmpty()) {
            return;
        }

        int dialogWidth = BOX_WIDTH;
        int dialogHeight = BOX_HEIGHT;
        int dialogLeftX = (width - dialogWidth) / 2;
        int dialogTopY = BOX_Y + (BOX_HEIGHT - dialogHeight) / 2;

        int buttonX = dialogLeftX + dialogWidth - BUTTON_WIDTH + 10;

        int fixedLastButtonY = dialogTopY - 25;

        List<DialogueOption> options = currentNode.getOptions();
        int buttonCount = options.size();

        for (int i = 0; i < buttonCount; i++) {
            int optionIndex = buttonCount - 1 - i;
            DialogueOption option = options.get(optionIndex);

            int buttonY = fixedLastButtonY - i * (BUTTON_HEIGHT + 8);

            dialogueButtons.add(new DialogueButton(buttonX, buttonY, BUTTON_WIDTH, BUTTON_HEIGHT,
                    option.getOptionText(), optionIndex));
        }
    }

    @Override
    protected void init() {}

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
        // 半透明背景
        int backgroundAlpha = (int) (fadeAlpha * 80) << 24;
        guiGraphics.fill(0, 0, width, height, backgroundAlpha);

        // 固定大小和位置
        int dialogWidth = BOX_WIDTH;
        int dialogHeight = BOX_HEIGHT;
        int dialogX = (width - dialogWidth) / 2;
        int dialogY = BOX_Y;

        // 滑入动画
        float slideProgress = fadeAlpha;
        int slideOffsetY = Math.round(30 * (1.0f - slideProgress));
        int drawY = dialogY + slideOffsetY;

        // 绘制对话框背景
        if (fadeAlpha > 0.01f) {
            drawNineSlicedTexture(guiGraphics, DIALOGUE_BOX,
                    dialogX, drawY, dialogWidth, dialogHeight,
                    BOX_BORDER, BOX_BORDER, BOX_BORDER, BOX_BORDER,
                    256, 256, fadeAlpha);
        }

        // ==================== 修复：渲染节点图片 ====================
        loadNodeImages(); // 懒加载，只加载一次

        if (!currentNode.getImages().isEmpty()) {
            int imageBaseX = dialogX + 15;
            int imageBaseY = drawY + 15;

            for (int i = 0; i < currentNode.getImages().size(); i++) {
                if (i >= imageResources.size() || i >= currentImageData.size() || i >= imageWidths.size()) break;

                DialogueNode.ImageData imgData = currentImageData.get(i);
                ResourceLocation res = imageResources.get(i);

                int originalW = imageWidths.get(i);
                int originalH = imageHeights.get(i);
                float scale = imgData.getScale();
                int scaledW = Math.round(originalW * scale);
                int scaledH = Math.round(originalH * scale);

                int drawXPos = imageBaseX + imgData.getX();
                int drawYPos = imageBaseY + imgData.getY();

                guiGraphics.setColor(1.0f, 1.0f, 1.0f, fadeAlpha);
                // 【修复】blit 方法的最后两个参数应该是 scaledW, scaledH 而不是 originalW, originalH
                guiGraphics.blit(res, drawXPos, drawYPos, 0, 0, scaledW, scaledH, scaledW, scaledH);
                guiGraphics.setColor(1.0f, 1.0f, 1.0f, 1.0f);
            }
        }
        // ============================================================

        if (currentNode != null) {
            // 说话者名字
            int nameY = drawY - 15;
            int nameAlpha = (int) (fadeAlpha * 255) << 24;
            guiGraphics.drawCenteredString(font, Component.literal(currentNode.getSpeakerName()),
                    dialogX + dialogWidth / 2, nameY, 0xFFFFFF | nameAlpha);

            // 对话文本
            String fullText = currentNode.getNpcText();
            String displayedText = fullText.substring(0, Math.min(displayedCharCount, fullText.length()));
            int revealEnd = (int) (displayedText.length() * textReveal);
            if (skipRequested) revealEnd = displayedText.length();

            if (revealEnd > 0) {
                String revealedText = displayedText.substring(0, Math.min(revealEnd, displayedText.length()));
                List<FormattedCharSequence> lines = font.split(Component.literal(revealedText), dialogWidth - 40);
                for (int i = 0; i < lines.size(); i++) {
                    int lineY = drawY + 15 + i * (font.lineHeight + 2);
                    int textAlpha = (int) (fadeAlpha * 255) << 24;
                    guiGraphics.drawString(font, lines.get(i), dialogX + 20, lineY, 0xFFFFFF | textAlpha, false);
                }

                // 打字光标
                if (animationState == AnimationState.TEXT_TYPING && !fullyDisplayed) {
                    int cursorX = dialogX + 20 + font.width(revealedText);
                    int cursorY = drawY + 15 + font.lineHeight;
                    int cursorAlpha = (int) ((Math.sin(System.currentTimeMillis() / 200.0) * 0.5 + 0.5) * fadeAlpha * 255);
                    guiGraphics.fill(cursorX, cursorY - 1, cursorX + 1, cursorY, 0xFFFFFF | (cursorAlpha << 24));
                }
            }
        }

        // 手动绘制所有按钮
        for (DialogueButton btn : dialogueButtons) {
            boolean hovered = mouseX >= btn.x && mouseX <= btn.x + btn.width &&
                    mouseY >= btn.y && mouseY <= btn.y + btn.height;

            drawNineSlicedTexture(guiGraphics, DIALOGUE_BUTTON,
                    btn.x, btn.y, btn.width, btn.height,
                    BUTTON_BORDER_LEFT, BUTTON_BORDER_TOP, BUTTON_BORDER_RIGHT, BUTTON_BORDER_BOTTOM,
                    BUTTON_TEXTURE_WIDTH, BUTTON_TEXTURE_HEIGHT, fadeAlpha);

            int textAlpha = (int) (fadeAlpha * 255) << 24;
            guiGraphics.drawCenteredString(font, Component.literal(btn.text),
                    btn.x + btn.width / 2,
                    btn.y + (btn.height - 8) / 2,
                    (hovered ? 0xFFFFA0 : 0xFFFFFF) | textAlpha);
        }

        // 跳过提示
        if (animationState == AnimationState.TEXT_TYPING && !fullyDisplayed) {
            String skipText = "点击跳过";
            int skipAlpha = (int) ((Math.sin(System.currentTimeMillis() / 500.0) * 0.3 + 0.7) * fadeAlpha * 255);
            guiGraphics.drawString(font, Component.literal(skipText),
                    width - font.width(skipText) - 10, height - 30,
                    0xAAAAAA | (skipAlpha << 24));
        }
    }

    private void drawNineSlicedTexture(GuiGraphics guiGraphics, ResourceLocation texture,
                                       int x, int y, int width, int height,
                                       int borderLeft, int borderTop, int borderRight, int borderBottom,
                                       int textureWidth, int textureHeight, float alpha) {
        guiGraphics.setColor(1.0F, 1.0F, 1.0F, alpha);

        guiGraphics.blit(texture, x, y, 0, 0, borderLeft, borderTop, textureWidth, textureHeight);
        guiGraphics.blit(texture, x + borderLeft, y, width - borderLeft - borderRight, borderTop,
                borderLeft, 0, textureWidth - borderLeft - borderRight, borderTop, textureWidth, textureHeight);
        guiGraphics.blit(texture, x + width - borderRight, y, textureWidth - borderRight, 0,
                borderRight, borderTop, textureWidth, textureHeight);

        guiGraphics.blit(texture, x, y + borderTop, borderLeft, height - borderTop - borderBottom,
                0, borderTop, borderLeft, textureHeight - borderTop - borderBottom, textureWidth, textureHeight);
        guiGraphics.blit(texture, x + borderLeft, y + borderTop,
                width - borderLeft - borderRight, height - borderTop - borderBottom,
                borderLeft, borderTop,
                textureWidth - borderLeft - borderRight, textureHeight - borderTop - borderBottom,
                textureWidth, textureHeight);
        guiGraphics.blit(texture, x + width - borderRight, y + borderTop,
                borderRight, height - borderTop - borderBottom,
                textureWidth - borderRight, borderTop,
                borderRight, textureHeight - borderTop - borderBottom, textureWidth, textureHeight);

        guiGraphics.blit(texture, x, y + height - borderBottom,
                0, textureHeight - borderBottom,
                borderLeft, borderBottom, textureWidth, textureHeight);
        guiGraphics.blit(texture, x + borderLeft, y + height - borderBottom,
                width - borderLeft - borderRight, borderBottom,
                borderLeft, textureHeight - borderBottom,
                textureWidth - borderLeft - borderRight, borderBottom,
                textureWidth, textureHeight);
        guiGraphics.blit(texture, x + width - borderRight, y + height - borderBottom,
                textureWidth - borderRight, textureHeight - borderBottom,
                borderRight, borderBottom, textureWidth, textureHeight);

        guiGraphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return false;

        for (DialogueButton btn : dialogueButtons) {
            if (mouseX >= btn.x && mouseX <= btn.x + btn.width &&
                    mouseY >= btn.y && mouseY <= btn.y + btn.height) {
                selectOption(btn.optionIndex);
                return true;
            }
        }

        int dialogWidth = BOX_WIDTH;
        int dialogX = (width - dialogWidth) / 2;
        int dialogY = BOX_Y;

        boolean inDialogArea = mouseX >= dialogX && mouseX <= dialogX + dialogWidth &&
                mouseY >= dialogY && mouseY <= dialogY + BOX_HEIGHT;

        if (animationState == AnimationState.TEXT_TYPING && !fullyDisplayed && inDialogArea) {
            skipRequested = true;
            return true;
        }

        if (fullyDisplayed && (currentNode == null || currentNode.getOptions().isEmpty()) && inDialogArea) {
            startCloseAnimation();
            return true;
        }

        return false;
    }

    private void startCloseAnimation() {
        animationState = AnimationState.FADE_OUT;
    }

    private void selectOption(int optionIndex) {
        if (animationState != AnimationState.IDLE) return;

        ModPacketHandler.sendToServer(new SelectOptionC2SPacket(currentNode.getNodeId(), optionIndex, entityId, isBroadcast));

        String nextId = currentNode.getOptions().get(optionIndex).getNextNodeId();
        if ("END".equalsIgnoreCase(nextId)) {
            startCloseAnimation();
        }
    }

    public void updateNode(DialogueNode newNode) {
        this.currentNode = newNode;
        clearImages(); // 切换节点时清理旧图片
        this.textDisplayTimer = 0;
        this.displayedCharCount = 0;
        this.fullyDisplayed = false;
        this.skipRequested = false;
        this.textReveal = 0.0f;

        dialogueButtons.clear();

        animationState = AnimationState.TEXT_TYPING;
        fadeAlpha = 1.0f;
    }

    public void updateNode(DialogueNode newNode, boolean stillBroadcast) {
        this.currentNode = newNode;
        this.isBroadcast = stillBroadcast;
        clearImages(); // 清理旧图片，准备加载新节点的

        this.textDisplayTimer = 0;
        this.displayedCharCount = 0;
        this.fullyDisplayed = false;
        this.skipRequested = false;
        this.textReveal = 0.0f;

        dialogueButtons.clear();

        animationState = AnimationState.TEXT_TYPING;
        fadeAlpha = 1.0f;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        clearImages(); // 关闭界面时释放纹理
        ModPacketHandler.sendToServer(new CloseDialogueC2SPacket(entityId));
        super.onClose();
    }

    @Override
    public void resize(Minecraft minecraft, int width, int height) {
        super.resize(minecraft, width, height);
        recreateButtons();
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) {
            startCloseAnimation();
            return true;
        }
        if ((keyCode == 32 || keyCode == 257) && animationState == AnimationState.TEXT_TYPING && !fullyDisplayed) {
            skipRequested = true;
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}