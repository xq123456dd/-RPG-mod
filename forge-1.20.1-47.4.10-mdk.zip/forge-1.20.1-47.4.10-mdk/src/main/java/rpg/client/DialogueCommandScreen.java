package rpg.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import rpg.data.DialogueCommand;
import rpg.data.DialogueOption;

import java.util.ArrayList;
import java.util.List;

public class DialogueCommandScreen extends Screen {

    private final Screen parent;
    private final DialogueOption editingOption;

    private static final int BUTTON_WIDTH = 350;
    private static final int BUTTON_HEIGHT = 20;
    private static final int PADDING = 5;

    public DialogueCommandScreen(Screen parent, DialogueOption option) {
        super(Component.literal("编辑选项命令: " +
                (option != null && option.getOptionText() != null
                        ? option.getOptionText().trim()
                        : "未知选项")));
        this.parent = parent;
        this.editingOption = option;
    }

    @Override
    protected void init() {
        super.init();
        this.clearWidgets();

        // 关键防护：确保 commands 列表非 null
        List<DialogueCommand> commands = editingOption.getCommands();
        if (commands == null) {
            commands = new ArrayList<>();
            editingOption.getCommands().clear(); // 清空旧的（如果有）
            editingOption.getCommands().addAll(commands); // 重新赋值安全列表
        }

        int centerX = this.width / 2;
        int currentY = 60; // 留出标题空间

        // 渲染命令列表
        for (int i = 0; i < commands.size(); i++) {
            DialogueCommand cmd = commands.get(i);
            if (cmd == null) continue; // 额外防护

            String type = cmd.getCommandType() != null ? cmd.getCommandType().trim() : "NONE";
            String arg = cmd.getCommandArgument() != null ? cmd.getCommandArgument().trim() : "";
            String displayText = type + (arg.isEmpty() ? "" : " " + arg);
            if (displayText.isEmpty()) displayText = "<空命令>";

            int btnY = currentY + i * (BUTTON_HEIGHT + PADDING);

            this.addRenderableWidget(Button.builder(
                    Component.literal("编辑: " + displayText),
                    btn -> editCommand(cmd)
            ).bounds(centerX - BUTTON_WIDTH / 2, btnY, BUTTON_WIDTH - 50, BUTTON_HEIGHT).build());

            final int index = i;
            this.addRenderableWidget(Button.builder(
                    Component.literal("删除"),
                    btn -> deleteCommand(index)
            ).bounds(centerX + BUTTON_WIDTH / 2 - 45, btnY, 40, BUTTON_HEIGHT).build());
        }

        // 添加新命令按钮
        int addBtnY = currentY + commands.size() * (BUTTON_HEIGHT + PADDING) + 20;
        this.addRenderableWidget(Button.builder(
                Component.literal("➕ 添加新命令"),
                btn -> addNewCommand()
        ).bounds(centerX - 100, addBtnY, 200, BUTTON_HEIGHT).build());

        // 返回按钮
        int backBtnY = this.height - 50;
        this.addRenderableWidget(Button.builder(
                Component.literal("返回"),
                btn -> this.onClose()
        ).bounds(centerX - 75, backBtnY, 150, BUTTON_HEIGHT).build());
    }

    private void addNewCommand() {
        DialogueCommand newCommand = new DialogueCommand("NONE", "");
        // 确保所有字段非 null
        if (newCommand.getCommandType() == null) newCommand.setCommandType("NONE");
        if (newCommand.getCommandArgument() == null) newCommand.setCommandArgument("");

        List<DialogueCommand> commands = editingOption.getCommands();
        if (commands == null) {
            commands = new ArrayList<>();
            // 假设 DialogueOption 有 setCommands 方法，如果没有，需要在 DialogueOption.java 添加
            // editingOption.setCommands(commands);
        }
        commands.add(newCommand);
        this.init();
    }

    private void editCommand(DialogueCommand command) {
        if (this.minecraft != null && command != null) {
            this.minecraft.setScreen(new DialogueCommandEditScreen(this, command));
        }
    }

    private void deleteCommand(int index) {
        List<DialogueCommand> commands = editingOption.getCommands();
        if (commands != null && index >= 0 && index < commands.size()) {
            commands.remove(index);
        }
        this.init();
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
        this.renderBackground(guiGraphics);
        guiGraphics.drawCenteredString(this.font, this.title, this.width / 2, 20, 0xFFFFFF);

        int commandCount = editingOption.getCommands() != null ? editingOption.getCommands().size() : 0;
        guiGraphics.drawCenteredString(this.font,
                Component.literal("当前命令数量: " + commandCount),
                this.width / 2, 40, 0xAAAAAA);

        super.render(guiGraphics, mouseX, mouseY, partialTicks);
    }

    @Override
    public void onClose() {
        if (this.minecraft != null) {
            this.minecraft.setScreen(this.parent);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}