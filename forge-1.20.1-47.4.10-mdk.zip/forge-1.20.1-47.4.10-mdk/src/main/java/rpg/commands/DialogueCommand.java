package rpg.commands;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;
import rpg.data.BroadcastDialogueManager;
import rpg.network.ModPacketHandler;
import rpg.network.OpenDialogueS2CPacket;

public class DialogueCommand {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("dialogue")
                .requires(source -> source.hasPermission(2)) // 需要OP权限
                .then(Commands.literal("start")
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("entityId", StringArgumentType.string()) // 改为 entityId
                                        .then(Commands.argument("nodeId", StringArgumentType.string())
                                                .executes(context -> executeStart(
                                                        context.getSource(),
                                                        EntityArgument.getPlayer(context, "player"),
                                                        StringArgumentType.getString(context, "entityId"),
                                                        StringArgumentType.getString(context, "nodeId")
                                                ))))))
                .then(Commands.literal("npc")
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("entityId", StringArgumentType.string()) // 改为 entityId
                                        .then(Commands.argument("startNode", StringArgumentType.string())
                                                .executes(context -> executeNpcDialogue(
                                                        context.getSource(),
                                                        EntityArgument.getPlayer(context, "player"),
                                                        StringArgumentType.getString(context, "entityId"),
                                                        StringArgumentType.getString(context, "startNode")
                                                ))))))
                .then(Commands.literal("test")
                        .then(Commands.argument("nodeId", StringArgumentType.string())
                                .executes(context -> executeTest(
                                        context.getSource(),
                                        context.getSource().getPlayerOrException(),
                                        StringArgumentType.getString(context, "nodeId")
                                ))))
                // 新增：全局广播命令
                .then(Commands.literal("broadcast")
                        .then(Commands.argument("entityId", StringArgumentType.string())
                                .then(Commands.argument("nodeId", StringArgumentType.string())
                                        .executes(context -> executeBroadcastStart(
                                                context.getSource(),
                                                StringArgumentType.getString(context, "entityId"),
                                                StringArgumentType.getString(context, "nodeId")
                                        )))))
                .then(Commands.literal("broadcast")
                        .then(Commands.literal("stop")
                                .executes(context -> executeBroadcastStop(context.getSource()))))
        );
    }

    private static int executeStart(CommandSourceStack source, ServerPlayer player,
                                    String entityIdStr, String nodeId) {
        try {
            int entityId = Integer.parseInt(entityIdStr);
            
            // 先同步节点数据给客户端
            syncNodeDataToPlayer(player, entityId);
            
            // 然后发送对话包
            ModPacketHandler.sendToPlayer(new OpenDialogueS2CPacket(nodeId, entityId), player);
            source.sendSuccess(() -> Component.literal("已向玩家 " + player.getName().getString() +
                    " 发送对话 [节点: " + nodeId + ", 实体ID: " + entityId + "]"), true);
            return 1;
        } catch (NumberFormatException e) {
            source.sendFailure(Component.literal("实体ID必须是数字"));
            return 0;
        }
    }

    private static int executeNpcDialogue(CommandSourceStack source, ServerPlayer player,
                                          String entityIdStr, String startNode) {
        try {
            int entityId = Integer.parseInt(entityIdStr);
            
            // 先同步节点数据给客户端
            syncNodeDataToPlayer(player, entityId);
            
            // 然后发送对话包
            ModPacketHandler.sendToPlayer(new OpenDialogueS2CPacket(startNode, entityId), player);
            source.sendSuccess(() -> Component.literal("已向玩家 " + player.getName().getString() +
                    " 打开NPC对话 [实体ID: " + entityId + ", 起始节点: " + startNode + "]"), true);
            return 1;
        } catch (NumberFormatException e) {
            source.sendFailure(Component.literal("实体ID必须是数字"));
            return 0;
        }
    }

    private static int executeTest(CommandSourceStack source, ServerPlayer player,
                                   String nodeId) {
        // test 命令不依赖实体，直接传 -1 表示无实体
        ModPacketHandler.sendToPlayer(new OpenDialogueS2CPacket(nodeId, -1), player);
        source.sendSuccess(() -> Component.literal("已为你打开测试对话 [" + nodeId + "]"), true);
        return 1;
    }

    private static int executeBroadcastStart(CommandSourceStack source, String entityIdStr, String nodeId) {
        try {
            int entityId = Integer.parseInt(entityIdStr);
            BroadcastDialogueManager.getInstance().startBroadcast(entityId, nodeId);
            source.sendSuccess(() -> Component.literal("成功启动全局广播对话：实体ID=" + entityId + "，起始节点=" + nodeId), true);
            return 1;
        } catch (NumberFormatException e) {
            source.sendFailure(Component.literal("实体ID必须是数字"));
            return 0;
        }
    }

    private static int executeBroadcastStop(CommandSourceStack source) {
        BroadcastDialogueManager.getInstance().stopBroadcast();
        source.sendSuccess(() -> Component.literal("已停止全局广播对话"), true);
        return 1;
    }

    /**
     * 同步节点数据给玩家
     * @param player 目标玩家
     * @param entityId 实体ID
     */
    private static void syncNodeDataToPlayer(ServerPlayer player, int entityId) {
        try {
            // 获取实体
            net.minecraft.world.entity.Entity entity = player.serverLevel().getEntity(entityId);
            if (entity != null) {
                // 从实体加载对话节点
                java.util.Map<String, rpg.data.DialogueNode> nodes = rpg.data.NpcDialogueLoader.loadNodesFromEntity(entity);
                if (!nodes.isEmpty()) {
                    // 创建同步包
                    rpg.network.SyncDialogueDataPacket syncPacket = new rpg.network.SyncDialogueDataPacket(nodes, entityId);
                    // 发送给客户端
                    ModPacketHandler.sendToPlayer(syncPacket, player);
                    System.out.println("[DialogueCommand] 已同步 " + nodes.size() + " 个对话节点给玩家: " + player.getName().getString());
                }
            }
        } catch (Exception e) {
            System.err.println("[DialogueCommand] 同步节点数据失败: " + e.getMessage());
            e.printStackTrace();
        }
    }
}