package rpg.commands;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType; // 添加这行
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import rpg.network.ModPacketHandler;
import rpg.network.OpenDialogueS2CPacket;

public class DebugDialogueCommand {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("debugdialogue")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("testbroadcast")
                        .then(Commands.argument("nodeId", StringArgumentType.string())
                                .executes(context -> {
                                    ServerPlayer player = context.getSource().getPlayer();
                                    String nodeId = StringArgumentType.getString(context, "nodeId");

                                    if (player != null) {
                                        // 使用 BroadcastDialogueManager 来启动广播对话
                                        boolean success = rpg.data.BroadcastDialogueManager.getInstance()
                                                .startBroadcast(-1, nodeId);

                                        if (success) {
                                            context.getSource().sendSuccess(() ->
                                                            Component.literal("§a已成功启动广播对话，节点ID: " + nodeId),
                                                    true
                                            );
                                        } else {
                                            context.getSource().sendFailure(Component.literal("§c启动广播对话失败，请检查日志"));
                                        }
                                    }
                                    return 1;
                                })
                        )
                )
                .then(Commands.literal("testnetwork")
                        .executes(context -> {
                            ServerPlayer player = context.getSource().getPlayer();
                            if (player != null) {
                                // 测试网络连接是否正常
                                for (ServerPlayer otherPlayer : player.getServer().getPlayerList().getPlayers()) {
                                    boolean isSelf = otherPlayer == player;
                                    OpenDialogueS2CPacket packet = new OpenDialogueS2CPacket(
                                            "test_node",
                                            isSelf ? 0 : 1,
                                            false
                                    );

                                    ModPacketHandler.sendToPlayer(packet, otherPlayer);
                                    context.getSource().sendSuccess(() ->
                                                    Component.literal("§a已向玩家 " + otherPlayer.getName().getString() + " 发送测试包"),
                                            false
                                    );
                                }
                            }
                            return 1;
                        })
                )
                .then(Commands.literal("status")
                        .executes(context -> {
                            ServerPlayer player = context.getSource().getPlayer();
                            if (player != null) {
                                context.getSource().sendSuccess(() ->
                                                Component.literal("§e网络调试命令可用。使用 /debugdialogue testbroadcast <节点ID> 测试广播"),
                                        false
                                );
                            }
                            return 1;
                        })
                )
        );
    }
}