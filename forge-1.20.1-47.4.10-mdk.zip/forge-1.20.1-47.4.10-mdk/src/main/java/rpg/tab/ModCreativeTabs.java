package rpg.tab;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;
import rpg.RpgDialogueMod;
import rpg.item.ModItems;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, RpgDialogueMod.MOD_ID);

    // 注册新的标签页
    public static final RegistryObject<CreativeModeTab> RPG_TAB = CREATIVE_MODE_TABS.register("rpg_tab",
            () -> CreativeModeTab.builder()
                    // 設置標籤頁的圖示為 NPC 編輯魔杖
                    .icon(() -> ModItems.DIALOGUE_TOOL.get().getDefaultInstance())
                    // 標籤頁標題（在 lang 文件中定義）
                    .title(Component.translatable("itemGroup." + RpgDialogueMod.MOD_ID))
                    // 定義此標籤頁中包含的物品
                    .displayItems((parameters, output) -> {
                        // 将您的工具添加到此标签页
                        output.accept(ModItems.DIALOGUE_TOOL.get());

                        // 可以在这里添加其他物品...
                    }).build());

    public static void register(IEventBus eventBus) {
        CREATIVE_MODE_TABS.register(eventBus);
    }
}