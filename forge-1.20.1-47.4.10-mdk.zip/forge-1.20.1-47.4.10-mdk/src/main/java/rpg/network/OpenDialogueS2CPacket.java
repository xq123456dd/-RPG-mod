package rpg.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.network.NetworkEvent;
import rpg.client.EnhancedDialogueScreen;
import rpg.data.DialogueLoader;
import rpg.data.DialogueNode;
import rpg.data.DialogueOption; // 导入 DialogueOption
import rpg.data.NpcDialogueLoader;

import java.util.function.Supplier;
import java.util.ArrayList; // 导入 ArrayList
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class OpenDialogueS2CPacket {
    private static final Logger LOGGER = LogManager.getLogger();

    private final String nodeId;
    private final int entityId;
    private final boolean isBroadcast;

    public OpenDialogueS2CPacket(String nodeId, int entityId, boolean isBroadcast) {
        this.nodeId = nodeId;
        this.entityId = entityId;
        this.isBroadcast = isBroadcast;
    }

    public OpenDialogueS2CPacket(String nodeId, int entityId) {
        this(nodeId, entityId, false);
    }

    public static void encode(OpenDialogueS2CPacket msg, FriendlyByteBuf buf) {
        buf.writeUtf(msg.nodeId);
        buf.writeInt(msg.entityId);
        buf.writeBoolean(msg.isBroadcast);
    }

    public static OpenDialogueS2CPacket decode(FriendlyByteBuf buf) {
        String nodeId = buf.readUtf();
        int entityId = buf.readInt();
        boolean isBroadcast = buf.readBoolean();
        return new OpenDialogueS2CPacket(nodeId, entityId, isBroadcast);
    }

    // 创建测试节点的辅助方法
    private static DialogueNode createTestNode(String nodeId) {
        // 创建选项列表 - 添加一个结束选项
        ArrayList<DialogueOption> options = new ArrayList<>();
        options.add(new DialogueOption("结束对话", "END"));

        // 创建测试节点
        DialogueNode node = new DialogueNode(
                nodeId,
                "系统广播",
                "这是一个广播测试对话！节点ID: " + nodeId,
                options
        );

        LOGGER.info("[测试] 创建测试节点: {}", nodeId);
        return node;
    }

    public static void handle(OpenDialogueS2CPacket msg, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> {
            System.out.println("[客户端] 收到对话包: 节点ID=" + msg.nodeId +
                    ", 实体ID=" + msg.entityId + ", 是否广播=" + msg.isBroadcast);

            if ("END".equalsIgnoreCase(msg.nodeId)) {
                System.out.println("[客户端] 收到END节点，关闭对话");
                Minecraft mc = Minecraft.getInstance();
                if (mc.screen instanceof EnhancedDialogueScreen) {
                    mc.setScreen(null);
                }
                return;
            }

            DialogueNode node = null;

            // 【关键修复】广播对话的处理逻辑
            if (msg.isBroadcast) {
                System.out.println("[客户端] 广播对话，尝试加载节点: " + msg.nodeId);

                // 方法1：从DialogueLoader的临时节点中获取
                node = DialogueLoader.getNode(msg.nodeId);

                if (node == null) {
                    System.out.println("[客户端] 无法从临时节点中找到广播节点，尝试从实体加载");

                    // 方法2：尝试从实体加载（如果实体存在）
                    if (msg.entityId != -1) {
                        Entity entity = Minecraft.getInstance().level.getEntity(msg.entityId);
                        if (entity != null) {
                            System.out.println("[客户端] 从实体加载对话节点，实体ID=" + msg.entityId);
                            node = NpcDialogueLoader.loadNodesFromEntity(entity).get(msg.nodeId);
                        }
                    }
                }

                // 方法3：如果还是找不到，创建一个默认节点
                if (node == null) {
                    System.out.println("[客户端] 广播对话无法找到节点: " + msg.nodeId + "，创建默认节点");

                    // 创建默认广播节点
                    ArrayList<DialogueOption> options = new ArrayList<>();
                    options.add(new DialogueOption("结束广播", "END", "NONE"));

                    node = new DialogueNode(
                            msg.nodeId,
                            "广播系统",
                            "这是一条广播消息。节点ID: " + msg.nodeId,
                            options
                    );

                    // 将这个默认节点添加到临时存储中，以便后续使用
                    DialogueLoader.addTemporaryNode(node);
                }
            } else {
                // 非广播对话的逻辑保持不变
                if (msg.entityId != -1) {
                    Entity entity = Minecraft.getInstance().level.getEntity(msg.entityId);
                    if (entity != null) {
                        System.out.println("[客户端] 从实体加载对话节点，实体ID=" + msg.entityId);
                        node = NpcDialogueLoader.loadNodesFromEntity(entity).get(msg.nodeId);
                    } else {
                        System.out.println("[客户端] 实体不存在，实体ID=" + msg.entityId + "，尝试从DialogueLoader加载");
                    }
                }

                // 如果从实体加载失败，尝试从DialogueLoader加载
                if (node == null) {
                    node = DialogueLoader.getNode(msg.nodeId);
                }
            }

            if (node == null) {
                System.out.println("[客户端] 无法加载对话节点: " + msg.nodeId);

                // 即使找不到节点，也创建一个错误提示节点
                ArrayList<DialogueOption> options = new ArrayList<>();
                options.add(new DialogueOption("确定", "END", "NONE"));
                node = new DialogueNode(
                        msg.nodeId,
                        "错误",
                        "无法加载对话节点: " + msg.nodeId,
                        options
                );
            }

            System.out.println("[客户端] 成功加载节点: " + node.getNodeId() + "，说话者: " + node.getSpeakerName());

            Minecraft mc = Minecraft.getInstance();

            // 调试当前屏幕信息
            if (mc.screen != null) {
                System.out.println("[客户端] 当前屏幕: " + mc.screen.getClass().getName());
            } else {
                System.out.println("[客户端] 当前屏幕: null");
            }

            // 检查是否已经有相同的对话屏幕，如果有则更新，否则创建新的
            if (mc.screen instanceof EnhancedDialogueScreen currentScreen &&
                    currentScreen.getEntityId() == msg.entityId) {
                System.out.println("[客户端] 更新现有对话屏幕");
                currentScreen.updateNode(node, msg.isBroadcast);
            } else {
                System.out.println("[客户端] 创建新的对话屏幕");
                mc.setScreen(new EnhancedDialogueScreen(node, msg.entityId, msg.isBroadcast));
            }
        });
        context.setPacketHandled(true);
    }
    // Getters
    public String getNodeId() { return nodeId; }
    public int getEntityId() { return entityId; }
    public boolean isBroadcast() { return isBroadcast; }
}