package rpg.network;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;
import rpg.RpgDialogueMod;

import java.util.Optional;

public class ModPacketHandler {
    private static final String PROTOCOL_VERSION = "1.0";
    public static SimpleChannel INSTANCE = null;
    private static int packetId = 0;

    private static int id() {
        return packetId++;
    }

    public static void register() {
        INSTANCE = NetworkRegistry.newSimpleChannel(
                ResourceLocation.fromNamespaceAndPath(RpgDialogueMod.MOD_ID, "main"),
                () -> PROTOCOL_VERSION,
                PROTOCOL_VERSION::equals,
                PROTOCOL_VERSION::equals
        );

        System.out.println("RPG对话Mod网络包已注册");

        // 注册所有包
        INSTANCE.registerMessage(id(),
                UpdateDialogueDataC2SPacket.class,
                UpdateDialogueDataC2SPacket::encode,
                UpdateDialogueDataC2SPacket::new,
                UpdateDialogueDataC2SPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));

        // S2C: OpenDialogueS2CPacket
        INSTANCE.registerMessage(id(),
                OpenDialogueS2CPacket.class,
                OpenDialogueS2CPacket::encode,
                OpenDialogueS2CPacket::decode,
                OpenDialogueS2CPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));

        // C2S: SelectOptionC2SPacket
        INSTANCE.registerMessage(id(),
                SelectOptionC2SPacket.class,
                SelectOptionC2SPacket::encode,
                SelectOptionC2SPacket::decode,
                SelectOptionC2SPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));

        // S2C: OpenNpcEditorPacket
        INSTANCE.registerMessage(id(),
                OpenNpcEditorPacket.class,
                OpenNpcEditorPacket::toBytes,
                OpenNpcEditorPacket::new,
                OpenNpcEditorPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));


        // C2S: CloseDialogueC2SPacket
        INSTANCE.registerMessage(id(),
                CloseDialogueC2SPacket.class,
                CloseDialogueC2SPacket::encode,
                CloseDialogueC2SPacket::decode,
                CloseDialogueC2SPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
        INSTANCE.registerMessage(id(),
                SyncDialogueDataPacket.class,
                SyncDialogueDataPacket::encode,
                SyncDialogueDataPacket::decode,
                SyncDialogueDataPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));

        // C2S: ExportDialogueC2SPacket
        INSTANCE.registerMessage(id(),
                ExportDialogueC2SPacket.class,
                ExportDialogueC2SPacket::encode,
                ExportDialogueC2SPacket::new,
                ExportDialogueC2SPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
    }

    /**
     * 发送消息给特定玩家 (服务器 -> 客户端)
     */
    public static <MSG> void sendToPlayer(MSG message, ServerPlayer player) {
        if (INSTANCE != null) {
            INSTANCE.send(PacketDistributor.PLAYER.with(() -> player), message);
        } else {
            System.err.println("Warning: ModPacketHandler INSTANCE is null, cannot send packet to player.");
        }
    }

    /**
     * 发送消息给服务器 (客户端 -> 服务器)
     */
    public static <MSG> void sendToServer(MSG message) {
        if (INSTANCE != null) {
            INSTANCE.sendToServer(message);
        } else {
            System.err.println("Warning: ModPacketHandler INSTANCE is null, cannot send packet to server.");
        }
    }
}