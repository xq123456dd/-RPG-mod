package rpg.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.network.NetworkEvent;
import rpg.events.NpcBehaviorHandler;

import java.util.function.Supplier;

public class CloseDialogueC2SPacket {
    private final int entityId;

    public CloseDialogueC2SPacket(int entityId) {
        this.entityId = entityId;
    }

    public static void encode(CloseDialogueC2SPacket msg, FriendlyByteBuf buf) {
        buf.writeInt(msg.entityId);
    }

    public static CloseDialogueC2SPacket decode(FriendlyByteBuf buf) {
        return new CloseDialogueC2SPacket(buf.readInt());
    }

    public static void handle(CloseDialogueC2SPacket msg, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player == null) return;

            // 清除NPC的对话激活标记
            Entity targetEntity = player.level().getEntity(msg.entityId);
            if (targetEntity != null) {
                // 使用新的NPC行为管理器
                NpcBehaviorHandler.onDialogueEnded(targetEntity);
                System.out.println("服务器：清除对话激活标记，实体: " + targetEntity.getName().getString() + " (ID: " + msg.entityId + ")");
            } else {
                System.out.println("服务器：无法清除对话标记，找不到实体ID: " + msg.entityId);
            }
        });
        context.setPacketHandled(true);
    }
}