
package rpg.network;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import rpg.data.DialogueNode;
import rpg.data.JsonDialogueLoader;
import rpg.util.NbtOptimizer;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

/**
 * 客户端发送到服务器的包，用于导出对话到JSON文件
 */
public class ExportDialogueC2SPacket {
    private final Map<String, DialogueNode> dialogueMap;
    private final String fileName;

    public ExportDialogueC2SPacket(Map<String, DialogueNode> dialogueMap, String fileName) {
        this.dialogueMap = dialogueMap;
        this.fileName = fileName;
    }

    public ExportDialogueC2SPacket(FriendlyByteBuf buffer) {
        // 从NBT反序列化对话数据
        CompoundTag mapTag = buffer.readNbt();
        this.dialogueMap = NbtOptimizer.deserializeDialogueMap(mapTag);
        this.fileName = buffer.readUtf();
    }

    public void encode(FriendlyByteBuf buffer) {
        // 将对话数据序列化为NBT
        CompoundTag mapTag = NbtOptimizer.serializeDialogueMap(dialogueMap);
        buffer.writeNbt(mapTag);
        buffer.writeUtf(fileName);
    }

    public static void handle(ExportDialogueC2SPacket msg, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player != null && player.server != null) {
                // 获取主世界
                var overworld = player.server.getLevel(net.minecraft.world.level.Level.OVERWORLD);
                if (overworld != null) {
                    // 导出对话到JSON文件
                    boolean success = JsonDialogueLoader.saveToJsonFile(msg.dialogueMap, msg.fileName, overworld);
                    if (success) {
                        System.out.println("成功导出对话到JSON文件: " + msg.fileName);
                    } else {
                        System.err.println("导出对话到JSON文件失败: " + msg.fileName);
                    }
                }
            }
        });
        context.setPacketHandled(true);
    }
}
