package rpg.network;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import rpg.data.DialogueNode;
import rpg.data.DialogueLoader;
import rpg.util.NbtOptimizer;

import java.util.Map;
import java.util.function.Supplier;

public class UpdateDialogueDataC2SPacket {
    private final int entityId;
    private final CompoundTag dialogueData;
    private final int nodeCount;
    // 【新增字段】
    private final String startNodeId;

    // 【修改构造函数】添加 String startNodeId 参数
    public UpdateDialogueDataC2SPacket(int entityId, Map<String, DialogueNode> dialogueMap, String startNodeId) {
        this.entityId = entityId;
        this.nodeCount = dialogueMap.size();

        this.dialogueData = NbtOptimizer.serializeDialogueMap(dialogueMap);
        this.startNodeId = startNodeId; // 【新增】赋值

        System.out.println("创建更新包: 实体ID=" + entityId + ", 节点数=" + nodeCount + ", 起始节点=" + startNodeId);
    }

    // 【修改解码构造函数】读取 startNodeId
    public UpdateDialogueDataC2SPacket(FriendlyByteBuf buf) {
        this.entityId = buf.readInt();
        this.nodeCount = buf.readInt();

        if (buf.readBoolean()) {
            this.dialogueData = buf.readNbt();
        } else {
            this.dialogueData = new CompoundTag();
        }

        // 【新增】读取起始节点ID
        this.startNodeId = buf.readUtf();
    }

    /**
     * 【修复】使用 encode 方法名
     */
    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(this.entityId);
        buf.writeInt(this.nodeCount);

        boolean hasData = !this.dialogueData.isEmpty();
        buf.writeBoolean(hasData);
        if (hasData) {
            buf.writeNbt(this.dialogueData);
        }

        // 【新增】写入起始节点ID
        buf.writeUtf(this.startNodeId);
    }

    public void handle(Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> {
            if (context.getSender() == null) return;
            ServerPlayer sender = context.getSender();

            net.minecraft.world.entity.Entity entity = sender.level().getEntity(this.entityId);

            if (entity != null) {

                // 1. 更新内存中的全局地图
                Map<String, DialogueNode> updatedMap = NbtOptimizer.deserializeDialogueMap(this.dialogueData);
                DialogueLoader.DIALOGUE_MAP.putAll(updatedMap);

                System.out.println("=== 服务器：更新NPC对话数据到内存。当前节点总数: " + DialogueLoader.DIALOGUE_MAP.size() + " ===");

                // 2. 立即强制保存到磁盘
                net.minecraft.server.level.ServerLevel overworld = sender.getServer().getLevel(net.minecraft.world.level.Level.OVERWORLD);
                if (overworld != null) {
                    DialogueLoader.saveDialogues(overworld);
                }

                // 3. 将 NBT 数据写到实体的persistentData标签中 (作为备份或旧结构兼容)
                CompoundTag nbt = entity.getPersistentData();
                final String dialogueDataKey = "rpg_dialogue_data";
                CompoundTag dialogueRoot = nbt.getCompound(dialogueDataKey);
                dialogueRoot.put("DialogueNodes", this.dialogueData);
                nbt.put(dialogueDataKey, dialogueRoot);

                // 4. 更新起始 ID 逻辑：直接保存客户端提供的值
                final String startNodeIdKey = "rpg_dialogue_start_id";

                String newStartNodeId = this.startNodeId != null ? this.startNodeId : "";

                // 【关键修复】直接保存客户端提供的起始节点ID
                nbt.putString(startNodeIdKey, newStartNodeId);
                System.out.println("更新NPC起始节点ID为: " + newStartNodeId);

                // 移除或替换了原有的复杂 ID 修复逻辑，因为客户端现在发送了最新的、正确的值。

                System.out.println("成功更新NPC对话数据");

            } else {
                System.err.println("尝试为非RPG实体ID: " + this.entityId + " 更新对话数据");
            }
        });
        context.setPacketHandled(true);
    }
}