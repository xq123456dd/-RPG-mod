package rpg.network;

import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag; // 导入 Tag 类
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraftforge.network.NetworkEvent;
import rpg.client.NpcEditorScreen;
import rpg.client.DialogueManager;
import rpg.data.DialogueNode;
// 假设 DialogueNode 有静态方法 DialogueNode.deserializeNBT(CompoundTag)

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

public class OpenNpcEditorPacket {
    private final int entityId;
    private final String entityName;
    private final CompoundTag dialogueData;

    public OpenNpcEditorPacket(int entityId, String entityName, CompoundTag dialogueData) {
        this.entityId = entityId;
        this.entityName = entityName != null ? entityName : "Unknown NPC";
        // dialogueData 预期是实体的完整持久化 NBT
        this.dialogueData = dialogueData != null ? dialogueData : new CompoundTag();
    }

    public OpenNpcEditorPacket(FriendlyByteBuf buf) {
        this.entityId = buf.readInt();
        this.entityName = buf.readUtf();
        // 增加读取检查，防止空指针
        CompoundTag readTag = buf.readNbt();
        this.dialogueData = readTag != null ? readTag : new CompoundTag();
    }

    public void toBytes(FriendlyByteBuf buf) {
        buf.writeInt(entityId);
        buf.writeUtf(entityName);
        buf.writeNbt(dialogueData);
    }

    public boolean handle(Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            // 确保只在客户端执行
            if (context.getDirection().getReceptionSide().isClient()) {
                handleClientSide();
            }
        });
        context.setPacketHandled(true);
        return true;
    }

    private void handleClientSide() {
        System.out.println("=== 客户端：加载NPC编辑器数据 ===");

        Map<String, DialogueNode> nodeMap = new HashMap<>();

        // 1. 提取对话节点数据
        if (dialogueData.contains("rpg_dialogue_data", Tag.TAG_COMPOUND)) {
            CompoundTag dialogueRoot = dialogueData.getCompound("rpg_dialogue_data");
            if (dialogueRoot.contains("DialogueNodes", Tag.TAG_COMPOUND)) {
                CompoundTag nodesTag = dialogueRoot.getCompound("DialogueNodes");
                for (String key : nodesTag.getAllKeys()) {
                    CompoundTag nodeTag = nodesTag.getCompound(key);
                    // 假设 DialogueNode.deserializeNBT 是可用的
                    DialogueNode node = DialogueNode.deserializeNBT(nodeTag);
                    if (node != null) {
                        nodeMap.put(key, node);
                    }
                }
            }
        }

        // 2. 【新增】提取起始节点 ID
        final String startNodeIdKey = "rpg_dialogue_start_id";
        String startNodeId = ""; // 默认值

        // 假设起始节点ID直接保存在实体的persistentData NBT中
        if (dialogueData.contains(startNodeIdKey, Tag.TAG_STRING)) {
            startNodeId = dialogueData.getString(startNodeIdKey);
        }

        // 3. 【修正调用】：初始化 Manager，现在传递 4 个参数
        DialogueManager.getInstance().startEditing(entityId, entityName, nodeMap, startNodeId);

        // 4. 打开屏幕
        Minecraft mc = Minecraft.getInstance();
        if (mc != null) {
            // 再次确保在主线程执行 GUI 操作
            mc.execute(() -> {
                mc.setScreen(new NpcEditorScreen(
                        Component.literal("NPC 编辑器: " + entityName),
                        entityId,
                        entityName
                ));
            });
        }
    }
}