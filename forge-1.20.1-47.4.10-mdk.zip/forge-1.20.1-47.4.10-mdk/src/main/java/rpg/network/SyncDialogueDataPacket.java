package rpg.network;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;
import rpg.data.DialogueLoader;
import rpg.data.DialogueNode;

import java.util.function.Supplier;
import java.util.Map;

public class SyncDialogueDataPacket {
    public CompoundTag nodesTag;
    private final int npcId;

    public SyncDialogueDataPacket(Map<String, DialogueNode> nodes, int npcId) {
        this.npcId = npcId;
        this.nodesTag = new CompoundTag();

        // 将节点数据序列化为NBT
        ListTag nodesList = new ListTag();
        for (Map.Entry<String, DialogueNode> entry : nodes.entrySet()) {
            CompoundTag nodeTag = entry.getValue().serializeNBT();
            nodesList.add(nodeTag);
        }
        nodesTag.put("Nodes", nodesList);
        nodesTag.putInt("NpcId", npcId);
    }

    public static void encode(SyncDialogueDataPacket msg, FriendlyByteBuf buf) {
        buf.writeNbt(msg.nodesTag);
    }

    public static SyncDialogueDataPacket decode(FriendlyByteBuf buf) {
        CompoundTag nodesTag = buf.readNbt();
        return new SyncDialogueDataPacket(null, 0) {
            {
                this.nodesTag = nodesTag;
            }
        };
    }

    public static void handle(SyncDialogueDataPacket msg, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> {
            int npcId = msg.nodesTag.getInt("NpcId");
            System.out.println("[客户端] 收到节点同步包，NPC ID=" + npcId);

            // 只清空同一NPC的临时节点，避免多个NPC对话数据冲突
            clearTemporaryNodesForNpc(npcId);

            if (msg.nodesTag.contains("Nodes")) {
                ListTag nodesList = msg.nodesTag.getList("Nodes", 10); // 10 = TAG_Compound

                // 反序列化节点
                for (int i = 0; i < nodesList.size(); i++) {
                    CompoundTag nodeTag = nodesList.getCompound(i);
                    DialogueNode node = DialogueNode.deserializeNBT(nodeTag);
                    if (node != null) {
                        DialogueLoader.addTemporaryNode(node);
                    }
                }

                System.out.println("[客户端] 已同步 " + nodesList.size() + " 个广播对话节点");
            }
        });
        context.setPacketHandled(true);
    }

    /**
     * 只清空指定NPC的临时节点
     * @param npcId NPC ID
     */
    private static void clearTemporaryNodesForNpc(int npcId) {
        // 由于临时节点没有存储NPC ID信息，我们暂时清空所有临时节点
        // TODO: 未来可以改进，只清空特定NPC的节点
        DialogueLoader.clearTemporaryNodes();
    }
}