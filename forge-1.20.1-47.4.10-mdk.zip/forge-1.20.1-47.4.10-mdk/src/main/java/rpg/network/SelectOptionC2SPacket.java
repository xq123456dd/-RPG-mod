package rpg.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import rpg.data.*;
import rpg.events.NpcBehaviorHandler;
import rpg.util.VariableCommandExecutor;

import java.util.List;
import java.util.function.Supplier;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class SelectOptionC2SPacket {
    private static final Logger LOGGER = LogManager.getLogger();

    private final String currentNodeId;
    private final int optionIndex;
    private final int entityId;
    private final boolean isBroadcast;

    public SelectOptionC2SPacket(String currentNodeId, int optionIndex, int entityId, boolean isBroadcast) {
        this.currentNodeId = currentNodeId;
        this.optionIndex = optionIndex;
        this.entityId = entityId;
        this.isBroadcast = isBroadcast;
    }

    public SelectOptionC2SPacket(String currentNodeId, int optionIndex, int entityId) {
        this(currentNodeId, optionIndex, entityId, false);
    }

    public static void encode(SelectOptionC2SPacket msg, FriendlyByteBuf buf) {
        buf.writeUtf(msg.currentNodeId);
        buf.writeInt(msg.optionIndex);
        buf.writeInt(msg.entityId);
        buf.writeBoolean(msg.isBroadcast);
    }

    public static SelectOptionC2SPacket decode(FriendlyByteBuf buf) {
        return new SelectOptionC2SPacket(buf.readUtf(), buf.readInt(), buf.readInt(), buf.readBoolean());
    }

    public static void handle(SelectOptionC2SPacket msg, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player == null) return;

            DialogueNode currentNode = null;

            // 加载当前节点（自定义或全局）
            if (msg.entityId != -1) {
                currentNode = NpcDialogueLoader.loadNodesFromEntity(player.level().getEntity(msg.entityId))
                        .get(msg.currentNodeId);
            }
            if (currentNode == null) {
                currentNode = DialogueLoader.getNode(msg.currentNodeId);
            }

            if (currentNode == null) {
                LOGGER.warn("服务器找不到节点: {}", msg.currentNodeId);
                return;
            }

            List<DialogueOption> options = currentNode.getOptions();
            if (msg.optionIndex < 0 || msg.optionIndex >= options.size()) {
                return;
            }

            DialogueOption selected = options.get(msg.optionIndex);

            // 执行命令（变量、给物品等）
            for (DialogueCommand cmd : selected.getCommands()) {
                // 这里保留你原有的命令执行逻辑（给物品、变量等）
                // 示例：VariableCommandExecutor 等
                switch (cmd.getCommandType()) {
                    case "SET_VARIABLE":
                        VariableCommandExecutor.executeSetVariable(cmd, PlayerVariables.get(player), player);
                        break;
                    case "ADD_VARIABLE":
                        VariableCommandExecutor.executeAddVariable(cmd, PlayerVariables.get(player), player);
                        break;
                    // 其他命令...
                    default:
                        // 自定义命令等
                        break;
                }
            }

            String nextId = selected.getNextNodeId();

            if (msg.isBroadcast) {
                // 广播模式：任意一人选择就推进所有人
                BroadcastDialogueManager.getInstance().advanceBroadcast(nextId);
            } else {
                // 普通模式：只发给触发者
                ModPacketHandler.sendToPlayer(new OpenDialogueS2CPacket(nextId, msg.entityId), player);
            }

            // 记录历史等（保留原有逻辑）
          //  DialogueHistoryManager.getInstance().addEntry(player, currentNode, selected);
        });
        context.setPacketHandled(true);
    }
}