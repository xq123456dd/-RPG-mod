package rpg;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
// 【新增】导入事件相关类
import net.minecraftforge.event.level.LevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraft.server.level.ServerLevel;
import java.io.File;                     // 新增：用于创建文件夹
import net.minecraftforge.fml.loading.FMLPaths; // 新增：服务器端获取游戏目录

import rpg.data.DialogueLoader;
import rpg.item.ModItems;
import rpg.network.ModPacketHandler;
import rpg.tab.ModCreativeTabs;

@Mod(RpgDialogueMod.MOD_ID)
public class RpgDialogueMod {
    public static final String MOD_ID = "rpg";

    // 静态初始化块 - 移除 DialogueLoader.init() 调用，避免在不正确的时间清除数据
    static {
        System.out.println("正在初始化RPG对话Mod...");
        // DialogueLoader.init(); // 【重要】：此行已被移除。数据将在 LevelEvent.Load 时加载。
    }

    public RpgDialogueMod() {
        // 获取Forge模组事件总线
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModItems.register(modEventBus);
        ModCreativeTabs.register(modEventBus);

        modEventBus.addListener(this::commonSetup);
        MinecraftForge.EVENT_BUS.register(this); // 注册到事件总线

        // 初始化服务定位器
        rpg.service.ModServices.init();
        System.out.println("RPG对话Mod服务定位器已初始化");
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(() -> {
            ModPacketHandler.register();
            System.out.println("RPG对话Mod网络包已注册");

            // ==================== 新增功能：创建 rpg_images 文件夹 ====================
            // 兼容客户端和服务器端
            File gameDir;
            try {
                // 客户端环境下优先使用 Minecraft 实例
                gameDir = net.minecraft.client.Minecraft.getInstance().gameDirectory;
            } catch (Exception e) {
                gameDir = null;
            }

            if (gameDir == null) {
                // 服务器端或客户端未初始化时，使用 Forge 通用路径
                gameDir = FMLPaths.GAMEDIR.get().toFile();
            }

            File imagesDir = new File(gameDir, "rpg_images");
            if (!imagesDir.exists()) {
                if (imagesDir.mkdirs()) {
                    System.out.println("RPG对话Mod: 成功创建图片文件夹 -> " + imagesDir.getAbsolutePath());
                } else {
                    System.err.println("RPG对话Mod: 创建图片文件夹失败！路径: " + imagesDir.getAbsolutePath());
                }
            } else {
                System.out.println("RPG对话Mod: 图片文件夹已存在 -> " + imagesDir.getAbsolutePath());
            }
            // ===================================================================
        });
    }

    @SubscribeEvent
    public void registerCommands(net.minecraftforge.event.RegisterCommandsEvent event) {
        rpg.commands.DialogueCommand.register(event.getDispatcher());
        rpg.commands.DebugDialogueCommand.register(event.getDispatcher());
        System.out.println("RPG对话Mod命令已注册：/dialogue, /debugdialogue");
    }

    /**
     * 世界加载事件 - 负责在服务器启动时从文件加载数据
     */
    @SubscribeEvent
    public void onWorldLoad(LevelEvent.Load event) {
        // 确保只在服务器端的主世界加载时执行
        if (event.getLevel() instanceof ServerLevel serverLevel) {
            System.out.println("MOD: 触发世界加载事件，尝试加载对话数据...");
            DialogueLoader.loadDialogues(serverLevel);
        }
    }

    /**
     * 世界保存事件 - 负责在服务器保存时持久化数据
     */
    @SubscribeEvent
    public void onWorldSave(LevelEvent.Save event) {
        // 确保只在服务器端的主世界保存时执行
        if (event.getLevel() instanceof ServerLevel serverLevel) {
            System.out.println("MOD: 触发世界保存事件，尝试保存对话数据...");
            DialogueLoader.saveDialogues(serverLevel);
        }
    }
}