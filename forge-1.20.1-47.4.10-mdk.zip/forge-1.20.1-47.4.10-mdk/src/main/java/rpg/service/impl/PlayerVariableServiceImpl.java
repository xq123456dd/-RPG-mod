package rpg.service.impl;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import rpg.data.PlayerVariables;
import rpg.service.IPlayerVariableService;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 玩家变量服务实现
 * 负责管理所有玩家的变量
 */
public class PlayerVariableServiceImpl implements IPlayerVariableService {
    private static final Logger LOGGER = LogManager.getLogger();

    // 内存中的玩家变量缓存
    private final Map<UUID, PlayerVariables> playerVariables = new HashMap<>();

    // 脏标记，用于优化保存
    private final Map<UUID, Boolean> dirtyFlags = new HashMap<>();

    @Override
    public PlayerVariables getPlayerVariables(Player player) {
        UUID playerId = player.getUUID();

        // 如果内存中没有，从NBT加载
        if (!playerVariables.containsKey(playerId)) {
            loadPlayerVariables(player);
        }

        return playerVariables.get(playerId);
    }

    /**
     * 从玩家NBT加载变量
     */
    private void loadPlayerVariables(Player player) {
        UUID playerId = player.getUUID();
        CompoundTag playerData = player.getPersistentData();

        if (playerData.contains("rpg_dialogue_variables")) {
            CompoundTag variablesTag = playerData.getCompound("rpg_dialogue_variables");
            PlayerVariables pv = PlayerVariables.deserializeNBT(variablesTag);
            playerVariables.put(playerId, pv);
            dirtyFlags.put(playerId, false);

            LOGGER.info("加载玩家变量: " + playerId + ", 变量数: " + pv.getAllVariableNames().size());
        } else {
            // 如果没有变量，初始化一个空的
            playerVariables.put(playerId, new PlayerVariables(playerId));
            dirtyFlags.put(playerId, false);
        }
    }

    /**
     * 保存玩家变量到NBT
     */
    private void savePlayerVariables(Player player) {
        UUID playerId = player.getUUID();
        PlayerVariables pv = playerVariables.get(playerId);

        if (pv != null) {
            CompoundTag variablesTag = pv.serializeNBT();
            player.getPersistentData().put("rpg_dialogue_variables", variablesTag);
            dirtyFlags.put(playerId, false);

            LOGGER.info("保存玩家变量: " + playerId + ", 变量数: " + pv.getAllVariableNames().size());
        }
    }

    @Override
    public void markDirty(Player player) {
        UUID playerId = player.getUUID();
        dirtyFlags.put(playerId, true);
    }

    @Override
    public void saveDirtyData() {
        for (Map.Entry<UUID, Boolean> entry : dirtyFlags.entrySet()) {
            if (entry.getValue()) {
                UUID playerId = entry.getKey();
                // 这里需要从服务器获取玩家实例，实际使用时需要注入服务器实例
                LOGGER.info("玩家变量已标记为脏，需要保存: " + playerId);
            }
        }
    }

    @Override
    public void onPlayerLogout(ServerPlayer player) {
        if (playerVariables.containsKey(player.getUUID())) {
            savePlayerVariables(player);
        }
    }

    @Override
    public void clearPlayerVariables(Player player) {
        UUID playerId = player.getUUID();
        playerVariables.remove(playerId);
        dirtyFlags.remove(playerId);

        player.getPersistentData().remove("rpg_dialogue_variables");
        LOGGER.info("清除玩家变量: " + playerId);
    }
}
