package rpg.service.impl;

import rpg.data.DialogueNode;
import rpg.service.IDialogueRepository;
import rpg.service.ISerializer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 对话仓库实现
 * 负责对话数据的存储和管理
 */
public class DialogueRepositoryImpl implements IDialogueRepository {
    private final Map<String, DialogueNode> dialogueMap;
    private final Map<String, DialogueNode> temporaryNodes;
    private final ISerializer serializer;

    public DialogueRepositoryImpl(ISerializer serializer) {
        this.dialogueMap = new HashMap<>();
        this.temporaryNodes = new HashMap<>();
        this.serializer = serializer;
    }

    @Override
    public DialogueNode getNode(String nodeId) {
        if (nodeId == null || "END".equalsIgnoreCase(nodeId)) {
            return null;
        }

        // 1. 先尝试从临时节点中获取（广播对话使用）
        DialogueNode node = temporaryNodes.get(nodeId);
        if (node != null) {
            System.out.println("[DialogueRepository] 从临时节点中获取到: " + nodeId);
            return node;
        }

        // 2. 从全局节点中获取
        node = dialogueMap.get(nodeId);
        if (node != null) {
            System.out.println("[DialogueRepository] 从全局节点中获取到: " + nodeId);
            return node;
        }

        System.out.println("[DialogueRepository] 无法找到对话节点: " + nodeId);
        return null;
    }

    @Override
    public void saveNode(DialogueNode node) {
        if (node != null && node.getNodeId() != null) {
            dialogueMap.put(node.getNodeId(), node);
        }
    }

    @Override
    public void deleteNode(String nodeId) {
        dialogueMap.remove(nodeId);
    }

    @Override
    public Map<String, DialogueNode> getAllNodes() {
        return new HashMap<>(dialogueMap);
    }

    @Override
    public void addTemporaryNode(DialogueNode node) {
        if (node != null && node.getNodeId() != null) {
            temporaryNodes.put(node.getNodeId(), node);
            System.out.println("[DialogueRepository] 添加临时对话节点: " + node.getNodeId());
        }
    }

    @Override
    public void addTemporaryNodes(Map<String, DialogueNode> nodes) {
        if (nodes != null && !nodes.isEmpty()) {
            temporaryNodes.putAll(nodes);
            System.out.println("[DialogueRepository] 批量添加 " + nodes.size() + " 个临时对话节点");
        }
    }

    @Override
    public void clearTemporaryNodes() {
        System.out.println("[DialogueRepository] 清除 " + temporaryNodes.size() + " 个临时对话节点");
        temporaryNodes.clear();
    }

    @Override
    public int getTemporaryNodeCount() {
        return temporaryNodes.size();
    }

    @Override
    public List<String> getTemporaryNodeIds() {
        return new ArrayList<>(temporaryNodes.keySet());
    }

    /**
     * 清空所有对话数据
     */
    public void clearAll() {
        dialogueMap.clear();
        temporaryNodes.clear();
    }

    /**
     * 获取序列化服务
     */
    public ISerializer getSerializer() {
        return serializer;
    }
}
