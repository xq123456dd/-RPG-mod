package rpg.service.impl;

import net.minecraft.server.level.ServerPlayer;
import rpg.network.ModPacketHandler;
import rpg.service.IPacketSender;

/**
 * 网络包发送服务实现
 * 负责在客户端和服务器之间发送网络包
 */
public class PacketSenderImpl implements IPacketSender {

    @Override
    public <MSG> void sendToPlayer(MSG message, ServerPlayer player) {
        ModPacketHandler.sendToPlayer(message, player);
    }

    @Override
    public <MSG> void sendToServer(MSG message) {
        ModPacketHandler.sendToServer(message);
    }
}
