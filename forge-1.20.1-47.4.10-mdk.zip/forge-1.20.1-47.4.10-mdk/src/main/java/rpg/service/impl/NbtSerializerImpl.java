package rpg.service.impl;

import net.minecraft.nbt.CompoundTag;
import rpg.data.DialogueNode;
import rpg.service.ISerializer;

import java.util.HashMap;
import java.util.Map;

/**
 * NBT序列化服务实现
 * 负责将对话数据序列化到NBT格式
 */
public class NbtSerializerImpl implements ISerializer {

    @Override
    public CompoundTag serializeDialogueMap(Map<String, DialogueNode> dialogueMap) {
        CompoundTag rootNbt = new CompoundTag();
        for (Map.Entry<String, DialogueNode> entry : dialogueMap.entrySet()) {
            if (entry.getValue() != null) {
                try {
                    rootNbt.put(entry.getKey(), entry.getValue().serializeNBT());
                } catch (Exception e) {
                    System.err.println("序列化 DialogueNode 失败，ID: " + entry.getKey());
                    e.printStackTrace();
                }
            }
        }
        return rootNbt;
    }

    @Override
    public Map<String, DialogueNode> deserializeDialogueMap(CompoundTag nbt) {
        Map<String, DialogueNode> map = new HashMap<>();
        for (String nodeId : nbt.getAllKeys()) {
            CompoundTag nodeNbt = nbt.getCompound(nodeId);
            try {
                map.put(nodeId, DialogueNode.deserializeNBT(nodeNbt));
            } catch (Exception e) {
                System.err.println("反序列化 DialogueNode 失败，ID: " + nodeId);
                e.printStackTrace();
            }
        }
        return map;
    }
}
