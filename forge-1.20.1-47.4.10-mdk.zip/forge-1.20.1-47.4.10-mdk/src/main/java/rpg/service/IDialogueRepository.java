package rpg.service;

import rpg.data.DialogueNode;

import java.util.Map;

/**
 * 对话数据仓库接口
 * 用于解耦对话数据的存储和访问逻辑
 */
public interface IDialogueRepository {
    /**
     * 获取对话节点
     */
    DialogueNode getNode(String nodeId);

    /**
     * 保存对话节点
     */
    void saveNode(DialogueNode node);

    /**
     * 删除对话节点
     */
    void deleteNode(String nodeId);

    /**
     * 获取所有对话节点
     */
    Map<String, DialogueNode> getAllNodes();

    /**
     * 添加临时节点（用于广播对话）
     */
    void addTemporaryNode(DialogueNode node);

    /**
     * 批量添加临时节点
     */
    void addTemporaryNodes(Map<String, DialogueNode> nodes);

    /**
     * 清除所有临时节点
     */
    void clearTemporaryNodes();

    /**
     * 获取临时节点数量
     */
    int getTemporaryNodeCount();

    /**
     * 获取临时节点ID列表
     */
    java.util.List<String> getTemporaryNodeIds();
}
