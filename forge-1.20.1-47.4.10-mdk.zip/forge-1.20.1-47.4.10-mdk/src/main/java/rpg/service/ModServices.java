package rpg.service;

import rpg.service.impl.DialogueHistoryServiceImpl;
import rpg.service.impl.DialogueRepositoryImpl;
import rpg.service.impl.NbtSerializerImpl;
import rpg.service.impl.PacketSenderImpl;
import rpg.service.impl.PlayerVariableServiceImpl;

/**
 * 服务定位器
 * 集中管理所有服务实例，便于依赖注入和测试
 */
public class ModServices {
    private static IDialogueRepository dialogueRepository;
    private static IPlayerVariableService playerVariableService;
    private static IPacketSender packetSender;
    private static IDialogueHistoryService dialogueHistoryService;
    private static ISerializer serializer;

    /**
     * 初始化所有服务
     */
    public static void init() {
        // 初始化序列化服务
        serializer = new NbtSerializerImpl();

        // 初始化对话仓库
        dialogueRepository = new DialogueRepositoryImpl(serializer);

        // 初始化玩家变量服务
        playerVariableService = new PlayerVariableServiceImpl();

        // 初始化网络包发送服务
        packetSender = new PacketSenderImpl();

        // 初始化对话历史服务
        dialogueHistoryService = new DialogueHistoryServiceImpl();
    }

    public static IDialogueRepository getDialogueRepository() {
        return dialogueRepository;
    }

    public static void setDialogueRepository(IDialogueRepository dialogueRepository) {
        ModServices.dialogueRepository = dialogueRepository;
    }

    public static IPlayerVariableService getPlayerVariableService() {
        return playerVariableService;
    }

    public static void setPlayerVariableService(IPlayerVariableService playerVariableService) {
        ModServices.playerVariableService = playerVariableService;
    }

    public static IPacketSender getPacketSender() {
        return packetSender;
    }

    public static void setPacketSender(IPacketSender packetSender) {
        ModServices.packetSender = packetSender;
    }

    public static IDialogueHistoryService getDialogueHistoryService() {
        return dialogueHistoryService;
    }

    public static void setDialogueHistoryService(IDialogueHistoryService dialogueHistoryService) {
        ModServices.dialogueHistoryService = dialogueHistoryService;
    }

    public static ISerializer getSerializer() {
        return serializer;
    }

    public static void setSerializer(ISerializer serializer) {
        ModServices.serializer = serializer;
    }
}
