package rpg.service;

import net.minecraft.server.level.ServerPlayer;

/**
 * 网络包发送服务接口
 * 用于解耦网络通信逻辑
 */
public interface IPacketSender {
    /**
     * 发送消息给特定玩家 (服务器 -> 客户端)
     */
    <MSG> void sendToPlayer(MSG message, ServerPlayer player);

    /**
     * 发送消息给服务器 (客户端 -> 服务器)
     */
    <MSG> void sendToServer(MSG message);
}
