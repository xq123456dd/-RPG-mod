package rpg.service;

import net.minecraft.nbt.CompoundTag;
import rpg.data.DialogueNode;

import java.util.Map;

/**
 * 序列化服务接口
 * 用于解耦序列化/反序列化逻辑
 */
public interface ISerializer {
    /**
     * 将对话地图序列化为NBT
     */
    CompoundTag serializeDialogueMap(Map<String, DialogueNode> dialogueMap);

    /**
     * 从NBT反序列化对话地图
     */
    Map<String, DialogueNode> deserializeDialogueMap(CompoundTag nbt);
}
