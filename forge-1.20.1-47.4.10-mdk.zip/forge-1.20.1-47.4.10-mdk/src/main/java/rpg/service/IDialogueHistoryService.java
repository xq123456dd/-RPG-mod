package rpg.service;

import rpg.data.DialogueHistoryManager.DialogueHistoryEntry;
import net.minecraft.server.level.ServerPlayer;

import java.util.List;
import java.util.Map;

/**
 * 对话历史服务接口
 * 用于解耦对话历史的管理逻辑
 */
public interface IDialogueHistoryService {
    /**
     * 添加一条历史记录（服务器端调用）
     */
    void addHistory(ServerPlayer player, String npcName, String nodeId, String npcText, String selectedOption);

    /**
     * 获取玩家所有历史记录
     */
    List<DialogueHistoryEntry> getAllHistory();

    /**
     * 获取按NPC分组的历史记录
     */
    Map<String, List<DialogueHistoryEntry>> getGroupedHistory();

    /**
     * 玩家登出时强制保存
     */
    void onPlayerLogout(ServerPlayer player);
}
