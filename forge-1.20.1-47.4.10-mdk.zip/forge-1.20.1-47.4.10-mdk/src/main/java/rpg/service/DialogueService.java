package rpg.service;

import net.minecraft.server.level.ServerPlayer;
import rpg.data.DialogueNode;
import rpg.data.DialogueOption;
import rpg.data.PlayerVariables;

import java.util.List;
import java.util.UUID;

/**
 * 对话服务
 * 负责处理对话流程逻辑，与数据存储和网络通信解耦
 */
public class DialogueService {
    private final IDialogueRepository dialogueRepository;
    private final IPlayerVariableService playerVariableService;
    private final IPacketSender packetSender;
    private final IDialogueHistoryService dialogueHistoryService;

    public DialogueService(IDialogueRepository dialogueRepository,
                          IPlayerVariableService playerVariableService,
                          IPacketSender packetSender,
                          IDialogueHistoryService dialogueHistoryService) {
        this.dialogueRepository = dialogueRepository;
        this.playerVariableService = playerVariableService;
        this.packetSender = packetSender;
        this.dialogueHistoryService = dialogueHistoryService;
    }

    /**
     * 处理玩家选择的对话选项
     */
    public void processDialogueOption(ServerPlayer player, String nodeId, String optionId) {
        // 获取对话节点
        DialogueNode node = dialogueRepository.getNode(nodeId);
        if (node == null) {
            return;
        }

        // 获取玩家变量
        PlayerVariables variables = playerVariableService.getPlayerVariables(player);

        // 查找选项
        DialogueOption selectedOption = null;
        for (DialogueOption option : node.getOptions()) {
            if (optionId.equals(option.getOptionText()) || 
                optionId.equals(option.getNextNodeId())) {
                // 检查选项是否可用
                if (option.isAvailableForPlayer(variables)) {
                    selectedOption = option;
                    break;
                }
            }
        }

        if (selectedOption == null) {
            return;
        }

        // 执行选项的命令
        executeCommands(player, selectedOption.getCommands(), variables);

        // 记录历史
        dialogueHistoryService.addHistory(
            player,
            node.getSpeakerName(),
            nodeId,
            node.getNpcText(),
            selectedOption.getOptionText()
        );

        // 发送下一个节点
        String nextNodeId = selectedOption.getNextNodeId();
        if (nextNodeId != null && !"END".equals(nextNodeId)) {
            DialogueNode nextNode = dialogueRepository.getNode(nextNodeId);
            if (nextNode != null) {
                sendDialogueToPlayer(player, nextNode);
            }
        }
    }

    /**
     * 发送对话给玩家
     */
    public void sendDialogueToPlayer(ServerPlayer player, DialogueNode node) {
        // 这里应该创建并发送网络包
        // 实际实现需要使用 packetSender 发送 OpenDialogueS2CPacket
        // 为了解耦，这里只是示例
        System.out.println("发送对话节点给玩家: " + player.getName().getString() + 
                          ", 节点ID: " + node.getNodeId());
    }

    /**
     * 执行对话命令
     */
    private void executeCommands(ServerPlayer player, 
                                List<rpg.data.DialogueCommand> commands,
                                PlayerVariables variables) {
        if (commands == null || commands.isEmpty()) {
            return;
        }

        for (rpg.data.DialogueCommand command : commands) {
            executeCommand(player, command, variables);
        }
    }

    /**
     * 执行单个命令
     */
    private void executeCommand(ServerPlayer player, 
                              rpg.data.DialogueCommand command,
                              PlayerVariables variables) {
        // 这里应该调用 VariableCommandExecutor 执行命令
        // 为了解耦，这里只是示例
        System.out.println("执行命令: " + command.getCommandType());
    }

    /**
     * 检查对话节点是否对玩家可用
     */
    public boolean isNodeAvailableForPlayer(String nodeId, ServerPlayer player) {
        DialogueNode node = dialogueRepository.getNode(nodeId);
        if (node == null) {
            return false;
        }

        PlayerVariables variables = playerVariableService.getPlayerVariables(player);

        // 检查所有选项是否可用
        for (DialogueOption option : node.getOptions()) {
            if (option.isAvailableForPlayer(variables)) {
                return true;
            }
        }

        return false;
    }

    /**
     * 获取玩家可用的对话选项
     */
    public List<DialogueOption> getAvailableOptions(String nodeId, ServerPlayer player) {
        DialogueNode node = dialogueRepository.getNode(nodeId);
        if (node == null) {
            return List.of();
        }

        PlayerVariables variables = playerVariableService.getPlayerVariables(player);

        return node.getOptions().stream()
            .filter(option -> option.isAvailableForPlayer(variables))
            .toList();
    }
}
