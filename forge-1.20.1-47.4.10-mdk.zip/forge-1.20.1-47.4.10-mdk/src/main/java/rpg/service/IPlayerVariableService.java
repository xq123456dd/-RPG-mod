package rpg.service;

import rpg.data.PlayerVariables;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;

/**
 * 玩家变量服务接口
 * 用于解耦玩家变量的管理逻辑
 */
public interface IPlayerVariableService {
    /**
     * 获取玩家的变量管理器
     */
    PlayerVariables getPlayerVariables(Player player);

    /**
     * 标记玩家变量为脏（需要保存）
     */
    void markDirty(Player player);

    /**
     * 定期保存脏数据
     */
    void saveDirtyData();

    /**
     * 玩家登出时保存数据
     */
    void onPlayerLogout(ServerPlayer player);

    /**
     * 清除玩家变量（用于测试或重置）
     */
    void clearPlayerVariables(Player player);
}
