package rpg.test;

import rpg.data.PlayerVariables;

import java.util.UUID;

/**
 * 玩家变量构建器
 * 用于简化测试数据的创建
 */
public class PlayerVariablesBuilder {
    private UUID playerId = UUID.randomUUID();
    private PlayerVariables variables;

    public static PlayerVariablesBuilder someVariables() {
        return new PlayerVariablesBuilder();
    }

    public PlayerVariablesBuilder withPlayerId(UUID playerId) {
        this.playerId = playerId;
        return this;
    }

    public PlayerVariablesBuilder withVariable(String name, PlayerVariables.VariableType type, Object value) {
        if (variables == null) {
            variables = new PlayerVariables(playerId);
        }
        variables.setVariable(name, type, value);
        return this;
    }

    public PlayerVariables build() {
        if (variables == null) {
            variables = new PlayerVariables(playerId);
        }
        return variables;
    }
}
