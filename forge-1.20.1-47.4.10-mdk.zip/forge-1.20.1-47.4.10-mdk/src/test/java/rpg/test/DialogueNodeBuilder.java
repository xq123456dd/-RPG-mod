package rpg.test;

import rpg.data.DialogueNode;
import rpg.data.DialogueOption;

import java.util.ArrayList;
import java.util.List;

/**
 * 对话节点构建器
 * 用于简化测试数据的创建
 */
public class DialogueNodeBuilder {
    private String nodeId;
    private String speakerName = "";
    private String npcText = "";
    private List<DialogueOption> options = new ArrayList<>();
    private int priority = 0;

    public static DialogueNodeBuilder aNode() {
        return new DialogueNodeBuilder();
    }

    public DialogueNodeBuilder withId(String id) {
        this.nodeId = id;
        return this;
    }

    public DialogueNodeBuilder withSpeaker(String speakerName) {
        this.speakerName = speakerName;
        return this;
    }

    public DialogueNodeBuilder withText(String npcText) {
        this.npcText = npcText;
        return this;
    }

    public DialogueNodeBuilder withOption(DialogueOption option) {
        this.options.add(option);
        return this;
    }

    public DialogueNodeBuilder withOptions(List<DialogueOption> options) {
        this.options.addAll(options);
        return this;
    }

    public DialogueNodeBuilder withPriority(int priority) {
        this.priority = priority;
        return this;
    }

    public DialogueNode build() {
        DialogueNode node = new DialogueNode(nodeId, speakerName, npcText, options);
        node.setPriority(priority);
        return node;
    }
}
