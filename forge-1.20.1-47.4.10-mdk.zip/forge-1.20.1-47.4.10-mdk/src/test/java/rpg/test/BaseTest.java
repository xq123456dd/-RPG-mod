package rpg.test;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;

/**
 * 测试基类
 * 提供通用的测试工具方法和设置/清理逻辑
 */
public abstract class BaseTest {

    @BeforeEach
    public void setUp() throws Exception {
        // 子类可以覆盖此方法进行特定的设置
    }

    @AfterEach
    public void tearDown() throws Exception {
        // 子类可以覆盖此方法进行特定的清理
    }

    /**
     * 等待一段时间（用于异步测试）
     */
    protected void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
