package rpg.test;

import rpg.data.DialogueOption;

/**
 * 对话选项构建器
 * 用于简化测试数据的创建
 */
public class DialogueOptionBuilder {
    private String optionText;
    private String nextNodeId;
    private String action = "NONE";
    private String condition = "";
    private int priority = 0;

    public static DialogueOptionBuilder anOption() {
        return new DialogueOptionBuilder();
    }

    public DialogueOptionBuilder withText(String text) {
        this.optionText = text;
        return this;
    }

    public DialogueOptionBuilder withNextNode(String nodeId) {
        this.nextNodeId = nodeId;
        return this;
    }

    public DialogueOptionBuilder withAction(String action) {
        this.action = action != null ? action : "NONE";
        return this;
    }

    public DialogueOptionBuilder withCondition(String condition) {
        this.condition = condition != null ? condition : "";
        return this;
    }

    public DialogueOptionBuilder withPriority(int priority) {
        this.priority = priority;
        return this;
    }

    public DialogueOption build() {
        DialogueOption option = new DialogueOption(optionText, nextNodeId, action, condition);
        option.setPriority(priority);
        return option;
    }
}
