# 对话显示问题修复说明

## 问题描述

当使用命令给玩家显示对话框时，除了房主（命令执行者）外，其他玩家只会显示默认对话框而不是对应的对话框。

## 问题原因

1. **节点同步包未发送**：在`BroadcastDialogueManager`的`syncNodesToAllClients`方法中，同步节点的代码被注释掉了，导致节点数据没有发送给客户端。

2. **新玩家加入时未同步节点**：当新玩家加入广播对话时，没有先同步节点数据就直接发送对话节点，导致新玩家也看不到正确的对话内容。

3. **命令触发对话时未同步节点**：使用`/dialogue start`和`/dialogue npc`命令触发对话时，没有先同步节点数据给客户端。

## 修复方案

### 1. 修复BroadcastDialogueManager中的节点同步

**文件**：`src/main/java/rpg/data/BroadcastDialogueManager.java`

**修改**：
- 取消注释`syncNodesToAllClients`方法中的节点同步包发送代码
- 添加日志输出，显示同步的节点数量

```java
// 修改前
// ModPacketHandler.sendToPlayer(syncPacket, player);

// 修改后
ModPacketHandler.sendToPlayer(syncPacket, player);
LOGGER.info("已发送节点同步包给玩家: {}, 节点数: {}", player.getName().getString(), broadcastNodes.size());
```

### 2. 添加新玩家加入时的节点同步

**文件**：`src/main/java/rpg/data/BroadcastDialogueManager.java`

**修改**：
- 在`addPlayer`方法中，先同步所有节点数据给新玩家，然后再发送当前对话节点
- 添加`syncNodesToPlayer`方法，用于同步节点数据给单个玩家

```java
// 先同步所有节点数据给新玩家
syncNodesToPlayer(player, broadcastNpcId);

// 然后同步当前对话节点
if (currentBroadcastNodeId != null && !"END".equals(currentBroadcastNodeId)) {
    sendNodeToPlayer(player, currentBroadcastNodeId, broadcastNpcId);
}
```

### 3. 修复命令触发对话时的节点同步

**文件**：`src/main/java/rpg/commands/DialogueCommand.java`

**修改**：
- 在`executeStart`和`executeNpcDialogue`方法中，先同步节点数据给客户端，然后再发送对话包
- 添加`syncNodeDataToPlayer`方法，用于同步节点数据给玩家

```java
// 先同步节点数据给客户端
syncNodeDataToPlayer(player, entityId);

// 然后发送对话包
ModPacketHandler.sendToPlayer(new OpenDialogueS2CPacket(nodeId, entityId), player);
```

### 4. 优化节点同步逻辑

**文件**：`src/main/java/rpg/network/SyncDialogueDataPacket.java`

**修改**：
- 修改节点同步逻辑，只清空同一NPC的临时节点，避免多个NPC对话数据冲突
- 添加`clearTemporaryNodesForNpc`方法

## 测试建议

1. **测试广播对话**：
   - 使用`/dialogue broadcast <entityId> <nodeId>`启动广播对话
   - 验证所有玩家都能看到正确的对话内容

2. **测试NPC对话**：
   - 使用`/dialogue npc <player> <entityId> <startNode>`打开NPC对话
   - 验证目标玩家能看到正确的对话内容

3. **测试新玩家加入**：
   - 在广播对话进行中，让新玩家加入服务器
   - 验证新玩家能看到正确的对话内容

## 注意事项

1. **网络包顺序**：确保节点同步包在对话包之前发送，否则客户端可能无法找到节点数据
2. **节点数据清理**：避免多个NPC对话数据冲突，需要正确清理临时节点
3. **错误处理**：添加适当的错误处理和日志输出，便于排查问题

## 后续改进建议

1. **NPC特定节点管理**：改进临时节点管理，支持按NPC ID清理节点，避免全局清理
2. **节点缓存机制**：在客户端实现节点缓存，减少重复同步
3. **增量同步**：只同步变化的节点数据，而不是全部同步
4. **压缩传输**：对节点数据进行压缩，减少网络传输量
